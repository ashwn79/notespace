import { convertNodesSerialize, deserializeMd, serializeMd } from '@platejs/markdown';
import type { Value } from 'platejs';
import { createPlateEditor } from 'platejs/react';
import { editorPlugins } from '../plugins/editor-plugins';
import type { TextEditorValue } from '../types/editor';

function formatTableNode(node: any): string {
  const rows = node.children || [];
  if (rows.length === 0) return '';

  const tableData: string[][] = rows.map((row: any) =>
    (row.children || []).map((cell: any) => {
      return (cell.children || [])
        .map(
          (child: any) =>
            child.value ||
            (child.children && child.children.map((c: any) => c.value || '').join('')) ||
            '',
        )
        .join('')
        .replace(/\|/g, '\\|')
        .replace(/\n/g, ' ')
        .trim();
    }),
  );

  const colCount = Math.max(...tableData.map((r) => r.length), 1);
  const normalizedRows = tableData.map((row) => {
    const padded = [...row];
    while (padded.length < colCount) padded.push('');
    return padded;
  });

  const headerRow = normalizedRows[0] || [];
  const dataRows = normalizedRows.slice(1);

  const headerLine = `| ${headerRow.join(' | ')} |`;
  const delimiterLine = `| ${Array.from({ length: colCount }).fill('---').join(' | ')} |`;
  const bodyLines = dataRows.map((r) => `| ${r.join(' | ')} |`);

  return `${[headerLine, delimiterLine, ...bodyLines].join('\n')}\n\n`;
}

const customMarkdownRules: Record<string, any> = {
  todo: {
    serialize: (node: any, options: any) => ({
      type: 'todoItem',
      checked: Boolean(node.checked),
      children: convertNodesSerialize(node.children, options),
    }),
  },
  callout: {
    serialize: (node: any, options: any) => {
      const icon = node.icon ? `${node.icon} ` : '💡 ';
      return {
        type: 'blockquote',
        children: [
          {
            type: 'paragraph',
            children: [
              { type: 'text', value: icon },
              ...convertNodesSerialize(node.children, options),
            ],
          },
        ],
      };
    },
  },
  date: {
    serialize: (node: any) => ({
      type: 'text',
      value: String(node.date || node.value || ''),
    }),
  },
  mention: {
    serialize: (node: any) => ({
      type: 'link',
      url: `mention:${encodeURIComponent(String(node.key || node.value || ''))}`,
      children: [{ type: 'text', value: String(node.value || node.label || 'Mention') }],
    }),
  },
  toggle: {
    serialize: (node: any, options: any) => ({
      type: 'paragraph',
      children: convertNodesSerialize(node.children, options),
    }),
  },
  column_group: {
    serialize: (node: any, options: any) => ({
      type: 'root',
      children: (node.children || []).flatMap((col: any) =>
        convertNodesSerialize(col.children || [], options),
      ),
    }),
  },
  column: {
    serialize: (node: any, options: any) => ({
      type: 'root',
      children: convertNodesSerialize(node.children || [], options),
    }),
  },
  toc: {
    serialize: () => ({
      type: 'text',
      value: '',
    }),
  },
};

const remarkHandlers = {
  table: formatTableNode,
  todoItem: (node: any) => {
    const mark = node.checked ? '- [x] ' : '- [ ] ';
    const text = (node.children || []).map((c: any) => c.value || '').join('');
    return `${mark}${text}\n`;
  },
};

function serializeBlocksChunk(blocks: any[]): string {
  if (blocks.length === 0) return '';
  const editor = createPlateEditor({
    plugins: editorPlugins,
    value: blocks as unknown as Value,
  });
  return serializeMd(editor, {
    rules: customMarkdownRules,
    remarkStringifyOptions: {
      handlers: remarkHandlers,
    },
  }).trim();
}

function serializeContainerSubtree(nodes: any[]): string {
  const chunks: string[] = [];
  let i = 0;

  while (i < nodes.length) {
    const node = nodes[i];
    const nodeIndent = (node.indent as number) || 0;

    if (node.type === 'toggle') {
      const descendants: any[] = [];
      let j = i + 1;
      while (j < nodes.length) {
        const nextNode = nodes[j];
        const nextIndent = (nextNode.indent as number) || 0;
        if (nextIndent > nodeIndent) {
          descendants.push({
            ...nextNode,
            indent: nextIndent - (nodeIndent + 1),
          });
          j++;
        } else {
          break;
        }
      }
      i = j;

      const titleText = (node.children || [])
        .map((c: any) => c.text || c.value || '')
        .join('')
        .trim();

      const childrenMd =
        descendants.length > 0 ? serializeContainerSubtree(descendants).trim() : '';

      chunks.push(`<details>\n<summary>${titleText}</summary>\n\n${childrenMd}\n\n</details>`);
    } else if (node.type === 'callout') {
      const descendants: any[] = [];
      let j = i + 1;
      while (j < nodes.length) {
        const nextNode = nodes[j];
        const nextIndent = (nextNode.indent as number) || 0;
        if (nextIndent > nodeIndent) {
          descendants.push({
            ...nextNode,
            indent: nextIndent - (nodeIndent + 1),
          });
          j++;
        } else {
          break;
        }
      }
      i = j;

      const icon = node.icon && node.icon !== 'none' ? `${node.icon} ` : '💡 ';
      const headerText = (node.children || [])
        .map((c: any) => c.text || c.value || '')
        .join('')
        .trim();

      let calloutBody = `${icon}${headerText}`.trim();
      if (descendants.length > 0) {
        const childrenMd = serializeContainerSubtree(descendants).trim();
        calloutBody += `\n\n${childrenMd}`;
      }

      const blockquote = calloutBody
        .split('\n')
        .map((line) => (line.length > 0 ? `> ${line}` : '>'))
        .join('\n');

      chunks.push(blockquote);
    } else {
      const ordinary: any[] = [];
      let j = i;
      while (j < nodes.length) {
        const nextNode = nodes[j];
        if (nextNode.type === 'toggle' || nextNode.type === 'callout') break;
        ordinary.push(nextNode);
        j++;
      }
      i = j;

      const md = serializeBlocksChunk(ordinary);
      if (md) {
        chunks.push(md);
      }
    }
  }

  return chunks.join('\n\n');
}

export function editorValueToMarkdown(value: TextEditorValue): string {
  try {
    if (!Array.isArray(value) || value.length === 0) return '';
    return serializeContainerSubtree(value);
  } catch (err) {
    console.error('Failed to serialize editor value to markdown:', err);
    return '';
  }
}

function postProcessDeserialized(nodes: any[]): any[] {
  const result: any[] = [];
  let indent = 0;

  for (const node of nodes) {
    const text = (node.children || []).map((c: any) => c.text || '').join('');
    const detailsMatch = text.match(/<details>\s*<summary>(.*?)<\/summary>/i);
    const closeMatch = text.match(/<\/details>/i);

    if (detailsMatch) {
      result.push({
        type: 'toggle',
        open: true,
        indent,
        children: [{ text: detailsMatch[1] }],
      });
      indent++;
    } else if (closeMatch) {
      indent = Math.max(0, indent - 1);
    } else {
      result.push({
        ...node,
        ...(indent > 0 ? { indent } : {}),
      });
    }
  }

  return result;
}

export function markdownToEditorValue(markdown: string): TextEditorValue {
  const editor = createPlateEditor({
    plugins: editorPlugins,
  });
  const nodes = deserializeMd(editor, markdown);
  const processed = postProcessDeserialized(nodes as any[]);
  return processed as unknown as TextEditorValue;
}
