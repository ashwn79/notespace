import { cn } from '@xpace/ui';
import { PlateElement, type PlateElementProps } from 'platejs/react';

export function LinkElement({ className, children, element, ...props }: PlateElementProps) {
  const url = (element.url as string) || '';
  return (
    <PlateElement
      as="a"
      element={element}
      className={cn(
        'font-medium text-sky-400 underline underline-offset-4 hover:text-sky-300 transition-colors cursor-pointer',
        className,
      )}
      {...props}
      {...({
        href: url,
        target: (element.target as string) || '_blank',
        rel: 'noopener noreferrer',
      } as any)}
    >
      {children}
    </PlateElement>
  );
}
