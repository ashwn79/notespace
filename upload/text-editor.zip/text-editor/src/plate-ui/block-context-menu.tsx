'use client';

import { indent, outdent } from '@platejs/indent';
import {
  BLOCK_CONTEXT_MENU_ID,
  BlockMenuPlugin,
  BlockSelectionPlugin,
} from '@platejs/selection/react';
import {
  BulletedList,
  Copy,
  FileCode2,
  Heading1,
  Heading2,
  Heading3,
  Indent,
  NumberedList,
  Outdent,
  Quote,
  TodoList,
  ToggleHeading1,
  ToggleHeading2,
  ToggleHeading3,
  ToggleList,
  Trash2,
  Type,
} from '@xpace/icons';
import { FolderOpen, Lightbulb, Palette } from 'lucide-react';
import { KEYS, nanoid, PathApi } from 'platejs';
import { useEditorPlugin, useEditorReadOnly, usePluginOption } from 'platejs/react';
import * as React from 'react';
import { getCommandTargets, setBlockType } from '../commands/transforms';
import {
  ContextMenu,
  ContextMenuContent,
  ContextMenuGroup,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuSub,
  ContextMenuSubContent,
  ContextMenuSubTrigger,
  ContextMenuTrigger,
} from './context-menu';
import { expandSelectionNodesWithChildren, unwrapToggle } from './toggle-utils';

export function BlockContextMenu({ children }: { children: React.ReactNode }) {
  const { api, editor } = useEditorPlugin(BlockMenuPlugin);
  const readOnly = useEditorReadOnly();
  const openId = usePluginOption(BlockMenuPlugin, 'openId');
  const isOpen = openId === BLOCK_CONTEXT_MENU_ID;

  React.useEffect(() => {
    if (!isOpen) return;

    const handleScroll = () => {
      api.blockMenu.hide();
    };

    window.addEventListener('scroll', handleScroll, true);
    return () => {
      window.removeEventListener('scroll', handleScroll, true);
    };
  }, [isOpen, api]);

  const handleTurnInto = React.useCallback(
    (type: string) => {
      const targets = getCommandTargets(editor);
      if (targets.length > 0) {
        const sorted = [...targets].sort((a, b) => PathApi.compare(b[1], a[1]));
        editor.tf.withoutNormalizing(() => {
          sorted.forEach(([, path]) => {
            setBlockType(editor, type, { at: path });
          });
        });
      } else {
        setBlockType(editor, type);
      }
      editor.tf.focus();
    },
    [editor],
  );

  const handleUnwrap = React.useCallback(() => {
    const targets = getCommandTargets(editor);
    if (targets.length > 0) {
      editor.tf.withoutNormalizing(() => {
        targets.forEach(([node]) => {
          if (node.type === KEYS.toggle) {
            unwrapToggle(editor, node);
          }
        });
      });
    }
    editor.tf.focus();
  }, [editor]);

  const handleDelete = React.useCallback(() => {
    const targets = getCommandTargets(editor);
    if (targets.length > 0) {
      const expandedTargets = expandSelectionNodesWithChildren(editor, targets);
      const sorted = [...expandedTargets].sort((a, b) => PathApi.compare(b[1], a[1]));
      editor.tf.withoutNormalizing(() => {
        sorted.forEach(([, path]) => {
          editor.tf.removeNodes({ at: path });
        });
      });
      const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;
      blockSelectionApi?.clear?.();
    }
    editor.tf.focus();
  }, [editor]);

  const handleDuplicate = React.useCallback(() => {
    const targets = getCommandTargets(editor);
    if (targets.length > 0) {
      const expandedTargets = expandSelectionNodesWithChildren(editor, targets);
      const sorted = [...expandedTargets].sort((a, b) => PathApi.compare(a[1], b[1]));
      const lastEntry = sorted[sorted.length - 1];
      if (lastEntry) {
        const assignNewIds = (node: any): any => {
          const clone = { ...node, id: nanoid() };
          if (Array.isArray(clone.children)) {
            clone.children = clone.children.map((child: any) => {
              if (child && typeof child === 'object' && ('type' in child || 'children' in child)) {
                return assignNewIds(child);
              }
              return { ...child };
            });
          }
          return clone;
        };

        const clones = sorted.map(([node]) => assignNewIds(node));
        const insertPath = PathApi.next(lastEntry[1]);
        editor.tf.insertNodes(clones, { at: insertPath });

        const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;
        if (blockSelectionApi) {
          blockSelectionApi.set(clones.map((c: any) => c.id as string));
        }
      }
    }
  }, [editor]);

  const handleIndent = React.useCallback(() => {
    const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;
    if (blockSelectionApi && blockSelectionApi.getNodes().length > 0) {
      editor.getTransforms(BlockSelectionPlugin).blockSelection.setIndent(1);
    } else {
      indent(editor);
    }
  }, [editor]);

  const handleOutdent = React.useCallback(() => {
    const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;
    if (blockSelectionApi && blockSelectionApi.getNodes().length > 0) {
      editor.getTransforms(BlockSelectionPlugin).blockSelection.setIndent(-1);
    } else {
      outdent(editor);
    }
  }, [editor]);

  const handleApplyColor = React.useCallback(
    (color: string) => {
      const targets = getCommandTargets(editor);
      if (targets.length > 0) {
        editor.tf.withoutNormalizing(() => {
          targets.forEach(([, path]) => {
            if (!color) {
              editor.tf.unsetNodes('color', { at: path, match: (n) => 'text' in n });
            } else {
              editor.tf.setNodes({ color }, { at: path, match: (n) => 'text' in n });
            }
          });
        });
      } else {
        if (!color) editor.tf.removeMark('color');
        else editor.tf.addMark('color', color);
      }
    },
    [editor],
  );

  const handleApplyBgColor = React.useCallback(
    (backgroundColor: string) => {
      const targets = getCommandTargets(editor);
      if (targets.length > 0) {
        editor.tf.withoutNormalizing(() => {
          targets.forEach(([, path]) => {
            if (!backgroundColor) {
              editor.tf.unsetNodes('backgroundColor', { at: path, match: (n) => 'text' in n });
            } else {
              editor.tf.setNodes({ backgroundColor }, { at: path, match: (n) => 'text' in n });
            }
          });
        });
      } else {
        if (!backgroundColor) editor.tf.removeMark('backgroundColor');
        else editor.tf.addMark('backgroundColor', backgroundColor);
      }
    },
    [editor],
  );

  const currentTargets = isOpen ? getCommandTargets(editor) : [];
  const hasToggleTarget = currentTargets.some(([node]) => node.type === KEYS.toggle);

  return (
    <ContextMenu
      modal={false}
      onOpenChange={(open) => {
        if (!open) {
          api.blockMenu.hide();
        }
      }}
    >
      <ContextMenuTrigger
        asChild
        onContextMenu={(event) => {
          const dataset = (event.target as HTMLElement).dataset;
          const disabled =
            dataset?.slateEditor === 'true' ||
            readOnly ||
            dataset?.plateOpenContextMenu === 'false';

          if (disabled) return event.preventDefault();

          setTimeout(() => {
            api.blockMenu.show(BLOCK_CONTEXT_MENU_ID, {
              x: event.clientX,
              y: event.clientY,
            });
          }, 0);
        }}
      >
        <div className="w-full">{children}</div>
      </ContextMenuTrigger>

      {isOpen && (
        <ContextMenuContent
          className="w-56"
          onCloseAutoFocus={(e) => {
            e.preventDefault();
            editor.getApi(BlockSelectionPlugin).blockSelection.focus();
          }}
        >
          <ContextMenuGroup>
            {/* Turn into submenu */}
            <ContextMenuSub>
              <ContextMenuSubTrigger className="gap-2">
                <Type className="h-3.5 w-3.5 text-zinc-400" />
                <span>Turn into</span>
              </ContextMenuSubTrigger>
              <ContextMenuSubContent className="w-48">
                <ContextMenuItem onClick={() => handleTurnInto(KEYS.p)} className="gap-2">
                  <Type className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Paragraph</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto(KEYS.h1)} className="gap-2">
                  <Heading1 className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Heading 1</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto(KEYS.h2)} className="gap-2">
                  <Heading2 className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Heading 2</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto(KEYS.h3)} className="gap-2">
                  <Heading3 className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Heading 3</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto(KEYS.blockquote)} className="gap-2">
                  <Quote className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Quote</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto(KEYS.ul)} className="gap-2">
                  <BulletedList className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Bulleted list</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto(KEYS.ol)} className="gap-2">
                  <NumberedList className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Numbered list</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto(KEYS.listTodo)} className="gap-2">
                  <TodoList className="h-3.5 w-3.5 text-zinc-400" />
                  <span>To-do list</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto(KEYS.toggle)} className="gap-2">
                  <ToggleList className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Toggle list</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto('toggle_h1')} className="gap-2">
                  <ToggleHeading1 className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Toggle heading 1</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto('toggle_h2')} className="gap-2">
                  <ToggleHeading2 className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Toggle heading 2</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto('toggle_h3')} className="gap-2">
                  <ToggleHeading3 className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Toggle heading 3</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto(KEYS.callout)} className="gap-2">
                  <Lightbulb className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Callout</span>
                </ContextMenuItem>
                <ContextMenuItem onClick={() => handleTurnInto(KEYS.codeBlock)} className="gap-2">
                  <FileCode2 className="h-3.5 w-3.5 text-zinc-400" />
                  <span>Code block</span>
                </ContextMenuItem>
              </ContextMenuSubContent>
            </ContextMenuSub>

            {/* Color submenu */}
            <ContextMenuSub>
              <ContextMenuSubTrigger className="gap-2">
                <Palette className="h-3.5 w-3.5 text-zinc-400" />
                <span>Color</span>
              </ContextMenuSubTrigger>
              <ContextMenuSubContent className="w-48">
                <div className="px-2 py-1 text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">
                  Text color
                </div>
                {[
                  { label: 'Default', value: '' },
                  { label: 'Gray', value: '#a1a1aa' },
                  { label: 'Red', value: '#f87171' },
                  { label: 'Amber', value: '#fbbf24' },
                  { label: 'Lime', value: '#a3e635' },
                  { label: 'Emerald', value: '#34d399' },
                  { label: 'Sky', value: '#38bdf8' },
                  { label: 'Purple', value: '#c084fc' },
                ].map((c) => (
                  <ContextMenuItem
                    key={c.label}
                    onClick={() => handleApplyColor(c.value)}
                    className="gap-2 text-xs py-1"
                    style={{ color: c.value || undefined }}
                  >
                    <span
                      className="h-2 w-2 rounded-full border border-zinc-700"
                      style={{ backgroundColor: c.value || 'currentColor' }}
                    />
                    <span>{c.label}</span>
                  </ContextMenuItem>
                ))}

                <ContextMenuSeparator />

                <div className="px-2 py-1 text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">
                  Background
                </div>
                {[
                  { label: 'None', value: '' },
                  { label: 'Gray', value: 'rgba(161, 161, 170, 0.2)' },
                  { label: 'Red', value: 'rgba(239, 68, 68, 0.2)' },
                  { label: 'Amber', value: 'rgba(245, 158, 11, 0.2)' },
                  { label: 'Lime', value: 'rgba(163, 230, 53, 0.2)' },
                  { label: 'Sky', value: 'rgba(14, 165, 233, 0.2)' },
                  { label: 'Purple', value: 'rgba(168, 85, 247, 0.2)' },
                ].map((bg) => (
                  <ContextMenuItem
                    key={bg.label}
                    onClick={() => handleApplyBgColor(bg.value)}
                    className="gap-2 text-xs py-1"
                  >
                    <span
                      className="h-2 w-2 rounded-full border border-zinc-700"
                      style={{ backgroundColor: bg.value || 'transparent' }}
                    />
                    <span>{bg.label}</span>
                  </ContextMenuItem>
                ))}
              </ContextMenuSubContent>
            </ContextMenuSub>

            <ContextMenuSeparator />

            {hasToggleTarget && (
              <ContextMenuItem onClick={handleUnwrap} className="gap-2">
                <FolderOpen className="h-3.5 w-3.5 text-zinc-400" />
                <span>Unwrap toggle</span>
              </ContextMenuItem>
            )}

            <ContextMenuItem onClick={handleDuplicate} className="gap-2">
              <Copy className="h-3.5 w-3.5 text-zinc-400" />
              <span>Duplicate</span>
            </ContextMenuItem>

            <ContextMenuItem
              onClick={handleDelete}
              className="gap-2 text-red-400 focus:text-red-300"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>Delete</span>
            </ContextMenuItem>
          </ContextMenuGroup>

          <ContextMenuSeparator />

          <ContextMenuGroup>
            <ContextMenuItem onClick={handleIndent} className="gap-2">
              <Indent className="h-3.5 w-3.5 text-zinc-400" />
              <span>Indent</span>
            </ContextMenuItem>
            <ContextMenuItem onClick={handleOutdent} className="gap-2">
              <Outdent className="h-3.5 w-3.5 text-zinc-400" />
              <span>Outdent</span>
            </ContextMenuItem>
          </ContextMenuGroup>
        </ContextMenuContent>
      )}
    </ContextMenu>
  );
}
