'use client';

import { cn } from '@xpace/ui';
import type { PlateLeafProps } from 'platejs/react';
import { PlateLeaf } from 'platejs/react';

export function SuggestionLeaf(props: PlateLeafProps) {
  const type =
    (props.leaf?.suggestionType as string) || (props.leaf?.type as string) || 'insertion';
  const isDeletion = type === 'deletion';

  return (
    <PlateLeaf
      {...props}
      className={cn(
        isDeletion
          ? 'bg-red-400/15 text-red-300 line-through decoration-red-400/80 cursor-pointer'
          : 'bg-lime-400/15 text-lime-300 underline decoration-lime-400/80 cursor-pointer',
        props.className,
      )}
    >
      {props.children}
    </PlateLeaf>
  );
}
