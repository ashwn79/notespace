'use client';

import { isOrderedList } from '@platejs/list';
import { useTodoListElement, useTodoListElementState } from '@platejs/list/react';
import { Checkbox, cn } from '@xpace/ui';
import type { TListElement } from 'platejs';
import type { PlateElementProps, RenderNodeWrapper } from 'platejs/react';
import { useReadOnly } from 'platejs/react';
import type React from 'react';

const config: Record<
  string,
  {
    Li: React.FC<PlateElementProps>;
    Marker: React.FC<PlateElementProps>;
  }
> = {
  todo: {
    Li: TodoLi,
    Marker: TodoMarker,
  },
};

export const BlockList: RenderNodeWrapper = (props) => {
  if (!props.element.listStyleType) return;
  if (!isOrderedList(props.element)) return;

  return (hocProps) => <ListWrapper {...hocProps} />;
};

function ListWrapper(props: PlateElementProps) {
  const { listStart, listStyleType } = props.element as TListElement;
  const { Li, Marker } = config[listStyleType as string] ?? {};
  const ListTag = isOrderedList(props.element) ? 'ol' : 'ul';

  return (
    <ListTag className="relative m-0 p-0" start={listStart} style={{ listStyleType }}>
      {Marker && <Marker {...props} />}
      {Li ? <Li {...props} /> : <li>{props.children}</li>}
    </ListTag>
  );
}

function TodoMarker(props: PlateElementProps) {
  const state = useTodoListElementState({ element: props.element });
  const { checkboxProps } = useTodoListElement(state);
  const readOnly = useReadOnly();

  return (
    <div contentEditable={false}>
      <Checkbox
        className={cn(
          'absolute top-1 -left-6 border-zinc-700 data-[state=checked]:bg-lime-400 data-[state=checked]:border-lime-400 data-[state=checked]:text-zinc-950',
          readOnly && 'pointer-events-none',
        )}
        {...checkboxProps}
      />
    </div>
  );
}

function TodoLi(props: PlateElementProps) {
  return (
    <li
      className={cn(
        'list-none',
        Boolean(props.element.checked) && 'text-muted-foreground line-through opacity-70',
      )}
    >
      {props.children}
    </li>
  );
}
