'use client';

import {
  flip,
  offset,
  shift,
  useFloatingToolbar,
  useFloatingToolbarState,
} from '@platejs/floating';
import { isInClosedToggle } from '@platejs/toggle/react';
import { cn } from '@xpace/ui';
import { KEYS, RangeApi } from 'platejs';
import {
  useEditorId,
  useEditorSelector,
  useEventEditorValue,
  usePluginOption,
} from 'platejs/react';
import type React from 'react';
import { FloatingToolbarButtons } from './floating-toolbar-buttons';

export function FloatingToolbar({
  children,
  className,
}: {
  children?: React.ReactNode;
  className?: string;
}) {
  const editorId = useEditorId();
  const focusedEditorId = useEventEditorValue('focus');
  const isFloatingLinkOpen = Boolean(usePluginOption({ key: KEYS.link }, 'mode'));
  const isAIChatOpen = Boolean(usePluginOption({ key: KEYS.aiChat }, 'open'));

  const isCollapsedOrNone = useEditorSelector((ed) => {
    return !ed.selection || RangeApi.isCollapsed(ed.selection);
  }, []);

  const isSelectionInClosedToggle = useEditorSelector((ed) => {
    if (!ed.selection) return false;
    const block = ed.api.block();
    if (!block) return false;
    try {
      return isInClosedToggle(ed, block[0].id as string);
    } catch {
      return false;
    }
  }, []);

  const floatingToolbarState = useFloatingToolbarState({
    editorId,
    focusedEditorId,
    hideToolbar:
      isFloatingLinkOpen || isAIChatOpen || isSelectionInClosedToggle || isCollapsedOrNone,
    floatingOptions: {
      middleware: [
        offset(10),
        flip({
          fallbackPlacements: ['top-start', 'top-end', 'bottom-start', 'bottom-end'],
          padding: 12,
        }),
        shift({ padding: 12 }),
      ],
      placement: 'top',
    },
  });

  const {
    clickOutsideRef,
    hidden,
    props: rootProps,
    ref: floatingRef,
  } = useFloatingToolbar(floatingToolbarState);

  if (hidden || isCollapsedOrNone) return null;

  return (
    <div ref={clickOutsideRef}>
      <div
        ref={floatingRef}
        {...rootProps}
        data-plate-prevent-deselect
        className={cn(
          'absolute z-50 rounded-2xl border border-[#333333] bg-[#202020] p-1.5 shadow-2xl backdrop-blur-xl animate-in fade-in zoom-in-95 duration-100',
          className,
        )}
      >
        {children || <FloatingToolbarButtons />}
      </div>
    </div>
  );
}
