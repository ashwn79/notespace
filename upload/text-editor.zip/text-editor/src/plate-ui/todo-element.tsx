import { Checkbox, cn } from '@xpace/ui';
import { PlateElement, type PlateElementProps, useEditorRef } from 'platejs/react';

export function TodoElement({ className, children, ...props }: PlateElementProps) {
  const editor = useEditorRef();
  const checked = Boolean(props.element.checked);

  const handleCheckedChange = (isChecked: boolean) => {
    const path = editor.api.findPath(props.element);
    if (path) {
      editor.tf.setNodes({ checked: isChecked }, { at: path });
    }
  };

  return (
    <PlateElement className={cn('flex items-start gap-2.5 py-1', className)} {...props}>
      {/* biome-ignore lint/a11y/noStaticElementInteractions: preventDefault keeps Slate focus for undo/redo */}
      <div
        contentEditable={false}
        className="pt-0.5 select-none"
        onMouseDown={(e) => e.preventDefault()}
      >
        <Checkbox
          checked={checked}
          onCheckedChange={handleCheckedChange}
          className="h-4 w-4 rounded data-[state=checked]:bg-primary data-[state=checked]:border-primary cursor-pointer"
        />
      </div>
      <div
        className={cn(
          'flex-1 text-foreground transition-all leading-relaxed',
          checked && 'line-through text-muted-foreground opacity-60',
        )}
      >
        {children}
      </div>
    </PlateElement>
  );
}
