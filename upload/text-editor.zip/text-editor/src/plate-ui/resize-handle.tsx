'use client';

import { ResizeHandle as ResizeHandlePrimitive, type ResizeHandleProps } from '@platejs/resizable';
import { cn } from '@xpace/ui';

export function ResizeHandle({ className, options, ...props }: ResizeHandleProps) {
  const isLeft = options?.direction === 'left';

  return (
    <ResizeHandlePrimitive
      options={options}
      className={cn(
        'absolute top-0 z-30 flex h-full w-4 select-none items-center justify-center opacity-0 group-hover/media:opacity-100 transition-opacity',
        isLeft ? '-left-2 cursor-ew-resize' : '-right-2 cursor-ew-resize',
        className,
      )}
      {...props}
    >
      <div className="pointer-events-none h-8 w-1 rounded-full bg-lime-400 shadow-md ring-1 ring-black/40" />
    </ResizeHandlePrimitive>
  );
}
