import { cn } from '@xpace/ui';
import { PlateElement, type PlateElementProps } from 'platejs/react';

export function DividerElement({ className, children, ...props }: PlateElementProps) {
  return (
    <PlateElement className={cn('my-4 cursor-default py-1 select-none', className)} {...props}>
      <div contentEditable={false} className="h-px w-full bg-border" />
      {children}
    </PlateElement>
  );
}
