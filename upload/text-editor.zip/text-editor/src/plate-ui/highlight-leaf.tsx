'use client';

import { cn } from '@xpace/ui';
import type { PlateLeafProps } from 'platejs/react';
import { PlateLeaf } from 'platejs/react';

export function HighlightLeaf({ className, children, ...props }: PlateLeafProps) {
  const customBg = (props.leaf as { backgroundColor?: string })?.backgroundColor;
  return (
    <PlateLeaf
      as="mark"
      className={cn(
        'rounded-xs px-0.5 font-normal',
        !customBg && 'bg-yellow-500/25 text-yellow-200',
        className,
      )}
      style={{
        ...(customBg ? { backgroundColor: customBg } : {}),
        ...props.style,
      }}
      {...props}
    >
      {children}
    </PlateLeaf>
  );
}
