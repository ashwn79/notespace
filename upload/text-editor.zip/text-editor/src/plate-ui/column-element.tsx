'use client';

import { Trash2 } from '@xpace/icons';
import { Button, cn } from '@xpace/ui';
import { Columns2, Columns3 } from 'lucide-react';
import type { TElement } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
import {
  PlateElement,
  useEditorRef,
  useFocusedLast,
  useReadOnly,
  useSelected,
} from 'platejs/react';

export function ColumnGroupElement({ children, className, element, ...props }: PlateElementProps) {
  const editor = useEditorRef();
  const readOnly = useReadOnly();
  const selected = useSelected();
  const isFocusedLast = useFocusedLast();

  const showToolbar = !readOnly && selected && isFocusedLast;

  const setColumns = (widths: string[]) => {
    const children = (element.children as TElement[]) || [];
    editor.tf.withoutNormalizing(() => {
      children.forEach((child, index) => {
        const path = editor.api.findPath(child);
        if (path && widths[index]) {
          editor.tf.setNodes({ width: widths[index] }, { at: path });
        }
      });
    });
  };

  const handleDelete = () => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.removeNodes({ at: path });
    }
  };

  return (
    <PlateElement
      element={element}
      className={cn('relative my-3 rounded-xl transition-all', className)}
      {...props}
    >
      {showToolbar && (
        <div
          contentEditable={false}
          className="absolute -top-9 left-1/2 -translate-x-1/2 z-30 flex items-center gap-1 rounded-xl border border-zinc-800 bg-zinc-950/95 p-1 shadow-2xl backdrop-blur-md animate-in fade-in zoom-in-95 duration-100"
        >
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => setColumns(['50%', '50%'])}
            className="h-6 px-1.5 text-[11px] gap-1 text-zinc-300 hover:text-white"
          >
            <Columns2 className="h-3 w-3" />
            <span>2 Col</span>
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => setColumns(['33.33%', '33.33%', '33.33%'])}
            className="h-6 px-1.5 text-[11px] gap-1 text-zinc-300 hover:text-white"
          >
            <Columns3 className="h-3 w-3" />
            <span>3 Col</span>
          </Button>
          <div className="h-3.5 w-px bg-zinc-800 mx-0.5" />
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={handleDelete}
            className="h-6 px-1.5 text-[11px] text-red-400 hover:bg-red-500/10"
            title="Delete column group"
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      )}

      <div className="flex w-full items-stretch gap-4">{children}</div>
    </PlateElement>
  );
}

export function ColumnElement({ children, className, element, ...props }: PlateElementProps) {
  const readOnly = useReadOnly();
  const width = (element.width as string) || '100%';

  return (
    <div className="relative group/column flex-1 min-w-0" style={{ width }}>
      <PlateElement
        element={element}
        className={cn(
          'h-full rounded-lg p-2 transition-colors',
          !readOnly && 'border border-dashed border-zinc-800/60 hover:border-zinc-700/80',
          className,
        )}
        {...props}
      >
        <div className="min-w-0 flex-1">{children}</div>
      </PlateElement>
    </div>
  );
}
