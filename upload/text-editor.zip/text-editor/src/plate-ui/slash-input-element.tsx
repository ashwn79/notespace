'use client';

import type { TComboboxInputElement } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement } from 'platejs/react';
import * as React from 'react';
import { EDITOR_COMMANDS } from '../commands/command-registry';
import type { CommandGroup } from '../types/command';
import {
  defaultFilter,
  InlineCombobox,
  InlineComboboxContent,
  InlineComboboxEmpty,
  InlineComboboxGroup,
  InlineComboboxGroupLabel,
  InlineComboboxInput,
  InlineComboboxItem,
} from './inline-combobox';

const GROUP_LABELS: Record<CommandGroup, string> = {
  ai: 'AI Assistance',
  basic: 'Basic Blocks',
  lists: 'Lists',
  media: 'Media',
  advanced: 'Advanced Blocks',
  inline: 'Inline Items',
};

const GROUPS_ORDER: CommandGroup[] = ['ai', 'basic', 'lists', 'media', 'advanced', 'inline'];

export function SlashInputElement(props: PlateElementProps<TComboboxInputElement>) {
  const { editor, element } = props;
  const [value, setValue] = React.useState('');

  return (
    <PlateElement {...props} as="span">
      <InlineCombobox element={element} trigger="/" value={value} setValue={setValue}>
        <InlineComboboxInput />

        <InlineComboboxContent className="w-64">
          <InlineComboboxEmpty>No results</InlineComboboxEmpty>

          {GROUPS_ORDER.map((groupKey) => {
            const groupCommands = EDITOR_COMMANDS.filter((cmd) => cmd.group === groupKey);
            if (groupCommands.length === 0) return null;

            const filteredCommands = groupCommands.filter((cmd) =>
              defaultFilter(
                {
                  value: cmd.key,
                  label: cmd.label,
                  keywords: cmd.keywords,
                  group: GROUP_LABELS[groupKey],
                },
                value,
              ),
            );
            if (filteredCommands.length === 0) return null;

            return (
              <InlineComboboxGroup key={groupKey}>
                <InlineComboboxGroupLabel>{GROUP_LABELS[groupKey]}</InlineComboboxGroupLabel>

                {filteredCommands.map((cmd) => (
                  <InlineComboboxItem
                    key={cmd.key}
                    value={cmd.key}
                    label={cmd.label}
                    keywords={cmd.keywords}
                    group={GROUP_LABELS[groupKey]}
                    focusEditor={cmd.focusEditor ?? true}
                    onClick={() => {
                      cmd.execute(editor);
                    }}
                    className="gap-2.5"
                  >
                    <div className="flex h-5 w-5 shrink-0 items-center justify-center text-zinc-300">
                      {cmd.icon}
                    </div>
                    <span className="font-medium text-white truncate">{cmd.label}</span>
                    {cmd.shortcut && (
                      <span className="ml-auto text-[11px] font-mono text-zinc-500 select-none pl-2">
                        {cmd.shortcut}
                      </span>
                    )}
                  </InlineComboboxItem>
                ))}
              </InlineComboboxGroup>
            );
          })}
        </InlineComboboxContent>
      </InlineCombobox>
      {props.children}
    </PlateElement>
  );
}
