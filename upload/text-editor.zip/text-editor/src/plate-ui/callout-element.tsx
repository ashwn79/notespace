'use client';

import { cn } from '@xpace/ui';
import { AlertCircle, AlertTriangle, CheckCircle2, Info, Lightbulb } from 'lucide-react';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement, useEditorRef } from 'platejs/react';
import * as React from 'react';
import { EmojiPicker } from './emoji-picker';
import { Popover, PopoverContent, PopoverTrigger } from './popover';

type CalloutVariantStyle = {
  border: string;
  bg: string;
  text: string;
  iconBg: string;
  iconColor: string;
  defaultIcon: React.ReactNode;
};

const DEFAULT_VARIANT: CalloutVariantStyle = {
  border: 'border-zinc-800/80 focus-within:border-zinc-700',
  bg: 'bg-zinc-900/40',
  text: 'text-foreground/90',
  iconBg: 'bg-zinc-800/80',
  iconColor: 'text-lime-400',
  defaultIcon: <Lightbulb className="h-4 w-4" />,
};

const CALLOUT_VARIANTS: Record<string, CalloutVariantStyle> = {
  default: DEFAULT_VARIANT,
  info: {
    border: 'border-sky-800/60 focus-within:border-sky-600',
    bg: 'bg-sky-950/20',
    text: 'text-sky-100',
    iconBg: 'bg-sky-900/40',
    iconColor: 'text-sky-400',
    defaultIcon: <Info className="h-4 w-4" />,
  },
  tip: {
    border: 'border-teal-800/60 focus-within:border-teal-600',
    bg: 'bg-teal-950/20',
    text: 'text-teal-100',
    iconBg: 'bg-teal-900/40',
    iconColor: 'text-teal-400',
    defaultIcon: <Lightbulb className="h-4 w-4" />,
  },
  warning: {
    border: 'border-amber-800/60 focus-within:border-amber-600',
    bg: 'bg-amber-950/20',
    text: 'text-amber-100',
    iconBg: 'bg-amber-900/40',
    iconColor: 'text-amber-400',
    defaultIcon: <AlertTriangle className="h-4 w-4" />,
  },
  success: {
    border: 'border-emerald-800/60 focus-within:border-emerald-600',
    bg: 'bg-emerald-950/20',
    text: 'text-emerald-100',
    iconBg: 'bg-emerald-900/40',
    iconColor: 'text-emerald-400',
    defaultIcon: <CheckCircle2 className="h-4 w-4" />,
  },
  error: {
    border: 'border-red-800/60 focus-within:border-red-600',
    bg: 'bg-red-950/20',
    text: 'text-red-100',
    iconBg: 'bg-red-900/40',
    iconColor: 'text-red-400',
    defaultIcon: <AlertCircle className="h-4 w-4" />,
  },
  danger: {
    border: 'border-red-800/60 focus-within:border-red-600',
    bg: 'bg-red-950/20',
    text: 'text-red-100',
    iconBg: 'bg-red-900/40',
    iconColor: 'text-red-400',
    defaultIcon: <AlertCircle className="h-4 w-4" />,
  },
  custom: {
    border: 'border-purple-800/60 focus-within:border-purple-600',
    bg: 'bg-purple-950/20',
    text: 'text-purple-100',
    iconBg: 'bg-purple-900/40',
    iconColor: 'text-purple-400',
    defaultIcon: <Lightbulb className="h-4 w-4" />,
  },
};

export function CalloutElement({ children, className, element, ...props }: PlateElementProps) {
  const editor = useEditorRef();
  const [open, setOpen] = React.useState(false);

  const variantKey = (element.variant as string) || 'default';
  const variant: CalloutVariantStyle = CALLOUT_VARIANTS[variantKey] ?? DEFAULT_VARIANT;
  const icon = (element.icon as string) || null;

  const updateCallout = (updates: { icon?: string; variant?: string }) => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.setNodes(updates, { at: path });
    }
    setOpen(false);
  };

  return (
    <PlateElement
      element={element}
      className={cn(
        'group relative my-2 flex items-start gap-3 rounded-xl border p-3.5 transition-colors',
        variant.border,
        variant.bg,
        className,
      )}
      {...props}
    >
      <div contentEditable={false} className="shrink-0 select-none">
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>
            <button
              type="button"
              className={cn(
                'flex h-6 w-6 cursor-pointer items-center justify-center rounded-md text-sm font-medium transition-transform hover:scale-105',
                variant.iconBg,
                variant.iconColor,
              )}
              title="Change icon & variant"
            >
              {icon ? <span>{icon}</span> : variant.defaultIcon}
            </button>
          </PopoverTrigger>
          <PopoverContent
            align="start"
            className="w-68 p-2 z-50 bg-zinc-950/95 border-zinc-800 shadow-2xl backdrop-blur-md"
          >
            <div className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider mb-1.5">
              Variant
            </div>
            <div className="flex items-center gap-1 mb-2">
              {Object.keys(CALLOUT_VARIANTS).map((vKey) => (
                <button
                  type="button"
                  key={vKey}
                  onClick={() => updateCallout({ variant: vKey })}
                  className={cn(
                    'h-6 flex-1 rounded text-xs capitalize transition-colors border',
                    variantKey === vKey
                      ? 'border-primary bg-primary/20 text-white font-medium'
                      : 'border-zinc-800 hover:bg-zinc-800 text-zinc-400',
                  )}
                >
                  {vKey[0]?.toUpperCase()}
                </button>
              ))}
            </div>

            <div className="h-px bg-zinc-800/80 my-1" />

            <EmojiPicker
              onSelectEmoji={(emojiChar) => updateCallout({ icon: emojiChar })}
              className="p-0 w-full"
            />

            <div className="flex items-center justify-between text-[11px] text-zinc-400 mt-2 pt-2 border-t border-zinc-800 px-1">
              <button
                type="button"
                onClick={() => updateCallout({ icon: 'none' })}
                className="hover:text-white transition-colors text-[11px]"
              >
                No icon
              </button>
              <button
                type="button"
                onClick={() => updateCallout({ icon: undefined })}
                className="hover:text-white transition-colors text-[11px]"
              >
                Reset icon
              </button>
            </div>
          </PopoverContent>
        </Popover>
      </div>
      <div className={cn('min-w-0 flex-1 text-sm leading-relaxed', variant.text)}>{children}</div>
    </PlateElement>
  );
}
