'use client';

import {
  flip,
  offset,
  shift,
  useFloatingToolbar,
  useFloatingToolbarState,
} from '@platejs/floating';
import { Check, Copy, Edit, ExternalLink, Link as LinkIcon, Unlink, X } from '@xpace/icons';
import { Button } from '@xpace/ui';
import { KEYS } from 'platejs';
import { useEditorId, useEditorRef, useEventEditorValue, usePluginOption } from 'platejs/react';
import * as React from 'react';

function sanitizeUrl(rawUrl: string): string | null {
  const trimmed = rawUrl.trim();
  if (!trimmed) return null;
  if (/^javascript:/i.test(trimmed)) return null;
  if (/^(https?:\/\/|mailto:)/i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

export function LinkFloatingToolbar() {
  const editor = useEditorRef();
  const editorId = useEditorId();
  const focusedEditorId = useEventEditorValue('focus');

  const mode = usePluginOption({ key: KEYS.link }, 'mode') as string | undefined;
  const isLinkActive = Boolean(editor?.api?.some?.({ match: { type: 'a' } }));
  const isOpen = Boolean(mode || isLinkActive);

  const [isEditing, setIsEditing] = React.useState(Boolean(mode));
  const [urlInput, setUrlInput] = React.useState('');
  const [copied, setCopied] = React.useState(false);
  const inputRef = React.useRef<HTMLInputElement | null>(null);

  // Get current active link node if any
  const linkEntry = editor?.api?.node?.({ match: { type: 'a' } });
  const currentUrl = (linkEntry?.[0]?.url as string) || '';

  React.useEffect(() => {
    if (mode === 'insert' || mode === 'edit') {
      setIsEditing(true);
      setUrlInput(currentUrl);
      setTimeout(() => {
        inputRef.current?.focus({ preventScroll: true });
      }, 0);
    } else if (isLinkActive) {
      setUrlInput(currentUrl);
    }
  }, [mode, isLinkActive, currentUrl]);

  const floatingState = useFloatingToolbarState({
    editorId,
    focusedEditorId,
    hideToolbar: !isOpen,
    floatingOptions: {
      middleware: [
        offset(8),
        flip({
          fallbackPlacements: ['bottom-start', 'top-start'],
          padding: 8,
        }),
        shift({ padding: 8 }),
      ],
      placement: 'bottom-start',
    },
  });

  const {
    clickOutsideRef,
    hidden,
    props: rootProps,
    ref: floatingRef,
  } = useFloatingToolbar(floatingState);

  if (hidden || !isOpen) return null;

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const cleanUrl = sanitizeUrl(urlInput);
    if (!cleanUrl) return;

    if (linkEntry) {
      editor.tf.setNodes({ url: cleanUrl }, { at: linkEntry[1] });
    } else if (editor.selection) {
      editor.tf.wrapNodes(
        { type: 'a', url: cleanUrl, children: [] },
        { at: editor.selection, split: true },
      );
    }

    editor.setOption?.({ key: KEYS.link }, 'mode', '');
    setIsEditing(false);
    editor.tf.focus();
  };

  const handleUnlink = () => {
    editor.tf.unwrapNodes({ match: (n) => n.type === 'a' });
    editor.setOption?.({ key: KEYS.link }, 'mode', '');
    setIsEditing(false);
    editor.tf.focus();
  };

  const handleCopy = () => {
    if (currentUrl) {
      navigator.clipboard?.writeText(currentUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleClose = () => {
    editor.setOption?.({ key: KEYS.link }, 'mode', '');
    setIsEditing(false);
  };

  return (
    <div ref={clickOutsideRef}>
      <div
        ref={floatingRef}
        {...rootProps}
        className="absolute z-50 flex items-center rounded-xl border border-zinc-800 bg-zinc-950/95 p-1 shadow-2xl backdrop-blur-md animate-in fade-in zoom-in-95 duration-100"
      >
        {isEditing ? (
          <form onSubmit={handleSubmit} className="flex items-center gap-1.5 px-1 py-0.5">
            <LinkIcon className="h-3.5 w-3.5 text-zinc-400 ml-1 shrink-0" />
            <input
              ref={inputRef}
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  e.preventDefault();
                  handleClose();
                }
              }}
              placeholder="Paste or type URL (e.g. https://...)"
              className="h-7 w-56 rounded-md bg-zinc-900 px-2 text-xs text-zinc-200 outline-hidden placeholder:text-zinc-600 focus:ring-1 focus:ring-primary"
            />
            <Button
              type="submit"
              size="sm"
              variant="ghost"
              className="h-7 w-7 p-0 text-lime-400 hover:bg-zinc-800"
            >
              <Check className="h-3.5 w-3.5" />
            </Button>
            <Button
              type="button"
              size="sm"
              variant="ghost"
              onClick={handleClose}
              className="h-7 w-7 p-0 text-zinc-400 hover:bg-zinc-800"
            >
              <X className="h-3.5 w-3.5" />
            </Button>
          </form>
        ) : (
          <div className="flex items-center gap-0.5 px-1 py-0.5">
            <a
              href={currentUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 max-w-[200px] truncate px-2 py-1 text-xs text-sky-400 hover:underline"
              title={currentUrl}
            >
              <span className="truncate">{currentUrl}</span>
              <ExternalLink className="h-3 w-3 shrink-0 opacity-70" />
            </a>

            <div className="h-4 w-px bg-zinc-800 mx-0.5" />

            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => setIsEditing(true)}
              className="h-7 w-7 p-0 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
              title="Edit link"
            >
              <Edit className="h-3.5 w-3.5" />
            </Button>

            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleCopy}
              className="h-7 w-7 p-0 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800"
              title="Copy URL"
            >
              {copied ? (
                <Check className="h-3.5 w-3.5 text-lime-400" />
              ) : (
                <Copy className="h-3.5 w-3.5" />
              )}
            </Button>

            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleUnlink}
              className="h-7 w-7 p-0 text-red-400 hover:text-red-300 hover:bg-zinc-800"
              title="Remove link"
            >
              <Unlink className="h-3.5 w-3.5" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
