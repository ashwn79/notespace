'use client';

import { DndPlugin, useDraggable, useDropLine } from '@platejs/dnd';
import {
  BLOCK_CONTEXT_MENU_ID,
  BlockMenuPlugin,
  BlockSelectionPlugin,
  useBlockSelected,
} from '@platejs/selection/react';
import { TogglePlugin, useIsVisible } from '@platejs/toggle/react';
import { GripVertical, Plus } from '@xpace/icons';
import {
  cn,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@xpace/ui';
import { getPluginByType, isType, KEYS, type TElement } from 'platejs';
import type { PlateEditor, PlateElementProps, RenderNodeWrapper } from 'platejs/react';
import {
  MemoizedChildren,
  useEditorRef,
  useElement,
  usePluginOption,
  useSelected,
} from 'platejs/react';
import * as React from 'react';
import { BASIC_COMMANDS } from '../commands/command-registry';
import { expandSelectionNodesWithChildren, getEffectiveIndentOffset } from './toggle-utils';

const UNDRAGGABLE_KEYS = [KEYS.column, KEYS.tr, KEYS.td, KEYS.codeLine];

export const BlockDraggable: RenderNodeWrapper = (props) => {
  const { editor, element, path } = props;

  const enabled = React.useMemo(() => {
    if (editor.dom?.readOnly) return false;

    if (path.length === 1 && !isType(editor, element, UNDRAGGABLE_KEYS)) {
      return true;
    }
    if (path.length === 3 && !isType(editor, element, UNDRAGGABLE_KEYS)) {
      const block = editor.api.some({
        at: path,
        match: {
          type: editor.getType(KEYS.column),
        },
      });

      if (block) {
        return true;
      }
    }

    return false;
  }, [editor, element, path]);

  if (!enabled) return;

  return (hocProps) => <Draggable {...hocProps} />;
};

function Draggable(props: PlateElementProps) {
  const { children, editor, element, path } = props;
  const isVisible = useIsVisible(element.id as string);
  const isBlockSelected = useBlockSelected(element.id as string);
  const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;

  const isInColumn = path.length === 3;
  const [previewTop, setPreviewTop] = React.useState(0);
  const [dragButtonTop, setDragButtonTop] = React.useState(0);

  const { isAboutToDrag, isDragging, nodeRef, previewRef, handleRef } = useDraggable({
    element,
    onDropHandler: (currentEditor, { dragItem }) => {
      const id = (dragItem as { id: string[] | string }).id;

      if (blockSelectionApi) {
        blockSelectionApi.add(id);
      }
      if (previewRef.current) {
        previewRef.current.replaceChildren();
        previewRef.current?.classList.add('hidden');
      }

      // Calculate target indent based on drop target and direction
      const dropTarget = currentEditor.getOptions(DndPlugin).dropTarget;
      const line = dropTarget?.id === element.id ? dropTarget?.line : undefined;
      const currentElementIndent = (element.indent as number) || 0;
      const isToggle = element.type === KEYS.toggle;
      const isContainer = element.type === KEYS.callout || isToggle;

      let targetIndent = currentElementIndent;
      if (line === 'bottom') {
        if (isContainer) {
          targetIndent = currentElementIndent + 1;
          if (isToggle) {
            currentEditor.getApi(TogglePlugin)?.toggle?.toggleIds?.([element.id as string], true);
          }
        } else {
          targetIndent = currentElementIndent;
        }
      } else if (line === 'top') {
        targetIndent = currentElementIndent;
      }

      const draggedIds = Array.isArray(id) ? id : [id];
      const draggedEntries = draggedIds
        .map((dragId) => currentEditor.api.node<TElement>({ id: dragId, at: [] }))
        .filter((entry): entry is [TElement, any] => !!entry && !!entry[0]);

      if (draggedEntries.length > 0) {
        const minIndent = Math.min(...draggedEntries.map(([n]) => (n.indent as number) || 0));

        // Pre-set indent before move
        currentEditor.tf.withoutNormalizing(() => {
          draggedEntries.forEach(([node, p]) => {
            const desiredIndent = Math.max(
              0,
              targetIndent + (((node.indent as number) || 0) - minIndent),
            );
            if (desiredIndent === 0) {
              currentEditor.tf.unsetNodes('indent', { at: p });
            } else {
              currentEditor.tf.setNodes({ indent: desiredIndent }, { at: p });
            }
          });
        });

        // Post-move safety check in microtask
        queueMicrotask(() => {
          draggedIds.forEach((dragId) => {
            const entry = currentEditor.api.node<TElement>({ id: dragId, at: [] });
            if (entry) {
              const [node, p] = entry;
              const desiredIndent = Math.max(
                0,
                targetIndent + (((node.indent as number) || 0) - minIndent),
              );
              if ((node.indent || 0) !== desiredIndent) {
                if (desiredIndent === 0) {
                  currentEditor.tf.unsetNodes('indent', { at: p });
                } else {
                  currentEditor.tf.setNodes({ indent: desiredIndent }, { at: p });
                }
              }
            }
          });
        });
      }
    },
  });

  const resetPreview = React.useCallback(() => {
    if (previewRef.current) {
      previewRef.current.replaceChildren();
      previewRef.current?.classList.add('hidden');
    }
  }, [previewRef]);

  React.useEffect(() => {
    if (!isDragging) {
      resetPreview();
    }
  }, [isDragging, resetPreview]);

  React.useEffect(() => {
    if (isAboutToDrag) {
      previewRef.current?.classList.remove('opacity-0');
    }
  }, [isAboutToDrag, previewRef]);

  if (!isVisible) {
    return <div style={{ display: 'none' }}>{children}</div>;
  }

  return (
    // biome-ignore lint/a11y/noStaticElementInteractions: Mouse enter tracks gutter button vertical alignment
    <div
      className={cn(
        'relative group/block my-0.5 rounded-md transition-colors',
        isDragging && 'opacity-40',
        isBlockSelected && 'bg-lime-500/10 ring-1 ring-lime-500/30 rounded-lg',
        getPluginByType(editor, element.type)?.node.isContainer ? 'group/container' : 'group/block',
      )}
      onMouseEnter={() => {
        if (isDragging) return;
        setDragButtonTop(calcDragButtonTop(editor, element));
      }}
    >
      <Gutter isBlockSelected={isBlockSelected}>
        <div
          className={cn(
            'slate-blockToolbarWrapper',
            'flex h-[1.5em] items-center gap-0.5',
            isInColumn && 'h-4',
          )}
          style={{ marginTop: `${dragButtonTop}px` }}
        >
          {/* 1. Plus Button: Insert Block Below */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                data-testid="block-gutter-plus"
                aria-label="Add block below"
                onMouseDown={(e) => e.stopPropagation()}
                className="flex h-5 w-5 items-center justify-center rounded text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
              >
                <Plus className="h-3.5 w-3.5 text-lime-400" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              align="start"
              side="bottom"
              sideOffset={4}
              className="w-56 max-h-72 overflow-y-auto z-50 p-1"
            >
              <div className="px-2 py-1 text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">
                Insert Block Below
              </div>
              {BASIC_COMMANDS.map((cmd) => (
                <DropdownMenuItem
                  key={cmd.key}
                  onClick={() => {
                    cmd.execute(editor, { element, insertAfter: true });
                  }}
                  className="gap-2 text-xs py-1.5"
                >
                  <div className="flex h-5 w-5 items-center justify-center rounded bg-zinc-800 text-zinc-300">
                    {cmd.icon}
                  </div>
                  <span className="font-medium text-white">{cmd.label}</span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* 2. Drag Handle & Block Context Menu Trigger */}
          <div
            className={cn(
              'slate-blockToolbar relative w-5',
              'pointer-events-auto flex items-center',
              isInColumn && 'mr-1.5',
            )}
          >
            <DragHandle
              element={element}
              handleRef={handleRef}
              isDragging={isDragging}
              previewRef={previewRef}
              resetPreview={resetPreview}
              setPreviewTop={setPreviewTop}
              top={dragButtonTop}
            />
          </div>
        </div>
      </Gutter>

      {/* Virtual Multiple Drag Preview */}
      <div
        className={cn('absolute -left-0 hidden w-full')}
        contentEditable={false}
        ref={previewRef}
        style={{ top: `${-previewTop}px` }}
      />

      {/* Block Content Wrapper with Drop Target & DropLine */}
      {/* biome-ignore lint/a11y/noStaticElementInteractions: Radix context menu trigger handler for slate block */}
      <div
        className="slate-blockWrapper flow-root relative"
        onContextMenu={(event) => {
          const api = editor.getApi(BlockSelectionPlugin);
          if (api?.blockSelection?.addOnContextMenu) {
            api.blockSelection.addOnContextMenu({ element, event });
          }
        }}
        ref={nodeRef}
      >
        {/* Hover indentation guides (Feature 54) */}
        {((element.indent as number) || 0) > 0 && (
          <div className="absolute inset-y-0 left-0 pointer-events-none select-none z-0">
            {Array.from({ length: (element.indent as number) || 0 }).map((_, i) => {
              const offset = getEffectiveIndentOffset(i + 1);
              return (
                <div
                  key={i}
                  style={{ left: `${offset - 12}px` }}
                  className="absolute inset-y-0 w-px bg-zinc-800/35 group-hover/block:bg-zinc-700/60 transition-colors"
                />
              );
            })}
          </div>
        )}
        <MemoizedChildren>{children}</MemoizedChildren>
        <DropLine element={element} />
      </div>
    </div>
  );
}

function Gutter({
  children,
  className,
  isBlockSelected,
  ...props
}: React.ComponentProps<'div'> & { isBlockSelected?: boolean }) {
  const editor = useEditorRef();
  const element = useElement();
  const isSelectionAreaVisible = usePluginOption(BlockSelectionPlugin, 'isSelectionAreaVisible');
  const selected = useSelected();

  return (
    <div
      {...props}
      className={cn(
        'slate-gutterLeft',
        'absolute top-0 z-40 flex h-full -translate-x-full cursor-pointer pr-1 opacity-0 hover:opacity-100 focus-within:opacity-100',
        getPluginByType(editor, element.type)?.node.isContainer
          ? 'group-hover/container:opacity-100'
          : 'group-hover/block:opacity-100',
        isSelectionAreaVisible && 'hidden',
        (selected || isBlockSelected) && 'opacity-100',
        className,
      )}
      contentEditable={false}
    >
      {children}
    </div>
  );
}

const DragHandle = React.memo(function DragHandle({
  element,
  handleRef,
  isDragging,
  previewRef,
  resetPreview,
  setPreviewTop,
}: {
  element: TElement;
  handleRef: React.Ref<HTMLButtonElement>;
  isDragging: boolean;
  previewRef: React.RefObject<HTMLDivElement | null>;
  resetPreview: () => void;
  setPreviewTop: (top: number) => void;
  top?: number;
}) {
  const editor = useEditorRef();

  return (
    <button
      ref={handleRef}
      type="button"
      className="flex size-5 items-center justify-center rounded hover:bg-zinc-800 text-zinc-400 hover:text-white cursor-grab active:cursor-grabbing transition-colors focus:outline-none"
      data-plate-prevent-deselect
      aria-label="Drag to move or click for menu"
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        if (isDragging) return;
        const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;

        if (e.shiftKey && blockSelectionApi) {
          const selectedNodes = blockSelectionApi.getNodes({ sort: true });
          if (selectedNodes.length > 0 && selectedNodes[0]?.[0]) {
            const children = editor.children as TElement[];
            const anchorEntry = selectedNodes[0];
            const anchorIdx = children.findIndex((c) => c?.id === anchorEntry[0].id);
            const targetIdx = children.findIndex((c) => c?.id === element.id);
            if (anchorIdx !== -1 && targetIdx !== -1) {
              const start = Math.min(anchorIdx, targetIdx);
              const end = Math.max(anchorIdx, targetIdx);
              const rangeIds = children.slice(start, end + 1).map((c) => c.id as string);
              blockSelectionApi.set(rangeIds);
              return;
            }
          }
        }

        // Single block select + open block menu
        blockSelectionApi?.set(element.id as string);
        const target = e.currentTarget;
        const rect = target.getBoundingClientRect();
        editor.getApi(BlockMenuPlugin)?.blockMenu?.show(BLOCK_CONTEXT_MENU_ID, {
          x: rect.right + 4,
          y: rect.top,
        });
        target.dispatchEvent(
          new MouseEvent('contextmenu', {
            bubbles: true,
            cancelable: true,
            clientX: rect.right + 4,
            clientY: rect.top,
          }),
        );
      }}
      onMouseDown={(e) => {
        resetPreview();

        if (e.button !== 0 && e.button !== 2) return;

        const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;
        const blockSelection = blockSelectionApi ? blockSelectionApi.getNodes({ sort: true }) : [];

        let selectionNodes =
          blockSelection.length > 0 ? blockSelection : editor.api.blocks({ mode: 'highest' });

        if (!selectionNodes.some(([node]) => node.id === element.id)) {
          const path = editor.api.findPath(element);
          if (path) {
            selectionNodes = [[element, path]];
          }
        }

        const blocks = expandSelectionNodesWithChildren(editor, selectionNodes).map(
          ([node]) => node,
        );

        if (blockSelection.length === 0) {
          editor.tf.blur();
          editor.tf.collapse();
        }

        const elements = createDragPreviewElements(editor, blocks);
        if (previewRef.current) {
          previewRef.current.append(...elements);
          previewRef.current.classList.remove('hidden');
          previewRef.current.classList.add('opacity-0');
        }
        editor.setOption(DndPlugin, 'multiplePreviewRef', previewRef);

        const blockIds = blocks.map((block) => block.id as string);
        editor.setOption(DndPlugin, 'draggingId', blockIds);
        blockSelectionApi?.set(blockIds);
      }}
      onMouseEnter={() => {
        if (isDragging) return;

        const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;
        const blockSelection = blockSelectionApi ? blockSelectionApi.getNodes({ sort: true }) : [];

        let selectedBlocks =
          blockSelection.length > 0 ? blockSelection : editor.api.blocks({ mode: 'highest' });

        if (!selectedBlocks.some(([node]) => node.id === element.id)) {
          const path = editor.api.findPath(element);
          if (path) {
            selectedBlocks = [[element, path]];
          }
        }

        const processedBlocks = expandSelectionNodesWithChildren(editor, selectedBlocks);
        const ids = processedBlocks.map((block) => block[0].id as string);

        if (ids.length > 1 && ids.includes(element.id as string)) {
          const previewTop = calculatePreviewTop(editor, {
            blocks: processedBlocks.map((block) => block[0]),
            element,
          });
          setPreviewTop(previewTop);
        } else {
          setPreviewTop(0);
        }
      }}
      onMouseUp={() => {
        resetPreview();
      }}
    >
      <GripVertical className="h-3.5 w-3.5 text-zinc-400 group-hover:text-white" />
    </button>
  );
});

const DropLine = React.memo(function DropLine({
  className,
  element,
  ...props
}: React.ComponentProps<'div'> & { element?: TElement }) {
  const { dropLine } = useDropLine();

  if (!dropLine) return null;

  const isToggle = element?.type === KEYS.toggle;
  const isContainer = element?.type === KEYS.callout || isToggle;
  const currentIndent = (element?.indent as number) || 0;

  const isDroppingInside = (isToggle || isContainer) && dropLine === 'bottom';
  const indentLevel = isDroppingInside ? currentIndent + 1 : currentIndent;
  const leftOffset = indentLevel > 0 ? getEffectiveIndentOffset(indentLevel) : 0;

  return (
    <div
      {...props}
      style={{
        left: `${leftOffset}px`,
        right: 0,
        ...props.style,
      }}
      className={cn(
        'slate-dropLine',
        'absolute h-0.5 opacity-100 transition-all z-50 pointer-events-none',
        'bg-lime-400 shadow-[0_0_8px_rgba(163,230,53,0.9)]',
        dropLine === 'top' && '-top-px',
        dropLine === 'bottom' && '-bottom-px',
        className,
      )}
    >
      {isDroppingInside && (
        <div className="absolute -top-3.5 left-2 flex items-center gap-1 rounded bg-lime-400 px-1.5 py-0.5 text-[9px] font-bold text-zinc-950 shadow-md">
          <span>↳</span>
          <span>Inside {isToggle ? 'Toggle' : 'Container'}</span>
        </div>
      )}
      {!isDroppingInside && indentLevel > 0 && (
        <div className="absolute -top-3.5 left-2 flex items-center gap-1 rounded bg-zinc-800 border border-lime-400/50 px-1.5 py-0.5 text-[9px] font-medium text-lime-400 shadow-md">
          <span>↳</span>
          <span>Indented</span>
        </div>
      )}
    </div>
  );
});

const createDragPreviewElements = (editor: PlateEditor, blocks: TElement[]): HTMLElement[] => {
  const elements: HTMLElement[] = [];
  const ids: string[] = [];

  const removeDataAttributes = (element: HTMLElement) => {
    Array.from(element.attributes).forEach((attr) => {
      if (attr.name.startsWith('data-slate') || attr.name.startsWith('data-block-id')) {
        element.removeAttribute(attr.name);
      }
    });

    Array.from(element.children).forEach((child) => {
      removeDataAttributes(child as HTMLElement);
    });
  };

  const resolveElement = (node: TElement, index: number) => {
    const domNode = editor.api.toDOMNode(node);
    if (!domNode) return;
    const newDomNode = domNode.cloneNode(true) as HTMLElement;

    ids.push(node.id as string);
    const wrapper = document.createElement('div');
    wrapper.append(newDomNode);
    wrapper.style.display = 'flow-root';

    const lastDomNode = blocks[index - 1];

    if (lastDomNode) {
      const lastDom = editor.api.toDOMNode(lastDomNode);
      if (lastDom?.parentElement && domNode.parentElement) {
        const lastDomNodeRect = lastDom.parentElement.getBoundingClientRect();
        const domNodeRect = domNode.parentElement.getBoundingClientRect();
        const distance = domNodeRect.top - lastDomNodeRect.bottom;
        if (distance > 15) {
          wrapper.style.marginTop = `${distance}px`;
        }
      }
    }

    removeDataAttributes(newDomNode);
    elements.push(wrapper);
  };

  blocks.forEach((node, index) => {
    resolveElement(node, index);
  });

  editor.setOption(DndPlugin, 'draggingId', ids);

  return elements;
};

const calculatePreviewTop = (
  editor: PlateEditor,
  {
    blocks,
    element,
  }: {
    blocks: TElement[];
    element: TElement;
  },
): number => {
  const child = editor.api.toDOMNode(element);
  const editable = editor.api.toDOMNode(editor);
  const firstSelectedChild = blocks[0];
  if (!child || !editable || !firstSelectedChild) return 0;

  const firstDomNode = editor.api.toDOMNode(firstSelectedChild);
  if (!firstDomNode) return 0;

  const editorPaddingTop = Number(window.getComputedStyle(editable).paddingTop.replace('px', ''));

  const firstNodeToEditorDistance =
    firstDomNode.getBoundingClientRect().top -
    editable.getBoundingClientRect().top -
    editorPaddingTop;

  const firstMarginTopString = window.getComputedStyle(firstDomNode).marginTop;
  const marginTop = Number(firstMarginTopString.replace('px', ''));

  const currentToEditorDistance =
    child.getBoundingClientRect().top - editable.getBoundingClientRect().top - editorPaddingTop;

  const currentMarginTopString = window.getComputedStyle(child).marginTop;
  const currentMarginTop = Number(currentMarginTopString.replace('px', ''));

  const previewElementsTopDistance =
    currentToEditorDistance - firstNodeToEditorDistance + marginTop - currentMarginTop;

  return previewElementsTopDistance;
};

const calcDragButtonTop = (editor: PlateEditor, element: TElement): number => {
  const child = editor.api.toDOMNode(element);
  if (!child) return 0;

  const currentMarginTopString = window.getComputedStyle(child).marginTop;
  const currentMarginTop = Number(currentMarginTopString.replace('px', ''));

  return currentMarginTop;
};
