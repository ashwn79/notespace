import { cn } from '@xpace/ui';
import { PlateElement, type PlateElementProps } from 'platejs/react';

export function BlockquoteElement({ className, children, ...props }: PlateElementProps) {
  return (
    <PlateElement
      as="blockquote"
      className={cn(
        'my-3 border-l-4 border-primary/40 pl-4 italic text-muted-foreground',
        className,
      )}
      {...props}
    >
      {children}
    </PlateElement>
  );
}
