'use client';

import { Copy, Download, ExternalLink, Trash2 } from '@xpace/icons';
import {
  Button,
  cn,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@xpace/ui';
import {
  AlignCenter,
  AlignLeft,
  AlignRight,
  Check,
  Maximize2,
  MessageSquare,
  MoreVertical,
  Upload,
  X,
  ZoomIn,
} from 'lucide-react';
import type { TImageElement } from 'platejs';
import { useEditorRef } from 'platejs/react';
import * as React from 'react';
import { useState } from 'react';
import { Popover, PopoverContent, PopoverTrigger } from './popover';

/**
 * Custom Align Icon matching the hand-drawn toolbar design:
 * Two horizontal lines with a centered rounded rectangle between them.
 */
function ImageAlignDrawIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="h-3.5 w-3.5"
      {...props}
    >
      <line x1="3" y1="5" x2="21" y2="5" />
      <rect x="7" y="9" width="10" height="6" rx="2" />
      <line x1="3" y1="19" x2="21" y2="19" />
    </svg>
  );
}

/**
 * Custom Caption Icon matching the hand-drawn toolbar design:
 * A rounded rectangle representing the image with horizontal lines underneath for caption.
 */
function ImageCaptionDrawIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="h-3.5 w-3.5"
      {...props}
    >
      <rect x="4" y="4" width="16" height="10" rx="2" />
      <line x1="6" y1="18" x2="18" y2="18" />
      <line x1="8" y1="21" x2="16" y2="21" />
    </svg>
  );
}

interface ImageComment {
  id: string;
  author: string;
  text: string;
  createdAt: string;
}

export interface ImageToolbarProps {
  element: TImageElement;
  selected: boolean;
  isHovered: boolean;
  onExpand: () => void;
  figureRef?: React.RefObject<HTMLElement | null>;
}

export function ImageToolbar({
  element,
  selected,
  isHovered,
  onExpand,
  figureRef,
}: ImageToolbarProps) {
  const editor = useEditorRef();
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const [commentOpen, setCommentOpen] = useState(false);
  const [alignOpen, setAlignOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);

  const [commentText, setCommentText] = useState('');
  const [copied, setCopied] = useState(false);

  const url = (element.url as string) || '';
  const currentAlign = (element.align as 'left' | 'center' | 'right') || 'center';

  const rawComments = (element as unknown as { comments?: ImageComment[] }).comments;
  const comments: ImageComment[] = Array.isArray(rawComments) ? rawComments : [];

  // Determine if caption text is present
  const hasCaptionText = React.useMemo(() => {
    const rawCaption = element.caption as unknown;
    if (!rawCaption) return false;
    if (typeof rawCaption === 'string') return rawCaption.trim().length > 0;
    if (Array.isArray(rawCaption)) {
      return rawCaption.some((node: any) => {
        if (typeof node?.text === 'string') return node.text.trim().length > 0;
        if (Array.isArray(node?.children)) {
          return node.children.some(
            (child: any) => typeof child?.text === 'string' && child.text.trim().length > 0,
          );
        }
        return false;
      });
    }
    return false;
  }, [element.caption]);

  // Caption is currently visible if hideCaption is false, or if it was never hidden and has text
  const isCaptionVisible =
    element.hideCaption === false || (element.hideCaption === undefined && hasCaptionText);

  // Caption tooltip label based on state
  let captionTooltip = 'Add caption';
  if (isCaptionVisible) {
    captionTooltip = 'Hide caption';
  } else if (hasCaptionText) {
    captionTooltip = 'Show caption';
  }

  // Toggle caption visibility or initialize for the first time
  const handleToggleCaption = () => {
    const path = editor.api.findPath(element);
    if (!path) return;

    if (isCaptionVisible) {
      editor.tf.setNodes({ hideCaption: true }, { at: path });
    } else {
      const update: Record<string, unknown> = { hideCaption: false };
      if (!element.caption) {
        update.caption = [{ children: [{ text: '' }] }];
      }
      editor.tf.setNodes(update, { at: path });

      // Auto-focus caption textarea
      setTimeout(() => {
        const figure = figureRef?.current;
        const textarea = figure?.querySelector('textarea');
        if (textarea) {
          textarea.focus();
        }
      }, 50);
    }
  };

  // Change image alignment
  const handleAlign = (align: 'left' | 'center' | 'right') => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.setNodes({ align }, { at: path });
    }
    setAlignOpen(false);
  };

  // Delete image block
  const handleDelete = () => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.removeNodes({ at: path });
    }
  };

  // Add new comment
  const handleAddComment = () => {
    if (!commentText.trim()) return;
    const newComment: ImageComment = {
      id: Math.random().toString(36).slice(2, 9),
      author: 'You',
      text: commentText.trim(),
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.setNodes({ comments: [...comments, newComment] }, { at: path });
    }
    setCommentText('');
  };

  // Delete existing comment
  const handleDeleteComment = (id: string) => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.setNodes(
        { comments: comments.filter((c) => c.id !== id) },
        { at: path },
      );
    }
  };

  // Copy image URL
  const handleCopyLink = async () => {
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore clipboard error
    }
  };

  // Download image file
  const handleDownload = () => {
    if (!url) return;
    const a = document.createElement('a');
    a.href = url;
    a.download = (element.name as string) || (element.alt as string) || 'image';
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // Reset resized width
  const handleResetSize = () => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.setNodes({ width: undefined }, { at: path });
    }
    setMoreOpen(false);
  };

  // Replace image via file input
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const newUrl = URL.createObjectURL(file);
      const path = editor.api.findPath(element);
      if (path) {
        editor.tf.setNodes({ url: newUrl, name: file.name }, { at: path });
      }
    }
    setMoreOpen(false);
  };

  // Replace image via URL prompt
  const handlePromptUrl = () => {
    setMoreOpen(false);
    const newUrl = window.prompt('Enter new image URL:', url);
    if (newUrl !== null && newUrl.trim()) {
      const path = editor.api.findPath(element);
      if (path) {
        editor.tf.setNodes({ url: newUrl.trim() }, { at: path });
      }
    }
  };

  // Toolbar is visible when hovered, selected, or when any menu/popover is open
  const isVisible = isHovered || selected || commentOpen || alignOpen || moreOpen;

  return (
    <>
      {/* Hidden file input for Replace image */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileChange}
        className="hidden"
      />

      <div
        className={cn(
          'absolute top-2.5 right-2.5 z-20 flex items-center gap-0.5 rounded-lg border border-zinc-800/90 bg-zinc-950/90 p-0.5 shadow-2xl backdrop-blur-md transition-opacity duration-150',
          isVisible ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none',
        )}
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <TooltipProvider delayDuration={150}>
          {/* 1. Comment Button */}
          <Popover open={commentOpen} onOpenChange={setCommentOpen}>
            <Tooltip>
              <TooltipTrigger asChild>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className={cn(
                      'relative h-7 w-7 p-0 text-zinc-300 hover:bg-zinc-800 hover:text-white',
                      comments.length > 0 && 'text-lime-400',
                      commentOpen && 'bg-zinc-800 text-white',
                    )}
                    aria-label="Comment"
                  >
                    <MessageSquare className="h-3.5 w-3.5" />
                    {comments.length > 0 && (
                      <span className="absolute -top-0.5 -right-0.5 flex h-3 min-w-3 items-center justify-center rounded-full bg-lime-400 px-0.5 text-[8px] font-bold text-zinc-950">
                        {comments.length}
                      </span>
                    )}
                  </Button>
                </PopoverTrigger>
              </TooltipTrigger>
              <TooltipContent side="top" sideOffset={6} className="text-xs">
                Comment
              </TooltipContent>
            </Tooltip>

            <PopoverContent
              align="end"
              sideOffset={8}
              className="w-72 p-3 space-y-2.5 z-50 bg-zinc-950/95 border-zinc-800 shadow-2xl backdrop-blur-md rounded-xl text-zinc-200"
            >
              <div className="flex items-center justify-between border-b border-zinc-800/80 pb-1.5">
                <span className="text-xs font-semibold text-zinc-300">
                  Comments {comments.length > 0 && `(${comments.length})`}
                </span>
              </div>

              {comments.length > 0 ? (
                <div className="max-h-48 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
                  {comments.map((c) => (
                    <div
                      key={c.id}
                      className="rounded-lg bg-zinc-900/90 border border-zinc-800/70 p-2 text-xs space-y-1"
                    >
                      <div className="flex items-center justify-between text-[10px] text-zinc-500">
                        <span className="font-medium text-zinc-400">{c.author}</span>
                        <div className="flex items-center gap-1.5">
                          <span>{c.createdAt}</span>
                          <button
                            type="button"
                            onClick={() => handleDeleteComment(c.id)}
                            className="text-zinc-500 hover:text-red-400 transition-colors"
                            title="Delete comment"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      </div>
                      <p className="text-zinc-200 break-words leading-relaxed">{c.text}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-zinc-500 italic py-1">No comments on this image yet.</p>
              )}

              <div className="space-y-1.5 pt-1">
                <textarea
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Add a comment on this image..."
                  rows={2}
                  className="w-full resize-none rounded-lg border border-zinc-800 bg-zinc-900 p-2 text-xs text-zinc-200 placeholder:text-zinc-500 focus:outline-none focus:border-lime-400/80"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
                      e.preventDefault();
                      handleAddComment();
                    }
                  }}
                />
                <div className="flex justify-end">
                  <Button
                    type="button"
                    size="sm"
                    disabled={!commentText.trim()}
                    onClick={handleAddComment}
                    className="h-6 px-2.5 text-xs bg-lime-400 text-zinc-950 font-semibold hover:bg-lime-500 disabled:opacity-50"
                  >
                    Post
                  </Button>
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {/* 2. Align Button & Dropdown */}
          <DropdownMenu open={alignOpen} onOpenChange={setAlignOpen}>
            <Tooltip>
              <TooltipTrigger asChild>
                <DropdownMenuTrigger asChild>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className={cn(
                      'h-7 w-7 p-0 text-zinc-300 hover:bg-zinc-800 hover:text-white',
                      alignOpen && 'bg-zinc-800 text-white',
                    )}
                    aria-label="Align"
                  >
                    <ImageAlignDrawIcon />
                  </Button>
                </DropdownMenuTrigger>
              </TooltipTrigger>
              <TooltipContent side="top" sideOffset={6} className="text-xs">
                Align
              </TooltipContent>
            </Tooltip>

            <DropdownMenuContent align="center" sideOffset={8} className="w-36 p-1 z-50">
              <DropdownMenuItem
                onClick={() => handleAlign('left')}
                className={cn('gap-2 text-xs py-1.5 cursor-pointer', currentAlign === 'left' && 'text-lime-400 font-semibold')}
              >
                <AlignLeft className="h-3.5 w-3.5" />
                <span>Align left</span>
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => handleAlign('center')}
                className={cn('gap-2 text-xs py-1.5 cursor-pointer', currentAlign === 'center' && 'text-lime-400 font-semibold')}
              >
                <AlignCenter className="h-3.5 w-3.5" />
                <span>Align center</span>
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => handleAlign('right')}
                className={cn('gap-2 text-xs py-1.5 cursor-pointer', currentAlign === 'right' && 'text-lime-400 font-semibold')}
              >
                <AlignRight className="h-3.5 w-3.5" />
                <span>Align right</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* 3. Caption Button (Add caption / Hide caption / Show caption) */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleToggleCaption}
                className={cn(
                  'h-7 w-7 p-0 text-zinc-300 hover:bg-zinc-800 hover:text-white',
                  isCaptionVisible && 'text-lime-400 bg-lime-400/10 font-medium',
                )}
                aria-label={captionTooltip}
              >
                <ImageCaptionDrawIcon />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="top" sideOffset={6} className="text-xs">
              {captionTooltip}
            </TooltipContent>
          </Tooltip>

          {/* 4. Expand Button */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={onExpand}
                className="h-7 w-7 p-0 text-zinc-300 hover:bg-zinc-800 hover:text-white"
                aria-label="Expand"
              >
                <ZoomIn className="h-3.5 w-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="top" sideOffset={6} className="text-xs">
              Expand
            </TooltipContent>
          </Tooltip>

          {/* 5. Delete Button */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleDelete}
                className="h-7 w-7 p-0 text-zinc-300 hover:bg-red-500/20 hover:text-red-400"
                aria-label="Delete"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="top" sideOffset={6} className="text-xs">
              Delete
            </TooltipContent>
          </Tooltip>

          {/* 6. More Options Button & Dropdown */}
          <DropdownMenu open={moreOpen} onOpenChange={setMoreOpen}>
            <Tooltip>
              <TooltipTrigger asChild>
                <DropdownMenuTrigger asChild>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className={cn(
                      'h-7 w-7 p-0 text-zinc-300 hover:bg-zinc-800 hover:text-white',
                      moreOpen && 'bg-zinc-800 text-white',
                    )}
                    aria-label="More options"
                  >
                    <MoreVertical className="h-3.5 w-3.5" />
                  </Button>
                </DropdownMenuTrigger>
              </TooltipTrigger>
              <TooltipContent side="top" sideOffset={6} className="text-xs">
                More options
              </TooltipContent>
            </Tooltip>

            <DropdownMenuContent align="end" sideOffset={8} className="w-48 p-1 z-50">
              <DropdownMenuItem
                onClick={() => fileInputRef.current?.click()}
                className="gap-2 text-xs py-1.5 cursor-pointer"
              >
                <Upload className="h-3.5 w-3.5 text-zinc-400" />
                <span>Replace from file</span>
              </DropdownMenuItem>

              <DropdownMenuItem
                onClick={handlePromptUrl}
                className="gap-2 text-xs py-1.5 cursor-pointer"
              >
                <ExternalLink className="h-3.5 w-3.5 text-zinc-400" />
                <span>Replace with URL...</span>
              </DropdownMenuItem>

              <DropdownMenuSeparator />

              {url && (
                <>
                  <DropdownMenuItem
                    onClick={handleDownload}
                    className="gap-2 text-xs py-1.5 cursor-pointer"
                  >
                    <Download className="h-3.5 w-3.5 text-zinc-400" />
                    <span>Download</span>
                  </DropdownMenuItem>

                  <DropdownMenuItem
                    onClick={handleCopyLink}
                    className="gap-2 text-xs py-1.5 cursor-pointer"
                  >
                    {copied ? (
                      <Check className="h-3.5 w-3.5 text-lime-400" />
                    ) : (
                      <Copy className="h-3.5 w-3.5 text-zinc-400" />
                    )}
                    <span>{copied ? 'Link copied!' : 'Copy image link'}</span>
                  </DropdownMenuItem>

                  <DropdownMenuItem
                    onClick={() => window.open(url, '_blank')}
                    className="gap-2 text-xs py-1.5 cursor-pointer"
                  >
                    <ExternalLink className="h-3.5 w-3.5 text-zinc-400" />
                    <span>Open in new tab</span>
                  </DropdownMenuItem>
                </>
              )}

              <DropdownMenuItem
                onClick={handleResetSize}
                className="gap-2 text-xs py-1.5 cursor-pointer"
              >
                <Maximize2 className="h-3.5 w-3.5 text-zinc-400" />
                <span>Reset size</span>
              </DropdownMenuItem>

              <DropdownMenuSeparator />

              <DropdownMenuItem
                onClick={handleDelete}
                className="gap-2 text-xs py-1.5 text-red-400 focus:text-red-300 focus:bg-red-500/10 cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Delete image</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </TooltipProvider>
      </div>
    </>
  );
}

/**
 * Fullscreen Lightbox Preview Modal for expanding images
 */
export function ImageLightbox({
  url,
  alt,
  onClose,
}: {
  url: string;
  alt: string;
  onClose: () => void;
}) {
  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="relative max-h-[92vh] max-w-[92vw] overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-950 p-2.5 shadow-2xl flex flex-col items-center">
        {/* Header bar */}
        <div className="flex w-full items-center justify-between border-b border-zinc-800/80 pb-2 mb-2 px-2">
          <span className="text-xs font-medium text-zinc-300 truncate max-w-sm">
            {alt || 'Image Preview'}
          </span>
          <div className="flex items-center gap-1.5">
            {url && (
              <>
                <a
                  href={url}
                  download={alt || 'image'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-7 items-center gap-1 px-2 text-xs text-zinc-300 hover:text-white hover:bg-zinc-800 rounded transition-colors"
                  title="Download image"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Download</span>
                </a>
                <a
                  href={url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-7 w-7 items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 rounded transition-colors"
                  title="Open in new tab"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </>
            )}
            <button
              type="button"
              onClick={onClose}
              className="rounded p-1 text-zinc-400 hover:bg-zinc-800 hover:text-white transition-colors cursor-pointer"
              aria-label="Close preview"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* High-res image display */}
        <div className="max-h-[82vh] overflow-auto flex items-center justify-center p-1">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={url}
            alt={alt}
            className="max-h-[80vh] max-w-full object-contain rounded-lg shadow-md select-none"
          />
        </div>
      </div>
    </div>
  );
}
