import { expandListItemsWithChildren } from '@platejs/list';
import { buildToggleIndex } from '@platejs/toggle/react';
import { KEYS, type NodeEntry, PathApi, type TElement } from 'platejs';
import type { PlateEditor } from 'platejs/react';

export function isContainerType(type: string): boolean {
  return type === KEYS.toggle || type === KEYS.callout;
}

export function getContainerDescendants(
  editor: PlateEditor,
  containerNodeOrId: TElement | string,
): NodeEntry<TElement>[] {
  const children = editor.children as TElement[];
  const containerId =
    typeof containerNodeOrId === 'string' ? containerNodeOrId : containerNodeOrId.id;
  const containerIdx = children.findIndex((c) => c?.id === containerId);
  if (containerIdx === -1) return [];

  const container = children[containerIdx];
  if (!container) return [];
  const containerIndent = (container.indent as number) || 0;
  const descendants: NodeEntry<TElement>[] = [];

  for (let i = containerIdx + 1; i < children.length; i++) {
    const child = children[i];
    if (!child) continue;
    const childIndent = (child.indent as number) || 0;
    if (childIndent > containerIndent) {
      descendants.push([child, [i]]);
    } else {
      break;
    }
  }

  return descendants;
}

export function getContainerSubtree(
  editor: PlateEditor,
  containerNodeOrId: TElement | string,
): NodeEntry<TElement>[] {
  const children = editor.children as TElement[];
  const containerId =
    typeof containerNodeOrId === 'string' ? containerNodeOrId : containerNodeOrId.id;
  const containerIdx = children.findIndex((c) => c?.id === containerId);
  if (containerIdx === -1) return [];

  const container = children[containerIdx];
  if (!container) return [];
  const containerEntry: NodeEntry<TElement> = [container, [containerIdx]];
  const descendants = getContainerDescendants(editor, containerId as string);
  return [containerEntry, ...descendants];
}

export function removeContainerSubtree(
  editor: PlateEditor,
  containerNodeOrId: TElement | string,
): void {
  const subtree = getContainerSubtree(editor, containerNodeOrId);
  if (subtree.length === 0) return;

  const sorted = [...subtree].sort((a, b) => PathApi.compare(b[1], a[1]));
  editor.tf.withoutNormalizing(() => {
    sorted.forEach(([, path]) => {
      editor.tf.removeNodes({ at: path });
    });
  });
}

export function wrapBlocksInContainer(
  editor: PlateEditor,
  targetEntries: NodeEntry<TElement>[],
  containerType = KEYS.callout,
): void {
  if (targetEntries.length === 0) return;

  const sorted = [...targetEntries].sort((a, b) => PathApi.compare(a[1], b[1]));
  const first = sorted[0];
  if (!first) return;
  const firstPath = first[1];

  editor.tf.withoutNormalizing(() => {
    // 1. Insert container header block before the first target
    const headerNode = editor.api.create.block({
      type: containerType,
      ...(containerType === KEYS.callout ? { variant: 'default', icon: '💡' } : { open: true }),
      children: [{ text: '' }],
    });

    editor.tf.insertNodes([headerNode], { at: firstPath });

    // 2. Indent the wrapped blocks so they become logical children
    sorted.forEach((entry) => {
      if (!entry) return;
      const [, path] = entry;
      if (!path || path[0] === undefined) return;
      // The paths have shifted by +1 due to inserting header
      const shiftedPath = [path[0] + 1];
      const node = editor.api.node<TElement>(shiftedPath);
      if (node && node[0]) {
        const currentIndent = (node[0].indent as number) || 0;
        editor.tf.setNodes({ indent: currentIndent + 1 }, { at: shiftedPath });
      }
    });
  });
}

export function hasToggleChildren(
  editor: PlateEditor,
  containerNodeOrId: TElement | string,
): boolean {
  return getContainerDescendants(editor, containerNodeOrId).length > 0;
}

export function getToggleAncestors(
  editor: PlateEditor,
  nodeOrId: TElement | string,
): NodeEntry<TElement>[] {
  const children = editor.children as TElement[];
  const targetId = typeof nodeOrId === 'string' ? nodeOrId : nodeOrId.id;
  const targetIdx = children.findIndex((c) => c?.id === targetId);
  if (targetIdx === -1) return [];

  const targetNode = children[targetIdx];
  if (!targetNode) return [];
  const targetIndent = (targetNode.indent as number) || 0;
  if (targetIndent === 0) return [];

  const ancestors: NodeEntry<TElement>[] = [];
  let currentIndent = targetIndent;

  for (let i = targetIdx - 1; i >= 0; i--) {
    const prev = children[i];
    if (!prev) continue;
    const prevIndent = (prev.indent as number) || 0;
    if (prevIndent < currentIndent && isContainerType(prev.type)) {
      ancestors.unshift([prev, [i]]);
      currentIndent = prevIndent;
      if (currentIndent === 0) break;
    }
  }

  return ancestors;
}

export function unwrapToggle(
  editor: PlateEditor,
  toggleNodeOrId: TElement | string,
): void {
  const children = editor.children as TElement[];
  const toggleId =
    typeof toggleNodeOrId === 'string' ? toggleNodeOrId : toggleNodeOrId.id;
  const toggleIdx = children.findIndex((c) => c?.id === toggleId);
  if (toggleIdx === -1) return;

  const toggleNode = children[toggleIdx];
  if (!toggleNode) return;

  const descendants = getContainerDescendants(editor, toggleId as string);

  editor.tf.withoutNormalizing(() => {
    // 1. Outdent each descendant by 1
    descendants.forEach(([descendant, path]) => {
      const currentIndent = (descendant.indent as number) || 0;
      const newIndent = Math.max(0, currentIndent - 1);
      if (newIndent === 0) {
        editor.tf.unsetNodes('indent', { at: path });
      } else {
        editor.tf.setNodes({ indent: newIndent }, { at: path });
      }
    });

    // 2. Convert toggle node to paragraph or heading
    const newType = toggleNode.headingLevel ? `h${toggleNode.headingLevel}` : KEYS.p;
    editor.tf.unsetNodes(['headingLevel', 'variant', 'open'], { at: [toggleIdx] });
    editor.tf.setNodes({ type: newType }, { at: [toggleIdx] });
  });
}

export function getEffectiveIndentOffset(
  indent: number,
  step = 24,
  maxBeforeDampen = 6,
): number {
  if (indent <= 0) return 0;
  if (indent <= maxBeforeDampen) return indent * step;
  const baseOffset = maxBeforeDampen * step;
  const extraIndent = indent - maxBeforeDampen;
  return baseOffset + Math.min(extraIndent * 12, 120);
}

export function getTogglePersistenceKey(toggleId: string): string {
  return `xpace_toggle_state_${toggleId}`;
}

export function getPersistedToggleState(toggleId: string, defaultOpen = true): boolean {
  if (typeof window === 'undefined') return defaultOpen;
  try {
    const saved = localStorage.getItem(getTogglePersistenceKey(toggleId));
    if (saved !== null) {
      return saved === 'true';
    }
  } catch {
    // Ignore storage errors
  }
  return defaultOpen;
}

export function setPersistedToggleState(toggleId: string, open: boolean): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(getTogglePersistenceKey(toggleId), String(open));
  } catch {
    // Ignore storage errors
  }
}

export function expandSelectionNodesWithChildren(
  editor: PlateEditor,
  nodes: NodeEntry<TElement>[],
): NodeEntry<TElement>[] {
  const withLists = expandListItemsWithChildren(editor, nodes);

  const children = editor.children as TElement[];
  const toggleIndex = buildToggleIndex(children);
  const resultIds = new Set<string>();

  withLists.forEach(([node]) => {
    resultIds.add(node.id as string);

    // Expand Toggles
    if (node.type === KEYS.toggle) {
      children.forEach((c) => {
        if ((toggleIndex.get(c.id as string) || []).includes(node.id as string)) {
          resultIds.add(c.id as string);
        }
      });
    }

    // Expand Callouts and other block containers
    if (node.type === KEYS.callout) {
      const descendants = getContainerDescendants(editor, node);
      descendants.forEach(([d]) => {
        resultIds.add(d.id as string);
      });
    }
  });

  const expandedEntries: NodeEntry<TElement>[] = [];
  children.forEach((c, idx) => {
    if (resultIds.has(c.id as string)) {
      expandedEntries.push([c, [idx]]);
    }
  });

  return expandedEntries.length > 0 ? expandedEntries : withLists;
}

