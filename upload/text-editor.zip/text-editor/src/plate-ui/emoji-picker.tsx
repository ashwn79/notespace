'use client';

import emojiData from '@emoji-mart/data';
import { EmojiInlineIndexSearch } from '@platejs/emoji';
import { cn } from '@xpace/ui';
import { Search } from 'lucide-react';
import * as React from 'react';

const indexSearch = EmojiInlineIndexSearch.getInstance(emojiData as any);

const DEFAULT_EMOJI_GRID: string[] = [
  '💡',
  'ℹ️',
  '⚠️',
  '✅',
  '🚨',
  '🔥',
  '📌',
  '✨',
  '📝',
  '🎯',
  '🚀',
  '⭐',
  '😄',
  '❤️',
  '👍',
  '🎉',
  '👀',
  '💯',
  '⚡',
  '☕',
  '📚',
  '🙏',
  '💻',
  '🎨',
  '🤖',
  '💼',
  '📊',
  '🔗',
  '🔒',
  '🔑',
  '🌟',
  '💪',
  '🏆',
  '📈',
  '🛠️',
  '🧭',
];

export interface EmojiPickerProps {
  onSelectEmoji: (emoji: string) => void;
  onClose?: () => void;
  className?: string;
}

export function EmojiPicker({ onSelectEmoji, onClose, className }: EmojiPickerProps) {
  const [search, setSearch] = React.useState('');
  const inputRef = React.useRef<HTMLInputElement>(null);

  React.useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const searchResults = React.useMemo<string[] | null>(() => {
    const query = search.trim().toLowerCase();
    if (!query) return null;
    const results = (
      indexSearch.search(query).get() as Array<{
        id: string;
        name: string;
        skins?: Array<{ native: string }>;
      }>
    ).slice(0, 36);
    return results.map((r) => r.skins?.[0]?.native || '😀');
  }, [search]);

  const displayedEmojis = searchResults ?? DEFAULT_EMOJI_GRID;

  return (
    <div className={cn('flex flex-col gap-2 p-2 w-64 text-zinc-200 select-none', className)}>
      <div className="relative flex items-center">
        <Search className="absolute left-2.5 h-3.5 w-3.5 text-zinc-500 pointer-events-none" />
        <input
          ref={inputRef}
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Escape') {
              e.stopPropagation();
              onClose?.();
            }
          }}
          placeholder="Search emoji..."
          className="h-8 w-full rounded-md border border-zinc-800 bg-zinc-900/90 pl-8 pr-2.5 text-xs text-zinc-200 placeholder:text-zinc-500 focus:border-zinc-700 focus:outline-hidden"
        />
      </div>

      <div className="text-[10px] font-semibold text-zinc-500 uppercase tracking-wider px-1">
        {searchResults ? `Matching (${searchResults.length})` : 'Popular Icons'}
      </div>

      <div className="grid grid-cols-6 gap-1 max-h-48 overflow-y-auto pr-0.5">
        {displayedEmojis.length === 0 ? (
          <div className="col-span-6 py-4 text-center text-xs text-zinc-500 italic">
            No emojis found
          </div>
        ) : (
          displayedEmojis.map((emojiChar: string, idx: number) => (
            <button
              type="button"
              key={`${emojiChar}-${idx}`}
              onClick={() => onSelectEmoji(emojiChar)}
              className="flex h-8 w-8 cursor-pointer items-center justify-center rounded-md text-base transition-colors hover:bg-zinc-800 hover:scale-110 active:scale-95"
              title={emojiChar}
            >
              {emojiChar}
            </button>
          ))
        )}
      </div>
    </div>
  );
}
