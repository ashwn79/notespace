'use client';

import { CopilotPlugin } from '@platejs/ai/react';
import { useElement, usePluginOption } from 'platejs/react';

export function GhostText() {
  const element = useElement();

  const isSuggested = usePluginOption(CopilotPlugin, 'isSuggested', element.id as string);

  if (!isSuggested) return null;

  return <GhostTextContent />;
}

function GhostTextContent() {
  const suggestionText = usePluginOption(CopilotPlugin, 'suggestionText');

  if (!suggestionText) return null;

  return (
    <span
      contentEditable={false}
      className="pointer-events-none select-none text-zinc-500 italic font-normal inline"
    >
      <span>{suggestionText}</span>
      <span className="ml-1.5 inline-flex items-center rounded border border-zinc-800 bg-zinc-900 px-1 py-0.2 text-[10px] font-mono text-zinc-400 not-italic">
        Tab
      </span>
    </span>
  );
}
