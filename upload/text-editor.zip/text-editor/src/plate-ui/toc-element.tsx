'use client';

import { useTocElement, useTocElementState } from '@platejs/toc/react';
import { FileText } from '@xpace/icons';
import { cn } from '@xpace/ui';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement } from 'platejs/react';

export function TocElement(props: PlateElementProps) {
  const state = useTocElementState();
  const { props: btnProps } = useTocElement(state);
  const activeContentId = state?.activeContentId;
  const headingList = state?.headingList || [];

  return (
    <PlateElement
      {...props}
      className={cn(
        'my-3 rounded-xl border border-zinc-800/80 bg-zinc-900/30 p-3.5',
        props.className,
      )}
    >
      <div contentEditable={false} className="space-y-1 select-none">
        <div className="flex items-center gap-2 mb-2 text-xs font-semibold text-zinc-300 uppercase tracking-wider">
          <FileText className="h-3.5 w-3.5 text-lime-400" />
          <span>Table of Contents</span>
        </div>

        {headingList.length > 0 ? (
          <div className="space-y-0.5">
            {headingList.map((item) => {
              const isActive = item.id === activeContentId;
              const depth = item.depth as 1 | 2 | 3;
              return (
                <button
                  type="button"
                  key={item.id}
                  onClick={(e) => btnProps.onClick(e, item, 'smooth')}
                  className={cn(
                    'block w-full text-left text-xs py-1 px-2 rounded-md transition-colors truncate',
                    depth === 1 && 'font-medium',
                    depth === 2 && 'pl-4 text-zinc-400',
                    depth === 3 && 'pl-7 text-zinc-500',
                    isActive
                      ? 'bg-lime-400/10 text-lime-400 font-semibold'
                      : 'hover:bg-zinc-800 hover:text-zinc-200 text-zinc-300',
                  )}
                >
                  {item.title || 'Untitled'}
                </button>
              );
            })}
          </div>
        ) : (
          <p className="text-xs text-zinc-500 italic py-1">
            Add headings (H1, H2, H3) above to generate a table of contents outline.
          </p>
        )}
      </div>
      {props.children}
    </PlateElement>
  );
}
