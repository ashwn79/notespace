'use client';

import { AudioPlugin } from '@platejs/media/react';
import { Mic } from '@xpace/icons';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement } from 'platejs/react';
import { MediaToolbar } from './media-toolbar';

export function MediaAudioElement(props: PlateElementProps) {
  const url = (props.element.url as string) || '';
  const name = (props.element.name as string) || 'Audio recording';

  return (
    <MediaToolbar plugin={AudioPlugin}>
      <PlateElement {...props} className="my-2">
        <div
          contentEditable={false}
          className="flex flex-col gap-2 rounded-xl border border-zinc-800 bg-zinc-900/60 p-3 shadow-sm select-none"
        >
          <div className="flex items-center gap-2 text-xs font-medium text-zinc-300">
            <div className="flex h-6 w-6 items-center justify-center rounded-md bg-lime-400/10 text-lime-400">
              <Mic className="h-3.5 w-3.5" />
            </div>
            <span className="truncate">{name}</span>
          </div>
          <audio src={url} controls className="w-full h-8">
            <track kind="captions" />
          </audio>
        </div>
        {props.children}
      </PlateElement>
    </MediaToolbar>
  );
}
