'use client';

import { FloatingMedia, FloatingMediaStore, useFloatingMediaValue } from '@platejs/media/react';
import { Download, ExternalLink, Link, Trash2 } from '@xpace/icons';
import { Button, cn } from '@xpace/ui';
import { AlignCenter, AlignLeft, AlignRight, Maximize2, X } from 'lucide-react';
import type { WithRequiredKey } from 'platejs';
import {
  useEditorRef,
  useEditorSelector,
  useElement,
  useFocusedLast,
  useReadOnly,
  useRemoveNodeButton,
  useSelected,
} from 'platejs/react';
import type * as React from 'react';
import { useEffect, useState } from 'react';
import { CaptionButton } from './caption';
import { Popover, PopoverAnchor, PopoverContent } from './popover';

export function MediaToolbar({
  children,
  plugin,
}: {
  children: React.ReactNode;
  plugin: WithRequiredKey;
}) {
  const editor = useEditorRef();
  const readOnly = useReadOnly();
  const selected = useSelected();
  const isFocusedLast = useFocusedLast();
  const selectionCollapsed = useEditorSelector((ed) => !ed.api.isExpanded(), []);
  const [previewOpen, setPreviewOpen] = useState(false);
  const open = isFocusedLast && !readOnly && selected && selectionCollapsed && !previewOpen;
  const isEditing = useFloatingMediaValue('isEditing');

  useEffect(() => {
    if (!open && isEditing) {
      FloatingMediaStore.set('isEditing', false);
    }
  }, [open, isEditing]);

  const element = useElement();
  const { props: buttonProps } = useRemoveNodeButton({ element });

  const url = (element.url as string) || '';
  const name = (element.name as string) || 'Attached file';
  const currentAlign = (element.align as 'left' | 'center' | 'right') || 'center';
  const mediaType = plugin.key; // 'img' | 'video' | 'audio' | 'file'

  const handleAlign = (align: 'left' | 'center' | 'right') => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.setNodes({ align }, { at: path });
    }
  };

  const handleRename = () => {
    const newName = window.prompt('Rename file:', name);
    if (newName !== null && newName.trim()) {
      const path = editor.api.findPath(element);
      if (path) {
        editor.tf.setNodes({ name: newName.trim() }, { at: path });
      }
    }
  };

  return (
    <>
      <Popover open={open}>
        <PopoverAnchor>{children}</PopoverAnchor>

        <PopoverContent
          align="center"
          side="top"
          sideOffset={8}
          className="w-auto p-1.5 shadow-2xl rounded-xl backdrop-blur-md z-40 bg-zinc-950/95 border-zinc-800"
          onOpenAutoFocus={(e) => e.preventDefault()}
        >
          {isEditing ? (
            <div className="flex w-72 items-center gap-1.5 rounded-lg border border-zinc-800 bg-zinc-900 px-2 py-1">
              <Link className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
              <FloatingMedia.UrlInput
                options={{ plugin }}
                placeholder="Paste media link..."
                className="w-full bg-transparent text-xs text-foreground placeholder:text-muted-foreground focus:outline-none"
              />
            </div>
          ) : mediaType === 'file' ? (
            /* File Contextual Toolbar */
            <div className="flex items-center gap-1">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleRename}
                className="h-7 px-2 text-xs text-zinc-300 hover:text-white hover:bg-zinc-800 rounded"
              >
                Rename
              </Button>

              {url && (
                <>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setPreviewOpen(true)}
                    className="h-7 px-2 text-xs text-zinc-300 hover:text-white hover:bg-zinc-800 rounded"
                  >
                    Preview
                  </Button>
                  <a
                    href={url}
                    download={name}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex h-7 items-center gap-1 px-2 text-xs text-zinc-300 hover:text-white hover:bg-zinc-800 rounded transition-colors"
                  >
                    <Download className="h-3 w-3 text-lime-400" />
                    <span>Download</span>
                  </a>
                </>
              )}

              <FloatingMedia.EditButton className="h-7 px-2 text-xs text-zinc-300 hover:text-white hover:bg-zinc-800 rounded">
                Replace
              </FloatingMedia.EditButton>

              <div className="h-4 w-px bg-zinc-800 mx-0.5" />

              <Button
                type="button"
                variant="ghost"
                size="sm"
                {...buttonProps}
                className="h-7 w-7 p-0 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                title="Delete file"
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          ) : (
            /* Image / Video / Audio Toolbar */
            <div className="flex items-center gap-1">
              <FloatingMedia.EditButton className="h-7 px-2 text-xs text-zinc-300 hover:text-white hover:bg-zinc-800 rounded">
                Replace
              </FloatingMedia.EditButton>

              {mediaType !== 'audio' && <CaptionButton />}

              {mediaType !== 'audio' && (
                <>
                  <div className="h-4 w-px bg-zinc-800 mx-0.5" />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => handleAlign('left')}
                    className={cn(
                      'h-7 w-7 p-0 text-muted-foreground hover:text-foreground',
                      currentAlign === 'left' && 'bg-zinc-800 text-lime-400 font-semibold',
                    )}
                    title="Align left"
                  >
                    <AlignLeft className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => handleAlign('center')}
                    className={cn(
                      'h-7 w-7 p-0 text-muted-foreground hover:text-foreground',
                      currentAlign === 'center' && 'bg-zinc-800 text-lime-400 font-semibold',
                    )}
                    title="Align center"
                  >
                    <AlignCenter className="h-3.5 w-3.5" />
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => handleAlign('right')}
                    className={cn(
                      'h-7 w-7 p-0 text-muted-foreground hover:text-foreground',
                      currentAlign === 'right' && 'bg-zinc-800 text-lime-400 font-semibold',
                    )}
                    title="Align right"
                  >
                    <AlignRight className="h-3.5 w-3.5" />
                  </Button>
                </>
              )}

              {url && (
                <>
                  <div className="h-4 w-px bg-zinc-800 mx-0.5" />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setPreviewOpen(true)}
                    className="h-7 w-7 p-0 text-muted-foreground hover:text-foreground hover:bg-zinc-800"
                    title="Expand / Preview"
                  >
                    <Maximize2 className="h-3.5 w-3.5" />
                  </Button>
                  <a
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex h-7 w-7 items-center justify-center rounded text-muted-foreground hover:text-foreground hover:bg-zinc-800 transition-colors"
                    title="Open source link"
                  >
                    <ExternalLink className="h-3.5 w-3.5" />
                  </a>
                </>
              )}

              <div className="h-4 w-px bg-zinc-800 mx-0.5" />

              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-7 w-7 p-0 text-red-400 hover:text-red-300 hover:bg-red-500/10"
                title="Delete media"
                {...buttonProps}
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          )}
        </PopoverContent>
      </Popover>

      {/* Fullscreen Preview Lightbox (IMG-04: toolbar disappears while preview is active) */}
      {previewOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) setPreviewOpen(false);
          }}
          onKeyDown={(e) => {
            if (e.key === 'Escape') setPreviewOpen(false);
          }}
        >
          <div className="relative max-h-[90vh] max-w-[90vw] overflow-hidden rounded-xl border border-zinc-800 bg-zinc-950 p-2 shadow-2xl flex flex-col items-center">
            <div className="flex w-full items-center justify-between border-b border-zinc-800/80 pb-2 mb-2 px-2">
              <span className="text-xs font-medium text-zinc-300 truncate max-w-sm">
                {name || 'Media Preview'}
              </span>
              <button
                type="button"
                onClick={() => setPreviewOpen(false)}
                className="rounded p-1 text-zinc-400 hover:bg-zinc-800 hover:text-white transition-colors"
                aria-label="Close preview"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="max-h-[80vh] overflow-auto flex items-center justify-center">
              {mediaType === 'video' ? (
                <video src={url} controls className="max-h-[75vh] max-w-full rounded" autoPlay>
                  <track kind="captions" />
                </video>
              ) : mediaType === 'file' ? (
                url.endsWith('.pdf') ? (
                  <iframe src={url} title={name} className="w-[80vw] h-[75vh] border-0 rounded" />
                ) : (
                  <div className="p-8 text-center space-y-3">
                    <p className="text-xs text-zinc-400">
                      File format preview not directly embedded.
                    </p>
                    <a
                      href={url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-lime-400 text-zinc-950 rounded-lg hover:bg-lime-500 transition-colors"
                    >
                      <ExternalLink className="h-3.5 w-3.5" />
                      <span>Open Original in New Tab</span>
                    </a>
                  </div>
                )
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={url}
                  alt={name}
                  className="max-h-[75vh] max-w-full object-contain rounded"
                />
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
