'use client';

import { ChevronDown } from '@xpace/icons';
import {
  Button,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@xpace/ui';
import { KEYS } from 'platejs';
import { useEditorRef, useEditorSelector } from 'platejs/react';
import { TURN_INTO_COMMANDS } from '../commands/command-registry';
import { getBlockType, setBlockType } from '../commands/transforms';

export function TurnIntoDropdown() {
  const editor = useEditorRef();

  const currentType = useEditorSelector((ed) => {
    const entry = ed.api.block();
    if (!entry) return KEYS.p;
    return getBlockType(entry[0]);
  }, []);

  const activeCommand =
    TURN_INTO_COMMANDS.find((cmd) => cmd.key === currentType) ?? TURN_INTO_COMMANDS[0];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onMouseDown={(e) => e.preventDefault()}
          className="h-7 gap-1 px-2 text-xs font-medium text-zinc-300 hover:text-white hover:bg-zinc-800"
        >
          <div className="flex items-center gap-1.5">
            <span className="h-3.5 w-3.5 flex items-center justify-center text-zinc-400">
              {activeCommand?.icon}
            </span>
            <span>{activeCommand?.label ?? 'Text'}</span>
          </div>
          <ChevronDown className="h-3 w-3 opacity-60 ml-0.5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-56 p-1 z-50">
        <div className="px-2 py-1 text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">
          Turn into
        </div>
        {TURN_INTO_COMMANDS.map((cmd) => (
          <DropdownMenuItem
            key={cmd.key}
            onClick={() => {
              setBlockType(editor, cmd.key);
              editor.tf.focus();
            }}
            className="gap-2 text-xs py-1.5"
          >
            <div className="flex h-5 w-5 shrink-0 items-center justify-center text-zinc-300">
              {cmd.icon}
            </div>
            <span className="truncate">{cmd.label}</span>
            {cmd.shortcut && (
              <span className="ml-auto text-[11px] font-mono text-zinc-500 select-none pl-2">
                {cmd.shortcut}
              </span>
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
