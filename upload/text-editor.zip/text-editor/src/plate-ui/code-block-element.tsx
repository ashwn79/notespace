import { resetCodeBlockDecorations } from '@platejs/code-block';
import { Check, Copy } from '@xpace/icons';
import { cn } from '@xpace/ui';
import type { PlateElementProps, PlateLeafProps } from 'platejs/react';
import { PlateElement, PlateLeaf, useEditorRef } from 'platejs/react';
import * as React from 'react';

const CODE_LANGUAGES = [
  { label: 'Plain Text', value: 'plaintext' },
  { label: 'JavaScript', value: 'javascript' },
  { label: 'TypeScript', value: 'typescript' },
  { label: 'Python', value: 'python' },
  { label: 'HTML', value: 'html' },
  { label: 'CSS', value: 'css' },
  { label: 'JSON', value: 'json' },
  { label: 'Bash', value: 'bash' },
  { label: 'Markdown', value: 'markdown' },
];

export function CodeBlockElement({ className, children, element, ...props }: PlateElementProps) {
  const editor = useEditorRef();
  const [copied, setCopied] = React.useState(false);
  const lang = (element.lang as string) || 'plaintext';

  const handleCopy = () => {
    const text =
      (element.children as Array<{ children?: Array<{ text?: string }> }>)
        ?.map((line) => line.children?.map((c) => c.text ?? '').join('') ?? '')
        .join('\n') || editor.api.string(element);
    navigator.clipboard?.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLangChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const path = editor.api.findPath(element);
    if (path) {
      resetCodeBlockDecorations(element as any);
      editor.tf.setNodes({ lang: e.target.value }, { at: path });
    }
  };

  return (
    <PlateElement
      as="div"
      element={element}
      className={cn(
        'group relative my-3 rounded-xl bg-zinc-950/90 font-mono text-xs leading-relaxed text-zinc-200 border border-zinc-800 shadow-inner overflow-hidden',
        className,
      )}
      {...props}
    >
      <div
        contentEditable={false}
        className="flex items-center justify-between border-b border-zinc-800/80 bg-zinc-900/60 px-3 py-1.5 text-zinc-400 select-none"
      >
        <select
          value={lang}
          onChange={handleLangChange}
          className="bg-transparent text-[11px] text-zinc-400 hover:text-zinc-200 cursor-pointer focus:outline-hidden"
          title="Select language"
        >
          {CODE_LANGUAGES.map((l) => (
            <option key={l.value} value={l.value} className="bg-zinc-900 text-zinc-200">
              {l.label}
            </option>
          ))}
        </select>

        <button
          type="button"
          onClick={handleCopy}
          className="flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200 transition-colors"
          title="Copy code"
        >
          {copied ? (
            <>
              <Check className="h-3 w-3 text-lime-400" />
              <span className="text-lime-400">Copied</span>
            </>
          ) : (
            <>
              <Copy className="h-3 w-3" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>

      <pre className="p-3.5 overflow-x-auto">
        <code>{children}</code>
      </pre>
    </PlateElement>
  );
}

export function CodeLineElement({ className, children, ...props }: PlateElementProps) {
  return (
    <PlateElement as="div" className={cn('min-h-[1.5em] font-mono text-xs', className)} {...props}>
      {children}
    </PlateElement>
  );
}

export function CodeSyntaxLeaf(props: PlateLeafProps) {
  const tokenClassName = (props.leaf.className as string) || '';
  return <PlateLeaf className={tokenClassName} {...props} />;
}
