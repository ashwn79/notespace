'use client';

import { AIChatPlugin } from '@platejs/ai/react';
import { indent, outdent } from '@platejs/indent';
import {
  Copy,
  GripVertical,
  Indent as IndentIcon,
  Outdent as OutdentIcon,
  Plus,
  Sparkles,
  Trash2,
} from '@xpace/icons';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from '@xpace/ui';
import { nanoid } from 'platejs';
import type { PlateEditor } from 'platejs/react';
import type React from 'react';
import { BASIC_COMMANDS, TURN_INTO_COMMANDS } from '../commands/command-registry';
import { setBlockType } from '../commands/transforms';
import type { TextEditorElementNode } from '../types/editor';

interface BlockGutterProps {
  editor: PlateEditor;
  element: TextEditorElementNode;
  handleRef?: React.Ref<HTMLButtonElement>;
  readOnly?: boolean;
}

export function BlockGutter({ editor, element, handleRef, readOnly }: BlockGutterProps) {
  if (readOnly) return null;

  const handleDuplicate = () => {
    const path = editor.api.findPath(element as never);
    if (!path) return;

    const index = editor.children.findIndex((n) => (n as TextEditorElementNode).id === element.id);
    const parentIndent = (element.indent as number) || 0;
    const blocksToDuplicate: TextEditorElementNode[] = [];

    if (index !== -1) {
      blocksToDuplicate.push(editor.children[index] as TextEditorElementNode);
      for (let i = index + 1; i < editor.children.length; i++) {
        const child = editor.children[i] as TextEditorElementNode;
        const childIndent = (child.indent as number) || 0;
        if (childIndent > parentIndent) {
          blocksToDuplicate.push(child);
        } else {
          break;
        }
      }
    } else {
      blocksToDuplicate.push(element);
    }

    const cloned = blocksToDuplicate.map((b) => {
      const copy = JSON.parse(JSON.stringify(b)) as TextEditorElementNode;
      copy.id = nanoid();
      if (Array.isArray(copy.children)) {
        const assignNewIds = (nodes: unknown[]) => {
          for (const node of nodes) {
            const el = node as TextEditorElementNode;
            if (el.id) el.id = nanoid();
            if (Array.isArray(el.children)) assignNewIds(el.children);
          }
        };
        assignNewIds(copy.children);
      }
      return copy;
    });

    const insertAt = index !== -1 ? index + blocksToDuplicate.length : (path[0] ?? 0) + 1;
    editor.tf.insertNodes(cloned as never[], { at: [insertAt] });
    const startPoint = editor.api.start([insertAt]);
    if (startPoint) {
      editor.tf.select(startPoint);
    }
    editor.tf.focus();
  };

  const handleDelete = () => {
    const index = editor.children.findIndex((n) => (n as TextEditorElementNode).id === element.id);
    if (index === -1) {
      const path = editor.api.findPath(element as never);
      if (path) editor.tf.removeNodes({ at: path });
      return;
    }

    const parentIndent = (element.indent as number) || 0;
    let removeCount = 1;
    for (let i = index + 1; i < editor.children.length; i++) {
      const child = editor.children[i] as TextEditorElementNode;
      const childIndent = (child.indent as number) || 0;
      if (childIndent > parentIndent) {
        removeCount++;
      } else {
        break;
      }
    }

    editor.tf.withoutNormalizing(() => {
      for (let i = index + removeCount - 1; i >= index; i--) {
        editor.tf.removeNodes({ at: [i] });
      }

      if (!editor.children || editor.children.length === 0) {
        editor.tf.insertNodes([{ id: nanoid(), type: 'p', children: [{ text: '' }] }], { at: [0] });
        editor.tf.select([0, 0]);
      } else {
        const nextIndex = Math.max(0, Math.min(index, editor.children.length - 1));
        const startPoint = editor.api.start([nextIndex]);
        if (startPoint) {
          editor.tf.select(startPoint);
        }
      }
    });
    editor.tf.focus();
  };

  const handleIndent = () => {
    const path = editor.api.findPath(element);
    if (!path || (path[0] === 0 && path.length === 1)) return;
    const currentIndent = (element.indent as number) || 0;
    if (currentIndent >= 6) return;
    editor.tf.select(editor.api.start(path));
    indent(editor);
  };

  const handleOutdent = () => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.select(editor.api.start(path));
      outdent(editor);
    }
  };

  const handleAskAI = () => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.select(editor.api.start(path));
    }
    editor.getApi(AIChatPlugin)?.aiChat?.show();
  };

  return (
    <div
      contentEditable={false}
      data-testid="block-gutter"
      className="absolute right-full top-0.5 mr-2 z-20 flex items-center gap-0.5 select-none opacity-0 group-hover/draggable:opacity-100 group-focus-within/draggable:opacity-100 transition-opacity duration-150"
    >
      {/* 1. Plus Button: Insert Block Below */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            type="button"
            data-testid="block-gutter-plus"
            aria-label="Add block below"
            className="flex h-5 w-5 items-center justify-center rounded text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <Plus className="h-3.5 w-3.5 text-lime-400" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          align="start"
          side="bottom"
          sideOffset={4}
          className="w-60 max-h-72 overflow-y-auto z-50 p-1"
        >
          <div className="px-2 py-1 text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">
            Insert Block Below
          </div>
          {BASIC_COMMANDS.map((cmd) => (
            <DropdownMenuItem
              key={cmd.key}
              onClick={() => {
                cmd.execute(editor, { element, insertAfter: true });
              }}
              className="gap-2 text-xs py-1.5"
            >
              <div className="flex h-5 w-5 shrink-0 items-center justify-center text-zinc-300">
                {cmd.icon}
              </div>
              <span className="font-medium text-white truncate">{cmd.label}</span>
              {cmd.shortcut && (
                <span className="ml-auto text-[11px] font-mono text-zinc-500 select-none pl-2">
                  {cmd.shortcut}
                </span>
              )}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      {/* 2. Drag Handle & Context Menu */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            ref={handleRef}
            type="button"
            data-testid="block-gutter-handle"
            aria-label="Drag block or open menu"
            className="flex h-5 w-5 items-center justify-center rounded text-zinc-400 hover:text-white hover:bg-zinc-800 cursor-grab active:cursor-grabbing transition-colors"
          >
            <GripVertical className="h-3.5 w-3.5" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" side="left" sideOffset={8} className="w-52 z-50 p-1">
          <DropdownMenuItem onClick={handleAskAI} className="gap-2 text-xs">
            <Sparkles className="h-3.5 w-3.5 text-lime-400" />
            <span className="font-semibold text-lime-400">Ask AI</span>
          </DropdownMenuItem>

          <DropdownMenuSeparator />

          {/* Turn Into Submenu */}
          <DropdownMenuSub>
            <DropdownMenuSubTrigger className="gap-2 text-xs">
              <span className="h-3.5 w-3.5 flex items-center justify-center text-zinc-400">🔄</span>
              <span>Turn into</span>
            </DropdownMenuSubTrigger>
            <DropdownMenuSubContent className="w-56 max-h-64 overflow-y-auto p-1 z-50">
              {TURN_INTO_COMMANDS.map((cmd) => (
                <DropdownMenuItem
                  key={cmd.key}
                  onClick={() => {
                    const path = editor.api.findPath(element);
                    if (path) {
                      editor.tf.select(editor.api.start(path));
                      setBlockType(editor, cmd.key, { at: path });
                      editor.tf.focus();
                    }
                  }}
                  className="gap-2 text-xs"
                >
                  <div className="flex h-5 w-5 shrink-0 items-center justify-center text-zinc-300">
                    {cmd.icon}
                  </div>
                  <span className="truncate">{cmd.label}</span>
                  {cmd.shortcut && (
                    <span className="ml-auto text-[11px] font-mono text-zinc-500 select-none pl-2">
                      {cmd.shortcut}
                    </span>
                  )}
                </DropdownMenuItem>
              ))}
            </DropdownMenuSubContent>
          </DropdownMenuSub>

          <DropdownMenuItem onClick={handleDuplicate} className="gap-2 text-xs">
            <Copy className="h-3.5 w-3.5" />
            <span>Duplicate</span>
          </DropdownMenuItem>

          <DropdownMenuItem
            onClick={handleDelete}
            className="gap-2 text-xs text-red-400 focus:text-red-300 hover:bg-red-500/10"
          >
            <Trash2 className="h-3.5 w-3.5" />
            <span>Delete</span>
          </DropdownMenuItem>

          <DropdownMenuSeparator />

          <DropdownMenuItem onClick={handleIndent} className="gap-2 text-xs">
            <IndentIcon className="h-3.5 w-3.5" />
            <span>Indent (Tab)</span>
          </DropdownMenuItem>

          <DropdownMenuItem onClick={handleOutdent} className="gap-2 text-xs">
            <OutdentIcon className="h-3.5 w-3.5" />
            <span>Outdent (Shift+Tab)</span>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
