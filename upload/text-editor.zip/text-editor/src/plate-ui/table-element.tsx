'use client';

import { ResizeHandle } from '@platejs/resizable';
import {
  deleteColumn,
  deleteRow,
  deleteTable,
  insertTableColumn,
  insertTableRow,
  mergeTableCells,
  splitTableCell,
} from '@platejs/table';
import {
  TableProvider,
  useTableCellElement,
  useTableCellElementResizable,
  useTableColSizes,
  useTableMergeState,
  useTableSelectionDom,
} from '@platejs/table/react';
import { Plus, Trash2 } from '@xpace/icons';
import { Button, cn } from '@xpace/ui';
import { Columns3, Merge, Rows3, Split } from 'lucide-react';
import { KEYS } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
import {
  PlateElement,
  useEditorRef,
  useEditorSelector,
  useReadOnly,
  useSelected,
  withHOC,
} from 'platejs/react';
import * as React from 'react';

export const TableElement = withHOC(
  TableProvider,
  function TableElement({ children, className, element, ...props }: PlateElementProps) {
    const editor = useEditorRef();
    const readOnly = useReadOnly();
    const selected = useSelected();
    const tableRef = React.useRef<HTMLTableElement>(null);
    useTableSelectionDom(tableRef);

    const { canMerge, canSplit } = useTableMergeState();
    const colSizes = useTableColSizes();
    const isSelectionInTable = useEditorSelector((ed) => {
      if (!ed.selection) return false;
      return Boolean(ed.api.above({ match: { type: ed.getType(KEYS.table) } }));
    }, []);

    const showToolbar = !readOnly && (selected || isSelectionInTable);

    const handleAddRowAbove = (e: React.MouseEvent) => {
      e.preventDefault();
      insertTableRow(editor, { before: true });
    };

    const handleAddRowBelow = (e: React.MouseEvent) => {
      e.preventDefault();
      insertTableRow(editor);
    };

    const handleAddColLeft = (e: React.MouseEvent) => {
      e.preventDefault();
      insertTableColumn(editor, { before: true });
    };

    const handleAddColRight = (e: React.MouseEvent) => {
      e.preventDefault();
      insertTableColumn(editor);
    };

    const handleDeleteRow = (e: React.MouseEvent) => {
      e.preventDefault();
      deleteRow(editor);
    };

    const handleDeleteCol = (e: React.MouseEvent) => {
      e.preventDefault();
      deleteColumn(editor);
    };

    const handleMergeCells = (e: React.MouseEvent) => {
      e.preventDefault();
      mergeTableCells(editor);
    };

    const handleSplitCell = (e: React.MouseEvent) => {
      e.preventDefault();
      splitTableCell(editor);
    };

    const handleDeleteTable = (e: React.MouseEvent) => {
      e.preventDefault();
      deleteTable(editor);
    };

    const effectiveColSizes =
      colSizes && colSizes.length > 0 ? colSizes.map((s) => s || 180) : [180, 180];
    const totalWidth = effectiveColSizes.reduce((a, b) => a + b, 0);

    return (
      <PlateElement
        element={element}
        className={cn('relative my-3 overflow-x-auto py-1', className)}
        {...props}
      >
        {showToolbar && (
          <div
            contentEditable={false}
            className="absolute -top-10 left-0 z-40 flex items-center gap-1 rounded-xl border border-zinc-800 bg-zinc-950/95 p-1 shadow-2xl backdrop-blur-md animate-in fade-in zoom-in-95 duration-100 select-none"
          >
            <div className="flex items-center gap-0.5">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onMouseDown={(e) => e.preventDefault()}
                onClick={handleAddRowAbove}
                className="h-6 px-1.5 text-[11px] gap-1 text-zinc-300 hover:text-white"
                title="Add row above"
              >
                <Plus className="h-3 w-3 text-lime-400" />
                <span>Row ↑</span>
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onMouseDown={(e) => e.preventDefault()}
                onClick={handleAddRowBelow}
                className="h-6 px-1.5 text-[11px] gap-1 text-zinc-300 hover:text-white"
                title="Add row below"
              >
                <Plus className="h-3 w-3 text-lime-400" />
                <span>Row ↓</span>
              </Button>
            </div>
            <div className="h-3.5 w-px bg-zinc-800 mx-0.5" />
            <div className="flex items-center gap-0.5">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onMouseDown={(e) => e.preventDefault()}
                onClick={handleAddColLeft}
                className="h-6 px-1.5 text-[11px] gap-1 text-zinc-300 hover:text-white"
                title="Add column left"
              >
                <Plus className="h-3 w-3 text-lime-400" />
                <span>Col ←</span>
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onMouseDown={(e) => e.preventDefault()}
                onClick={handleAddColRight}
                className="h-6 px-1.5 text-[11px] gap-1 text-zinc-300 hover:text-white"
                title="Add column right"
              >
                <Plus className="h-3 w-3 text-lime-400" />
                <span>Col →</span>
              </Button>
            </div>
            <div className="h-3.5 w-px bg-zinc-800 mx-0.5" />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onMouseDown={(e) => e.preventDefault()}
              onClick={handleDeleteRow}
              className="h-6 px-1.5 text-[11px] text-zinc-400 hover:text-red-400"
              title="Delete current row"
            >
              <Rows3 className="h-3 w-3" />
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onMouseDown={(e) => e.preventDefault()}
              onClick={handleDeleteCol}
              className="h-6 px-1.5 text-[11px] text-zinc-400 hover:text-red-400"
              title="Delete current column"
            >
              <Columns3 className="h-3 w-3" />
            </Button>
            <div className="h-3.5 w-px bg-zinc-800 mx-0.5" />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              disabled={!canMerge}
              onMouseDown={(e) => e.preventDefault()}
              onClick={handleMergeCells}
              className={cn(
                'h-6 px-1.5 text-[11px] gap-1',
                canMerge
                  ? 'text-lime-400 hover:bg-lime-500/10'
                  : 'text-zinc-600 opacity-50 cursor-not-allowed',
              )}
              title="Merge selected cells"
            >
              <Merge className="h-3 w-3" />
              <span>Merge</span>
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              disabled={!canSplit}
              onMouseDown={(e) => e.preventDefault()}
              onClick={handleSplitCell}
              className={cn(
                'h-6 px-1.5 text-[11px] gap-1',
                canSplit
                  ? 'text-lime-400 hover:bg-lime-500/10'
                  : 'text-zinc-600 opacity-50 cursor-not-allowed',
              )}
              title="Split cell"
            >
              <Split className="h-3 w-3" />
              <span>Split</span>
            </Button>
            <div className="h-3.5 w-px bg-zinc-800 mx-0.5" />
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onMouseDown={(e) => e.preventDefault()}
              onClick={handleDeleteTable}
              className="h-6 px-1.5 text-[11px] text-red-400 hover:bg-red-500/10"
              title="Delete table"
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          </div>
        )}

        <table
          ref={tableRef}
          style={{ width: `${totalWidth}px` }}
          className="table-fixed border-collapse rounded-lg border border-zinc-800 bg-zinc-950/40 text-base"
        >
          <colgroup>
            {effectiveColSizes.map((width, index) => (
              <col key={index} style={{ width: `${width}px` }} />
            ))}
          </colgroup>
          <tbody className="divide-y divide-zinc-800/80">{children}</tbody>
        </table>
      </PlateElement>
    );
  },
);

export function TableRowElement({ children, className, element, ...props }: PlateElementProps) {
  return (
    <PlateElement
      as="tr"
      element={element}
      className={cn('transition-colors hover:bg-zinc-900/30', className)}
      {...props}
    >
      {children}
    </PlateElement>
  );
}

export function TableCellElement({ children, className, element, ...props }: PlateElementProps) {
  const readOnly = useReadOnly();
  const cellState = useTableCellElement();
  const resizableState = useTableCellElementResizable(cellState);

  return (
    <PlateElement
      as="td"
      element={element}
      {...({
        colSpan: element.colSpan as number | undefined,
        rowSpan: element.rowSpan as number | undefined,
      } as any)}
      className={cn(
        'relative border border-zinc-800/80 p-2.5 align-top text-foreground leading-normal transition-colors',
        'focus-within:bg-zinc-900/50 focus-within:ring-1 focus-within:ring-lime-400/40',
        cellState.selected && 'bg-lime-500/15 ring-1 ring-lime-400/60',
        'data-[slate-cell-selected=true]:bg-lime-500/15 data-[slate-cell-selected=true]:ring-1 data-[slate-cell-selected=true]:ring-lime-400/60',
        className,
      )}
      {...props}
    >
      {children}
      {!readOnly && resizableState?.rightProps && (
        <ResizeHandle
          {...resizableState.rightProps}
          className="absolute -right-1 top-0 h-full w-2 cursor-col-resize hover:bg-lime-400/60 transition-colors select-none z-20"
        />
      )}
    </PlateElement>
  );
}

export function TableCellHeaderElement({
  children,
  className,
  element,
  ...props
}: PlateElementProps) {
  const readOnly = useReadOnly();
  const cellState = useTableCellElement();
  const resizableState = useTableCellElementResizable(cellState);

  return (
    <PlateElement
      as="th"
      element={element}
      {...({
        colSpan: element.colSpan as number | undefined,
        rowSpan: element.rowSpan as number | undefined,
      } as any)}
      className={cn(
        'relative border border-zinc-800/80 bg-zinc-900/60 p-2.5 text-left font-semibold text-zinc-200 align-top transition-colors',
        'focus-within:bg-zinc-900/80 focus-within:ring-1 focus-within:ring-lime-400/40',
        cellState.selected && 'bg-lime-500/15 ring-1 ring-lime-400/60',
        'data-[slate-cell-selected=true]:bg-lime-500/15 data-[slate-cell-selected=true]:ring-1 data-[slate-cell-selected=true]:ring-lime-400/60',
        className,
      )}
      {...props}
    >
      {children}
      {!readOnly && resizableState?.rightProps && (
        <ResizeHandle
          {...resizableState.rightProps}
          className="absolute -right-1 top-0 h-full w-2 cursor-col-resize hover:bg-lime-400/60 transition-colors select-none z-20"
        />
      )}
    </PlateElement>
  );
}
