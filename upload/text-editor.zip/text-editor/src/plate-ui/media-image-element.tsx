'use client';

import { Image, useMediaState } from '@platejs/media/react';
import { Resizable, ResizableProvider, useResizableValue } from '@platejs/resizable';
import { cn } from '@xpace/ui';
import type { TImageElement } from 'platejs';
import { PlateElement, type PlateElementProps, withHOC } from 'platejs/react';
import * as React from 'react';
import { Caption, CaptionTextarea } from './caption';
import { ImageLightbox, ImageToolbar } from './image-toolbar';
import { ResizeHandle } from './resize-handle';

export const MediaImageElement = withHOC(
  ResizableProvider,
  function MediaImageElement(props: PlateElementProps<TImageElement>) {
    const { align = 'center', focused, readOnly, selected } = useMediaState();
    const width = useResizableValue('width');
    const figureRef = React.useRef<HTMLElement>(null);
    const [maxWidth, setMaxWidth] = React.useState<number>(800);
    const [isHovered, setIsHovered] = React.useState(false);
    const [previewOpen, setPreviewOpen] = React.useState(false);

    React.useEffect(() => {
      const figure = figureRef.current;
      if (!figure) return;
      const parent = figure.parentElement;
      if (!parent) return;

      const updateWidth = () => {
        const clientWidth = parent.clientWidth;
        if (clientWidth > 0) {
          setMaxWidth(clientWidth);
        }
      };

      updateWidth();
      const ro = new ResizeObserver(updateWidth);
      ro.observe(parent);
      return () => ro.disconnect();
    }, []);

    return (
      <PlateElement {...props} className="py-2.5">
        <figure
          ref={figureRef}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          className={cn(
            'group/media relative m-0 flex w-full max-w-full flex-col',
            align === 'left' && 'items-start',
            align === 'center' && 'items-center',
            align === 'right' && 'items-end',
          )}
          contentEditable={false}
        >
          <Resizable
            className="max-w-full"
            options={{
              align,
              readOnly,
              maxWidth,
              minWidth: 92,
            }}
          >
            <ResizeHandle options={{ direction: 'left' }} />
            <div className="relative group/image overflow-hidden rounded-xl border border-zinc-800 bg-zinc-900 shadow-md">
              <Image
                alt={props.attributes.alt as string | undefined}
                className={cn(
                  'block w-full max-w-full cursor-pointer object-cover transition-all',
                  focused &&
                    selected &&
                    'ring-2 ring-lime-400 ring-offset-2 ring-offset-zinc-950',
                )}
                onDoubleClick={() => setPreviewOpen(true)}
              />

              {!readOnly && (
                <ImageToolbar
                  element={props.element}
                  selected={Boolean(selected)}
                  isHovered={isHovered}
                  onExpand={() => setPreviewOpen(true)}
                  figureRef={figureRef}
                />
              )}
            </div>
            <ResizeHandle options={{ direction: 'right' }} />
          </Resizable>

          <Caption align={align} style={{ width }}>
            <CaptionTextarea placeholder="Write an image caption..." readOnly={readOnly} />
          </Caption>
        </figure>
        {props.children}

        {previewOpen && (
          <ImageLightbox
            url={(props.element.url as string) || ''}
            alt={
              (props.element.alt as string) ||
              (props.element.name as string) ||
              ''
            }
            onClose={() => setPreviewOpen(false)}
          />
        )}
      </PlateElement>
    );
  },
);
