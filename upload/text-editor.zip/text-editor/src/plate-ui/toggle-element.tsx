'use client';

import { TogglePlugin, useToggleButton, useToggleButtonState } from '@platejs/toggle/react';
import { cn } from '@xpace/ui';
import { Play } from 'lucide-react';
import { KEYS, PathApi } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement, useEditorRef } from 'platejs/react';
import * as React from 'react';
import {
  getContainerDescendants,
  getPersistedToggleState,
  hasToggleChildren,
  setPersistedToggleState,
} from './toggle-utils';

export interface ToggleElementProps extends PlateElementProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

export function ToggleElement({
  children,
  className,
  element,
  open: controlledOpen,
  onOpenChange,
  ...props
}: ToggleElementProps) {
  const contentId = React.useId();
  const editor = useEditorRef();
  const toggleId = (element.id as string) || '';

  // 1. Expansion state: controlled > element.open > plate hook > localStorage
  const state = useToggleButtonState(toggleId);
  const { open: hookOpen } = useToggleButton(state);

  const initialPersisted = React.useMemo(() => {
    if (element.open !== undefined) return Boolean(element.open);
    return getPersistedToggleState(toggleId, true);
  }, [element.open, toggleId]);

  const isOpen =
    controlledOpen !== undefined
      ? controlledOpen
      : element.open !== undefined
        ? Boolean(element.open)
        : hookOpen ?? initialPersisted;

  // Sync initial state to Plate plugin if persisted is false but hook opened it
  React.useEffect(() => {
    if (toggleId && element.open !== undefined) {
      if (Boolean(element.open) !== hookOpen) {
        editor.getApi(TogglePlugin)?.toggle?.toggleIds?.([toggleId], Boolean(element.open));
      }
    }
  }, [editor, element.open, hookOpen, toggleId]);

  // Heading Level & Variants (Feature 4 & Feature 96)
  const headingLevel = (element.headingLevel as 1 | 2 | 3 | undefined) || 
    (element.variant === 'h1' ? 1 : element.variant === 'h2' ? 2 : element.variant === 'h3' ? 3 : undefined);
  const variant = (element.variant as string) || (headingLevel ? 'heading' : 'default');
  const indent = (element.indent as number) || 0;

  // Toggle Action Handler with Focus Preservation (Feature 59)
  const handleToggle = React.useCallback(
    (e?: React.MouseEvent | React.KeyboardEvent) => {
      e?.preventDefault();
      e?.stopPropagation();

      const nextState = !isOpen;

      // Feature 59: Focus Preservation
      // If closing and focus is currently inside a descendant block, move selection to toggle header
      if (isOpen && editor.selection) {
        const path = editor.api.findPath(element);
        if (path) {
          const descendants = getContainerDescendants(editor, toggleId);
          const isFocusInDescendant = descendants.some(([, dPath]) => {
            const focusPath = editor.selection?.focus?.path;
            if (!focusPath) return false;
            return (
              PathApi.isDescendant(focusPath, dPath) ||
              PathApi.equals(focusPath.slice(0, dPath.length), dPath)
            );
          });

          if (isFocusInDescendant) {
            editor.tf.select(editor.api.end(path));
            editor.tf.focus();
          }
        }
      }

      // Plate toggle update
      editor.getApi(TogglePlugin)?.toggle?.toggleIds?.([toggleId], nextState);

      // Slate node state persistence
      const currentPath = editor.api.findPath(element);
      if (currentPath) {
        editor.tf.setNodes({ open: nextState }, { at: currentPath });
      }

      // Storage persistence (Feature 22)
      setPersistedToggleState(toggleId, nextState);
      onOpenChange?.(nextState);
    },
    [editor, element, isOpen, onOpenChange, toggleId],
  );

  // Check if toggle has children for empty state (Features 80 & 81)
  const hasChildren = React.useMemo(() => {
    return hasToggleChildren(editor, toggleId);
  }, [editor, toggleId]);

  // First child quick creation handler (Feature 81)
  const handleCreateFirstChild = React.useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();

      const path = editor.api.findPath(element);
      if (!path) return;

      const nextPath = PathApi.next(path);
      const childIndent = indent + 1;

      editor.tf.insertNodes(
        editor.api.create.block({
          type: KEYS.p,
          indent: childIndent,
          children: [{ text: '' }],
        }),
        { at: nextPath, select: true },
      );
      editor.tf.focus();
    },
    [editor, element, indent],
  );

  // Double click full header row toggles open/collapse (Feature 53)
  const handleHeaderDoubleClick = React.useCallback(
    (e: React.MouseEvent) => {
      const target = e.target as HTMLElement;
      // If clicking directly inside editable text, let inline editing happen
      if (target.getAttribute('contenteditable') === 'true' || target.closest('[data-slate-string]')) {
        return;
      }
      handleToggle(e);
    },
    [handleToggle],
  );

  // Heading-specific classes
  const headingStyles = {
    1: 'text-2xl font-bold tracking-tight text-white mt-5 mb-1.5',
    2: 'text-xl font-semibold tracking-tight text-white mt-4 mb-1',
    3: 'text-lg font-semibold tracking-tight text-white mt-3 mb-0.5',
  };

  const buttonOffsets = {
    1: 'top-1',
    2: 'top-1',
    3: 'top-0.5',
  };

  // Variant wrapper classes (Feature 96)
  const variantWrapperClass = cn(
    'relative group/toggle transition-all',
    variant === 'card' && 'bg-[#1e1e20] border border-zinc-800/90 rounded-lg p-3 my-2 shadow-sm hover:border-zinc-700/80',
    variant === 'bordered' && 'border-l-2 border-lime-400/80 pl-3 my-1 rounded-r-md bg-zinc-900/30',
    variant === 'default' && 'my-0.5',
    className,
  );

  // Presence data (Feature 42)
  const presence = (element as any).presence as { id: string; name: string; color?: string }[] | undefined;

  return (
    <PlateElement
      element={element}
      className={variantWrapperClass}
      {...props}
    >
      {/* Interactive Toggle Header Row */}
      <div
        className={cn(
          'relative flex items-start rounded-md transition-colors',
          'hover:bg-zinc-800/25',
          headingLevel ? headingStyles[headingLevel] : 'text-base text-foreground font-normal min-h-[1.75rem]',
        )}
        onDoubleClick={handleHeaderDoubleClick}
      >
        {/* Chevron Button with Full-Row Hit Target & ARIA (Features 1, 50, 53, 57, 58) */}
        <button
          type="button"
          contentEditable={false}
          aria-expanded={isOpen}
          aria-label={isOpen ? 'Collapse toggle' : 'Expand toggle'}
          aria-controls={`toggle-content-${contentId}`}
          tabIndex={0}
          onClick={handleToggle}
          onKeyDown={(e) => {
            if (e.key === ' ' || e.key === 'Enter') {
              handleToggle(e);
            }
          }}
          className={cn(
            'flex shrink-0 cursor-pointer select-none items-center justify-center rounded transition-all',
            'h-6 w-6 mr-1 text-zinc-400 hover:bg-zinc-800 hover:text-white active:scale-95',
            headingLevel ? buttonOffsets[headingLevel] : 'top-0.5',
          )}
        >
          <Play
            className={cn(
              headingLevel === 1 && 'h-3.5 w-3.5',
              headingLevel === 2 && 'h-3 w-3',
              headingLevel === 3 && 'h-2.5 w-2.5',
              !headingLevel && 'h-2.5 w-2.5',
              'fill-current transition-transform duration-200 ease-out',
              isOpen ? 'rotate-90 text-lime-400' : 'rotate-0 text-zinc-400 group-hover/toggle:text-zinc-200',
            )}
          />
        </button>

        {/* Rich-Text Editable Title (Features 5 & 6) */}
        <div className="min-w-0 flex-1 leading-normal focus:outline-none">
          {children}
        </div>

        {/* Presence indicator avatar slot (Feature 42) */}
        {presence && presence.length > 0 && (
          <div
            contentEditable={false}
            className="flex items-center gap-1 ml-2 self-center select-none"
          >
            {presence.slice(0, 3).map((user) => (
              <span
                key={user.id}
                title={`${user.name} editing inside`}
                style={{ backgroundColor: user.color || '#a3e635' }}
                className="flex h-4 w-4 items-center justify-center rounded-full text-[9px] font-bold text-zinc-950 ring-1 ring-zinc-900 shadow-sm"
              >
                {user.name.charAt(0).toUpperCase()}
              </span>
            ))}
          </div>
        )}

        {/* Depth Badge for Deep Hierarchy (Feature 100) */}
        {indent >= 5 && (
          <span
            contentEditable={false}
            className="opacity-0 group-hover/toggle:opacity-100 transition-opacity ml-2 self-center rounded bg-zinc-800/80 border border-zinc-700/60 px-1 py-0.2 text-[9px] font-mono text-zinc-400 select-none"
            title={`Nesting depth level ${indent}`}
          >
            L{indent}
          </span>
        )}
      </div>

      {/* Hover Indentation Guide line when open (Feature 54) */}
      {isOpen && (
        <div
          contentEditable={false}
          className="absolute left-[11px] top-7 bottom-0 w-px bg-zinc-800/40 pointer-events-none group-hover/toggle:bg-lime-500/25 transition-colors"
        />
      )}

      {/* Empty State Prompt & First-Child Quick Creation (Features 80 & 81) */}
      {isOpen && !hasChildren && (
        <div
          id={`toggle-content-${contentId}`}
          contentEditable={false}
          onClick={handleCreateFirstChild}
          className={cn(
            'group/empty mt-1.5 flex items-center gap-2 rounded-md py-1.5 pl-7 pr-3',
            'text-xs text-zinc-500 hover:text-zinc-200 hover:bg-zinc-800/40',
            'border border-dashed border-zinc-800/80 hover:border-zinc-700/80',
            'cursor-pointer select-none transition-all duration-150',
          )}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === ' ' || e.key === 'Enter') {
              handleCreateFirstChild(e as any);
            }
          }}
        >
          <span className="flex h-3.5 w-3.5 items-center justify-center rounded bg-zinc-800 group-hover/empty:bg-lime-400 group-hover/empty:text-zinc-950 text-zinc-400 text-[10px] font-bold transition-colors">
            +
          </span>
          <span className="font-normal italic">
            Empty toggle. Click to add content or drop blocks here...
          </span>
        </div>
      )}
    </PlateElement>
  );
}
