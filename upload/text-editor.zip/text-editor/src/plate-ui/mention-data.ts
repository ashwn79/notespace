export interface MentionTeamMember {
  id: string;
  label: string;
  role: string;
  email?: string;
  keywords?: string[];
}

export interface MentionPageItem {
  id: string;
  label: string;
  description: string;
  keywords?: string[];
}

export const INITIAL_TEAM_MEMBERS: MentionTeamMember[] = [
  {
    id: 'ashwin',
    label: 'Ashwin',
    role: 'Workspace Owner',
    email: 'ashwin@xpace.io',
    keywords: ['ashwin', 'owner', 'founder', 'team'],
  },
  {
    id: 'sarah',
    label: 'Sarah Chen',
    role: 'Senior Editor',
    email: 'sarah@xpace.io',
    keywords: ['sarah', 'editor', 'content', 'team'],
  },
  {
    id: 'marcus',
    label: 'Marcus Vance',
    role: 'Creator & Host',
    email: 'marcus@xpace.io',
    keywords: ['marcus', 'creator', 'video', 'team'],
  },
  {
    id: 'elena',
    label: 'Elena Rostova',
    role: 'Brand Designer',
    email: 'elena@xpace.io',
    keywords: ['elena', 'designer', 'brand', 'team'],
  },
];

export const MORE_TEAM_MEMBERS: MentionTeamMember[] = [
  {
    id: 'devon',
    label: 'Devon Reed',
    role: 'Marketing Lead',
    email: 'devon@xpace.io',
    keywords: ['devon', 'marketing', 'growth', 'team'],
  },
  {
    id: 'alex',
    label: 'Alex Rivera',
    role: 'Videographer',
    email: 'alex@xpace.io',
    keywords: ['alex', 'video', 'media', 'team'],
  },
  {
    id: 'jordan',
    label: 'Jordan Lee',
    role: 'Copywriter',
    email: 'jordan@xpace.io',
    keywords: ['jordan', 'copy', 'writing', 'team'],
  },
  {
    id: 'maya',
    label: 'Maya Patel',
    role: 'Product Manager',
    email: 'maya@xpace.io',
    keywords: ['maya', 'pm', 'product', 'team'],
  },
  {
    id: 'chris',
    label: 'Chris Wu',
    role: 'Strategist',
    email: 'chris@xpace.io',
    keywords: ['chris', 'strategy', 'audience', 'team'],
  },
  {
    id: 'liam',
    label: "Liam O'Connor",
    role: 'Analytics Lead',
    email: 'liam@xpace.io',
    keywords: ['liam', 'analytics', 'data', 'team'],
  },
];

export const ALL_TEAM_MEMBERS: MentionTeamMember[] = [
  ...INITIAL_TEAM_MEMBERS,
  ...MORE_TEAM_MEMBERS,
];

export const ALL_PAGES: MentionPageItem[] = [
  {
    id: 'editor_showcase',
    label: 'XPACE Feature Showcase',
    description: 'Interactive editor canvas, blocks, and media',
    keywords: ['showcase', 'editor', 'page', 'doc'],
  },
  {
    id: 'brand_dna',
    label: 'Brand DNA & Tone Guidelines',
    description: 'Core brand spec, voice rules and audience positioning',
    keywords: ['brand', 'dna', 'tone', 'voice', 'page', 'doc'],
  },
  {
    id: 'playbook_dist',
    label: 'Distribution Engine Playbook',
    description: 'Multi-platform publication schedule and rules',
    keywords: ['distribution', 'engine', 'playbook', 'publishing', 'page', 'doc'],
  },
  {
    id: 'audience_icp',
    label: 'Audience Persona: Founder ICP',
    description: 'Demographics, pain points, and intelligence signals',
    keywords: ['audience', 'persona', 'icp', 'founder', 'page', 'doc'],
  },
  {
    id: 'content_roadmap',
    label: 'Weekly Content Sprint Plan',
    description: 'Active production pipeline and review queue',
    keywords: ['sprint', 'roadmap', 'content', 'production', 'page', 'doc'],
  },
];
export interface MentionDateItem {
  id: string;
  label: string;
  dateValue: string;
  description: string;
  keywords?: string[];
}

export function getStandardDates(): MentionDateItem[] {
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  const nextWeek = new Date(today);
  nextWeek.setDate(nextWeek.getDate() + 7);

  const formatDate = (d: Date) =>
    d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

  const formatIsoDate = (d: Date) => {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  return [
    {
      id: 'today',
      label: `Today (${formatDate(today)})`,
      dateValue: formatIsoDate(today),
      description: 'Interactive editable date',
      keywords: ['today', 'date', 'now', formatDate(today)],
    },
    {
      id: 'tomorrow',
      label: `Tomorrow (${formatDate(tomorrow)})`,
      dateValue: formatIsoDate(tomorrow),
      description: 'Interactive editable date',
      keywords: ['tomorrow', 'date', 'next', formatDate(tomorrow)],
    },
    {
      id: 'yesterday',
      label: `Yesterday (${formatDate(yesterday)})`,
      dateValue: formatIsoDate(yesterday),
      description: 'Interactive editable date',
      keywords: ['yesterday', 'date', 'prev', formatDate(yesterday)],
    },
    {
      id: 'next_week',
      label: `+1 Week (${formatDate(nextWeek)})`,
      dateValue: formatIsoDate(nextWeek),
      description: 'Interactive editable date',
      keywords: ['week', 'date', 'later', formatDate(nextWeek)],
    },
  ];
}

