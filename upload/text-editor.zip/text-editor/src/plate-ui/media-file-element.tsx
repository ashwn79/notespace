'use client';

import { FilePlugin } from '@platejs/media/react';
import { Download } from '@xpace/icons';
import { FileUp } from 'lucide-react';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement } from 'platejs/react';
import { MediaToolbar } from './media-toolbar';

function formatBytes(bytes?: number): string | null {
  if (typeof bytes !== 'number' || Number.isNaN(bytes) || bytes <= 0) return null;
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / k ** i).toFixed(1))} ${sizes[i]}`;
}

export function MediaFileElement(props: PlateElementProps) {
  const url = (props.element.url as string) || '';
  const name = (props.element.name as string) || 'Attached file';
  const size = typeof props.element.size === 'number' ? formatBytes(props.element.size) : null;
  const mime =
    typeof props.element.mimeType === 'string' && props.element.mimeType.trim()
      ? (props.element.mimeType as string)
      : null;
  const metaParts = [mime, size].filter(Boolean);
  const subtitle = metaParts.length > 0 ? metaParts.join(' • ') : 'Attachment';

  return (
    <MediaToolbar plugin={FilePlugin}>
      <PlateElement {...props} className="my-2">
        <div
          contentEditable={false}
          className="flex items-center justify-between gap-3 rounded-xl border border-zinc-800 bg-zinc-900/60 p-3 shadow-sm select-none hover:border-zinc-700 transition-colors"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-zinc-800 text-lime-400">
              <FileUp className="h-4 w-4" />
            </div>
            <div className="flex flex-col min-w-0">
              <span className="truncate text-xs font-medium text-white">{name}</span>
              <span className="text-[10px] text-zinc-500 font-mono">{subtitle}</span>
            </div>
          </div>

          {url && (
            <a
              href={url}
              download={name}
              target="_blank"
              rel="noopener noreferrer"
              className="flex h-7 items-center gap-1 rounded-md bg-zinc-800 px-2 text-[11px] text-zinc-300 hover:text-white hover:bg-zinc-700 transition-colors shrink-0"
            >
              <Download className="h-3 w-3 text-lime-400" />
              <span>Download</span>
            </a>
          )}
        </div>
        {props.children}
      </PlateElement>
    </MediaToolbar>
  );
}
