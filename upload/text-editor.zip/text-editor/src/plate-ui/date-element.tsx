'use client';

import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from '@xpace/icons';
import { cn, Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@xpace/ui';
import { AlarmClock } from 'lucide-react';
import type { TDateElement } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement, useReadOnly, useSelected } from 'platejs/react';
import * as React from 'react';
import { Popover, PopoverContent, PopoverTrigger } from './popover';

export type DateFormat = 'full' | 'short' | 'iso' | 'relative';
export type TimeFormat = '12h' | '24h';
export type ReminderOption = 'none' | 'at_time' | '5m' | '15m' | '1h' | '1d' | '2d' | '1w';

interface ExtendedDateElement extends TDateElement {
  endDate?: string;
  includeTime?: boolean;
  time?: string;
  endTime?: string;
  displayFormat?: DateFormat;
  timeFormat?: TimeFormat;
  reminder?: ReminderOption;
}

const MONTH_NAMES = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec',
];

const WEEKDAY_NAMES = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

function parseYMD(dateStr?: string): { year: number; month: number; day: number } | null {
  if (!dateStr) return null;
  const parts = dateStr
    .slice(0, 10)
    .split('-')
    .map((p) => Number.parseInt(p, 10));
  if (
    parts.length === 3 &&
    parts[0] !== undefined &&
    parts[1] !== undefined &&
    parts[2] !== undefined &&
    !Number.isNaN(parts[0]) &&
    !Number.isNaN(parts[1]) &&
    !Number.isNaN(parts[2])
  ) {
    return { year: parts[0], month: parts[1] - 1, day: parts[2] };
  }
  const d = new Date(dateStr);
  if (Number.isNaN(d.getTime())) return null;

  // Prevent JavaScript default 2001 reference year glitch
  let year = d.getFullYear();
  if (year === 2001 && !dateStr.includes('2001')) {
    year = new Date().getFullYear();
  }

  return { year, month: d.getMonth(), day: d.getDate() };
}

function toIsoDate(year: number, month: number, day: number): string {
  const y = year.toString().padStart(4, '0');
  const m = (month + 1).toString().padStart(2, '0');
  const d = day.toString().padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function parseDateInput(inputStr: string, defaultYear = new Date().getFullYear()): string | null {
  const trimmed = inputStr.trim().toLowerCase();
  if (!trimmed) return null;

  const now = new Date();
  if (trimmed === 'today') {
    return toIsoDate(now.getFullYear(), now.getMonth(), now.getDate());
  }
  if (trimmed === 'tomorrow') {
    const tom = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    return toIsoDate(tom.getFullYear(), tom.getMonth(), tom.getDate());
  }
  if (trimmed === 'yesterday') {
    const yest = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
    return toIsoDate(yest.getFullYear(), yest.getMonth(), yest.getDate());
  }

  // 1. Exact ISO: YYYY-MM-DD
  const ymdMatch = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(trimmed);
  if (ymdMatch) {
    const y = Number.parseInt(ymdMatch[1] ?? '', 10);
    const m = Number.parseInt(ymdMatch[2] ?? '', 10);
    const d = Number.parseInt(ymdMatch[3] ?? '', 10);
    if (!Number.isNaN(y) && !Number.isNaN(m) && !Number.isNaN(d)) {
      return toIsoDate(y, m - 1, d);
    }
  }

  // 2. Month and Day with optional year: "Oct 5", "October 5", "Oct 5, 2026"
  const monthNames = [
    'jan',
    'feb',
    'mar',
    'apr',
    'may',
    'jun',
    'jul',
    'aug',
    'sep',
    'oct',
    'nov',
    'dec',
  ];
  const monthDayMatch =
    /^(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+(\d{1,2})(?:st|nd|rd|th)?(?:\s*,?\s*(\d{4}))?$/i.exec(
      trimmed,
    );
  if (monthDayMatch) {
    const monthPrefix = monthDayMatch[1]?.slice(0, 3).toLowerCase();
    const monthIndex = monthNames.indexOf(monthPrefix ?? '');
    const day = Number.parseInt(monthDayMatch[2] ?? '', 10);
    const year = monthDayMatch[3] ? Number.parseInt(monthDayMatch[3], 10) : defaultYear;
    if (monthIndex !== -1 && !Number.isNaN(day) && day >= 1 && day <= 31) {
      return toIsoDate(year, monthIndex, day);
    }
  }

  // 3. Day Month: "5 Oct", "5 October 2026"
  const dayMonthMatch =
    /^(\d{1,2})(?:st|nd|rd|th)?\s+(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)(?:\s*,?\s*(\d{4}))?$/i.exec(
      trimmed,
    );
  if (dayMonthMatch) {
    const day = Number.parseInt(dayMonthMatch[1] ?? '', 10);
    const monthPrefix = dayMonthMatch[2]?.slice(0, 3).toLowerCase();
    const monthIndex = monthNames.indexOf(monthPrefix ?? '');
    const year = dayMonthMatch[3] ? Number.parseInt(dayMonthMatch[3], 10) : defaultYear;
    if (monthIndex !== -1 && !Number.isNaN(day) && day >= 1 && day <= 31) {
      return toIsoDate(year, monthIndex, day);
    }
  }

  // 4. MM/DD or MM/DD/YYYY
  const slashMatch = /^(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?$/.exec(trimmed);
  if (slashMatch) {
    const m = Number.parseInt(slashMatch[1] ?? '', 10);
    const d = Number.parseInt(slashMatch[2] ?? '', 10);
    let y = slashMatch[3] ? Number.parseInt(slashMatch[3], 10) : defaultYear;
    if (y < 100) y += 2000;
    if (m >= 1 && m <= 12 && d >= 1 && d <= 31) {
      return toIsoDate(y, m - 1, d);
    }
  }

  // 5. Fallback Date.parse
  const parsed = new Date(inputStr);
  if (!Number.isNaN(parsed.getTime())) {
    const yr =
      parsed.getFullYear() === 2001 && !inputStr.includes('2001')
        ? defaultYear
        : parsed.getFullYear();
    return toIsoDate(yr, parsed.getMonth(), parsed.getDate());
  }

  return null;
}

function parseTimeInput(inputStr: string): string | null {
  const trimmed = inputStr.trim().toLowerCase();
  if (!trimmed) return null;

  // Check 12h format with am/pm: "11:37 pm", "11:37pm", "11 pm", "11am", "9:30 AM"
  const ampmMatch = /^(\d{1,2})(?::(\d{2}))?\s*(am|pm)$/i.exec(trimmed);
  if (ampmMatch) {
    let h = Number.parseInt(ampmMatch[1] ?? '0', 10);
    const m = ampmMatch[2] ? Number.parseInt(ampmMatch[2], 10) : 0;
    const isPm = ampmMatch[3]?.toLowerCase() === 'pm';

    if (h < 1 || h > 12 || m < 0 || m > 59) return null;
    if (isPm && h < 12) h += 12;
    if (!isPm && h === 12) h = 0;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
  }

  // Check 24h format: "23:37", "11:37", "09:00"
  const colonMatch = /^(\d{1,2}):(\d{2})$/.exec(trimmed);
  if (colonMatch) {
    const h = Number.parseInt(colonMatch[1] ?? '0', 10);
    const m = Number.parseInt(colonMatch[2] ?? '0', 10);
    if (h >= 0 && h <= 23 && m >= 0 && m <= 59) {
      return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
    }
  }

  return null;
}

export function formatDateByFormat(dateStr: string, format: DateFormat = 'short'): string {
  if (!dateStr) return '';
  const parsedYMD = parseYMD(dateStr);
  if (!parsedYMD) return dateStr;

  const { year, month, day } = parsedYMD;
  const monthName = MONTH_NAMES[month];

  const now = new Date();
  const todayYMD = { year: now.getFullYear(), month: now.getMonth(), day: now.getDate() };

  const isSameDay = year === todayYMD.year && month === todayYMD.month && day === todayYMD.day;

  const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  const isTomorrow =
    year === tomorrow.getFullYear() && month === tomorrow.getMonth() && day === tomorrow.getDate();

  const yesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
  const isYesterday =
    year === yesterday.getFullYear() &&
    month === yesterday.getMonth() &&
    day === yesterday.getDate();

  switch (format) {
    case 'full':
      // Full date (eg: Oct 5, 2026)
      return `${monthName} ${day}, ${year}`;
    case 'iso':
      // ISO (eg: 2026-10-05)
      return toIsoDate(year, month, day);
    case 'relative':
      // Relative (eg: Tomorrow or Short date)
      if (isSameDay) return 'Today';
      if (isTomorrow) return 'Tomorrow';
      if (isYesterday) return 'Yesterday';
      return `${monthName} ${day}`;
    case 'short':
    default:
      // Short date (eg: Oct 5)
      return `${monthName} ${day}`;
  }
}

function formatTimeString(timeStr?: string, format: TimeFormat = '12h'): string {
  if (!timeStr) return '';
  const [hStr, mStr] = timeStr.split(':');
  if (!hStr) return timeStr;
  let h = Number.parseInt(hStr, 10);
  const m = mStr ? mStr.slice(0, 2) : '00';
  if (Number.isNaN(h)) return timeStr;

  if (format === '24h') {
    return `${h.toString().padStart(2, '0')}:${m}`;
  }

  const ampm = h >= 12 ? 'PM' : 'AM';
  h = h % 12;
  if (h === 0) h = 12;
  return `${h.toString().padStart(2, '0')}:${m} ${ampm}`;
}

function getLocalGmtOffset(): string {
  const offset = -new Date().getTimezoneOffset();
  const sign = offset >= 0 ? '+' : '-';
  const hours = Math.floor(Math.abs(offset) / 60);
  const mins = Math.abs(offset) % 60;
  return `GMT${sign}${hours}${mins > 0 ? `:${mins.toString().padStart(2, '0')}` : ':00'}`;
}

function getReminderLabel(reminder?: ReminderOption): string {
  switch (reminder) {
    case 'at_time':
      return 'On day of event';
    case '5m':
      return '5 minutes before';
    case '15m':
      return '15 minutes before';
    case '1h':
      return '1 hour before';
    case '1d':
      return '1 day before';
    case '2d':
      return '2 days before';
    case '1w':
      return '1 week before';
    case 'none':
    default:
      return 'None';
  }
}

function getFormatDisplayLabel(fmt: DateFormat): string {
  switch (fmt) {
    case 'full':
      return 'Full date';
    case 'short':
      return 'Short date';
    case 'iso':
      return 'ISO';
    case 'relative':
    default:
      return 'Relative';
  }
}

function getDateLabel(element: ExtendedDateElement): string {
  const dateValue = (element.date as string) || (element.rawDate as string) || '';
  if (!dateValue) return 'Pick a date';

  const format = element.displayFormat || 'short';
  const timeFmt = element.timeFormat || '12h';
  let startLabel = formatDateByFormat(dateValue, format);

  if (element.includeTime && element.time) {
    startLabel += ` ${formatTimeString(element.time, timeFmt)}`;
  }

  if (element.endDate) {
    let endLabel = formatDateByFormat(element.endDate, format);
    if (element.includeTime && element.endTime) {
      endLabel += ` ${formatTimeString(element.endTime, timeFmt)}`;
    }
    return `${startLabel} → ${endLabel}`;
  }

  return startLabel;
}

function getFullTooltipLabel(element: ExtendedDateElement): string {
  const dateValue = (element.date as string) || (element.rawDate as string) || '';
  if (!dateValue) return 'Pick a date';

  let fullLabel = formatDateByFormat(dateValue, 'full');
  const timeFmt = element.timeFormat || '12h';

  if (element.includeTime && element.time) {
    fullLabel += ` at ${formatTimeString(element.time, timeFmt)}`;
  }

  if (element.endDate) {
    let fullEnd = formatDateByFormat(element.endDate, 'full');
    if (element.includeTime && element.endTime) {
      fullEnd += ` at ${formatTimeString(element.endTime, timeFmt)}`;
    }
    fullLabel = `${fullLabel} → ${fullEnd}`;
  }

  if (element.reminder && element.reminder !== 'none') {
    fullLabel += ` • ⏰ ${getReminderLabel(element.reminder)}`;
  }

  return fullLabel;
}

export function DateElement(props: PlateElementProps<ExtendedDateElement>) {
  const { editor, element } = props;
  const readOnly = useReadOnly();
  const selected = useSelected();
  const [open, setOpen] = React.useState(false);

  const today = new Date();
  const dateValue =
    (element.date as string) ||
    (element.rawDate as string) ||
    toIsoDate(today.getFullYear(), today.getMonth(), today.getDate());
  const endDateValue = element.endDate || '';
  const hasRange = Boolean(element.endDate);
  const includeTime = Boolean(element.includeTime);
  const currentFormat: DateFormat = element.displayFormat || 'short';
  const currentTimeFormat: TimeFormat = element.timeFormat || '12h';
  const currentReminder: ReminderOption = element.reminder || 'none';
  const hasReminder = Boolean(currentReminder && currentReminder !== 'none');
  const timeZoneStr = React.useMemo(() => getLocalGmtOffset(), []);

  const [activeTarget, setActiveTarget] = React.useState<'start' | 'end'>('start');
  const [showFormatMenu, setShowFormatMenu] = React.useState(false);
  const [showReminderMenu, setShowReminderMenu] = React.useState(false);

  // Editable text states for left-aligned date & time boxes
  const [startInputText, setStartInputText] = React.useState(
    formatDateByFormat(dateValue, currentFormat),
  );
  const [endInputText, setEndInputText] = React.useState(
    endDateValue ? formatDateByFormat(endDateValue, currentFormat) : '',
  );
  const [startTimeInputText, setStartTimeInputText] = React.useState(
    formatTimeString(element.time || '11:37', currentTimeFormat),
  );
  const [endTimeInputText, setEndTimeInputText] = React.useState(
    formatTimeString(element.endTime || '16:40', currentTimeFormat),
  );

  // Calendar View month and year
  const initialYMD = parseYMD(dateValue) || {
    year: today.getFullYear(),
    month: today.getMonth(),
    day: today.getDate(),
  };
  const [viewYear, setViewYear] = React.useState(initialYMD.year);
  const [viewMonth, setViewMonth] = React.useState(initialYMD.month);

  // Sync inputs and calendar view when element changes or popover opens
  React.useEffect(() => {
    setStartInputText(formatDateByFormat(dateValue, currentFormat));
    setEndInputText(endDateValue ? formatDateByFormat(endDateValue, currentFormat) : '');
    setStartTimeInputText(formatTimeString(element.time || '11:37', currentTimeFormat));
    setEndTimeInputText(formatTimeString(element.endTime || '16:40', currentTimeFormat));

    if (open) {
      const targetDate = activeTarget === 'end' && endDateValue ? endDateValue : dateValue;
      const ymd = parseYMD(targetDate);
      if (ymd) {
        setViewYear(ymd.year);
        setViewMonth(ymd.month);
      }
      setShowFormatMenu(false);
      setShowReminderMenu(false);
    }
  }, [
    open,
    dateValue,
    endDateValue,
    activeTarget,
    currentFormat,
    currentTimeFormat,
    element.time,
    element.endTime,
  ]);

  const updateDate = (updates: Partial<ExtendedDateElement>) => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.setNodes(updates, { at: path });
    }
  };

  const handleClear = () => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.removeNodes({ at: path });
    }
    setOpen(false);
  };

  const handlePrevMonth = () => {
    if (viewMonth === 0) {
      setViewMonth(11);
      setViewYear((y) => y - 1);
    } else {
      setViewMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (viewMonth === 11) {
      setViewMonth(0);
      setViewYear((y) => y + 1);
    } else {
      setViewMonth((m) => m + 1);
    }
  };

  const handleTodayOrNowClick = () => {
    const now = new Date();
    const iso = toIsoDate(now.getFullYear(), now.getMonth(), now.getDate());
    setViewYear(now.getFullYear());
    setViewMonth(now.getMonth());

    const currentH = now.getHours().toString().padStart(2, '0');
    const currentM = now.getMinutes().toString().padStart(2, '0');
    const currentTime = `${currentH}:${currentM}`;

    if (activeTarget === 'end' && hasRange) {
      updateDate({
        endDate: iso,
        ...(includeTime ? { endTime: currentTime } : {}),
      });
    } else {
      updateDate({
        date: iso,
        ...(includeTime ? { time: currentTime } : {}),
      });
    }
  };

  const handleSelectDay = (year: number, month: number, day: number) => {
    const iso = toIsoDate(year, month, day);

    if (hasRange) {
      if (activeTarget === 'start') {
        if (endDateValue && iso > endDateValue) {
          updateDate({ date: iso, endDate: iso });
        } else {
          updateDate({ date: iso });
          setActiveTarget('end');
        }
      } else {
        if (iso < dateValue) {
          updateDate({ date: iso, endDate: dateValue });
        } else {
          updateDate({ endDate: iso });
        }
      }
    } else {
      updateDate({ date: iso });
    }
  };

  const handleCommitStartInput = () => {
    const parsedIso = parseDateInput(startInputText, viewYear);
    if (parsedIso) {
      updateDate({ date: parsedIso });
      const ymd = parseYMD(parsedIso);
      if (ymd) {
        setViewYear(ymd.year);
        setViewMonth(ymd.month);
      }
    } else {
      setStartInputText(formatDateByFormat(dateValue, currentFormat));
    }
  };

  const handleCommitEndInput = () => {
    const parsedIso = parseDateInput(endInputText, viewYear);
    if (parsedIso) {
      updateDate({ endDate: parsedIso });
      const ymd = parseYMD(parsedIso);
      if (ymd) {
        setViewYear(ymd.year);
        setViewMonth(ymd.month);
      }
    } else {
      setEndInputText(endDateValue ? formatDateByFormat(endDateValue, currentFormat) : '');
    }
  };

  const handleCommitStartTimeInput = () => {
    const parsedTime = parseTimeInput(startTimeInputText);
    if (parsedTime) {
      updateDate({ time: parsedTime });
    } else {
      setStartTimeInputText(formatTimeString(element.time || '11:37', currentTimeFormat));
    }
  };

  const handleCommitEndTimeInput = () => {
    const parsedTime = parseTimeInput(endTimeInputText);
    if (parsedTime) {
      updateDate({ endTime: parsedTime });
    } else {
      setEndTimeInputText(formatTimeString(element.endTime || '16:40', currentTimeFormat));
    }
  };

  const handleToggleRange = (enabled: boolean) => {
    if (enabled) {
      const startYMD = parseYMD(dateValue) || {
        year: today.getFullYear(),
        month: today.getMonth(),
        day: today.getDate(),
      };
      const nextDay = new Date(startYMD.year, startYMD.month, startYMD.day + 2);
      const nextDayIso = toIsoDate(nextDay.getFullYear(), nextDay.getMonth(), nextDay.getDate());
      updateDate({
        endDate: nextDayIso,
        endTime: element.time ? '16:40' : undefined,
      });
      setActiveTarget('end');
    } else {
      updateDate({
        endDate: undefined,
        endTime: undefined,
      });
      setActiveTarget('start');
    }
  };

  const handleToggleTime = (enabled: boolean) => {
    if (enabled) {
      updateDate({
        includeTime: true,
        time: element.time || '23:37',
        endTime: hasRange ? element.endTime || '16:40' : undefined,
      });
    } else {
      updateDate({
        includeTime: false,
      });
    }
  };

  // Calendar day cells calculation
  const calendarCells = React.useMemo(() => {
    const firstDayIndex = new Date(viewYear, viewMonth, 1).getDay(); // 0 = Sun
    const daysInCurrentMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
    const daysInPrevMonth = new Date(viewYear, viewMonth, 0).getDate();

    const cells: Array<{
      year: number;
      month: number;
      day: number;
      iso: string;
      isCurrentMonth: boolean;
      isToday: boolean;
      isStartDate: boolean;
      isEndDate: boolean;
      isInRange: boolean;
    }> = [];

    const now = new Date();
    const todayIso = toIsoDate(now.getFullYear(), now.getMonth(), now.getDate());

    // Previous month filler days
    for (let i = firstDayIndex - 1; i >= 0; i--) {
      const d = daysInPrevMonth - i;
      const prevM = viewMonth === 0 ? 11 : viewMonth - 1;
      const prevY = viewMonth === 0 ? viewYear - 1 : viewYear;
      const iso = toIsoDate(prevY, prevM, d);
      cells.push({
        year: prevY,
        month: prevM,
        day: d,
        iso,
        isCurrentMonth: false,
        isToday: iso === todayIso,
        isStartDate: iso === dateValue,
        isEndDate: Boolean(hasRange && iso === endDateValue),
        isInRange: Boolean(hasRange && endDateValue && iso > dateValue && iso < endDateValue),
      });
    }

    // Current month days
    for (let d = 1; d <= daysInCurrentMonth; d++) {
      const iso = toIsoDate(viewYear, viewMonth, d);
      cells.push({
        year: viewYear,
        month: viewMonth,
        day: d,
        iso,
        isCurrentMonth: true,
        isToday: iso === todayIso,
        isStartDate: iso === dateValue,
        isEndDate: Boolean(hasRange && iso === endDateValue),
        isInRange: Boolean(hasRange && endDateValue && iso > dateValue && iso < endDateValue),
      });
    }

    // Next month filler days (fill up to 35 or 42)
    const totalRemaining = (7 - (cells.length % 7)) % 7;
    const nextM = viewMonth === 11 ? 0 : viewMonth + 1;
    const nextY = viewMonth === 11 ? viewYear + 1 : viewYear;
    for (let d = 1; d <= totalRemaining; d++) {
      const iso = toIsoDate(nextY, nextM, d);
      cells.push({
        year: nextY,
        month: nextM,
        day: d,
        iso,
        isCurrentMonth: false,
        isToday: iso === todayIso,
        isStartDate: iso === dateValue,
        isEndDate: Boolean(hasRange && iso === endDateValue),
        isInRange: Boolean(hasRange && endDateValue && iso > dateValue && iso < endDateValue),
      });
    }

    return cells;
  }, [viewYear, viewMonth, dateValue, endDateValue, hasRange]);

  const trigger = (
    <button
      type="button"
      contentEditable={false}
      data-plate-prevent-deselect
      suppressHydrationWarning
      onClick={() => setOpen((prev) => !prev)}
      onKeyDown={(e) => {
        if (e.key === 'Backspace' || e.key === 'Delete') {
          e.preventDefault();
          handleClear();
        }
      }}
      className={cn(
        'inline-flex cursor-pointer select-none items-center gap-1.5 rounded-md px-2 py-0.5 text-xs font-medium transition-colors border',
        'bg-lime-400/10 text-lime-400 border-lime-400/30 hover:bg-lime-400/20',
        selected && 'ring-1 ring-lime-400 border-lime-400',
      )}
    >
      <CalendarIcon className="h-3 w-3 shrink-0 text-lime-400" />
      <span suppressHydrationWarning>{getDateLabel(element)}</span>
      {hasReminder && (
        <AlarmClock
          className="h-3 w-3 shrink-0 text-lime-400 ml-0.5"
          aria-label={`Reminder: ${getReminderLabel(currentReminder)}`}
        />
      )}
    </button>
  );

  return (
    <PlateElement {...props} as="span" className="inline-flex items-center align-baseline mx-0.5">
      {readOnly ? (
        <TooltipProvider delayDuration={200}>
          <Tooltip>
            <TooltipTrigger asChild>{trigger}</TooltipTrigger>
            <TooltipContent
              side="top"
              sideOffset={6}
              className="z-50 rounded-lg border border-zinc-800 bg-[#18181b] px-2.5 py-1 text-xs font-medium text-zinc-200 shadow-xl backdrop-blur-md"
            >
              {getFullTooltipLabel(element)}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      ) : (
        <TooltipProvider delayDuration={200}>
          <Tooltip open={open ? false : undefined}>
            <Popover open={open} onOpenChange={setOpen}>
              <TooltipTrigger asChild>
                <PopoverTrigger asChild>{trigger}</PopoverTrigger>
              </TooltipTrigger>

              <TooltipContent
                side="top"
                sideOffset={6}
                className="z-50 rounded-lg border border-zinc-800 bg-[#18181b] px-2.5 py-1 text-xs font-medium text-zinc-200 shadow-xl backdrop-blur-md"
              >
                {getFullTooltipLabel(element)}
              </TooltipContent>

              <PopoverContent
                align="start"
                sideOffset={6}
                className="w-[276px] p-3.5 space-y-3 z-50 bg-[#202020] border border-[#333333] shadow-2xl backdrop-blur-xl rounded-xl text-zinc-100 select-none animate-in fade-in zoom-in-95 duration-150"
              >
                {/* TOP INPUT BAR (Sleek Notion style) */}
                {!hasRange ? (
                  <div className="rounded-lg border border-[#383838] bg-[#2a2a2a]/70 px-2.5 py-1.5 flex items-center">
                    <input
                      type="text"
                      value={startInputText}
                      onChange={(e) => setStartInputText(e.target.value)}
                      onBlur={handleCommitStartInput}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') e.currentTarget.blur();
                      }}
                      style={{ outline: 'none', boxShadow: 'none' }}
                      className="flex-1 min-w-0 bg-transparent text-left text-sm font-normal text-zinc-100 placeholder-zinc-500 outline-none focus:outline-none focus:ring-0 focus-visible:outline-none focus-visible:ring-0 focus-visible:shadow-none shadow-none border-none ring-0"
                      placeholder="e.g. Oct 4, 2026 or Today"
                    />
                    {includeTime && (
                      <>
                        <div className="h-4 w-px bg-zinc-700 mx-2.5 shrink-0" />
                        <input
                          type="text"
                          value={startTimeInputText}
                          onChange={(e) => setStartTimeInputText(e.target.value)}
                          onBlur={handleCommitStartTimeInput}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') e.currentTarget.blur();
                          }}
                          style={{ outline: 'none', boxShadow: 'none' }}
                          className="w-20 shrink-0 bg-transparent text-left text-sm font-normal text-zinc-100 placeholder-zinc-500 outline-none focus:outline-none focus:ring-0 focus-visible:outline-none focus-visible:ring-0 focus-visible:shadow-none shadow-none border-none ring-0"
                          placeholder="11:37 PM"
                        />
                      </>
                    )}
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    <div
                      className={cn(
                        'rounded-lg border px-2.5 py-1.5 flex items-center transition-colors',
                        activeTarget === 'start'
                          ? 'border-zinc-400 bg-zinc-800/60'
                          : 'border-[#383838] bg-[#2a2a2a]/70',
                      )}
                    >
                      <input
                        type="text"
                        value={startInputText}
                        onFocus={() => setActiveTarget('start')}
                        onChange={(e) => setStartInputText(e.target.value)}
                        onBlur={handleCommitStartInput}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') e.currentTarget.blur();
                        }}
                        style={{ outline: 'none', boxShadow: 'none' }}
                        className="flex-1 min-w-0 bg-transparent text-left text-sm font-normal text-zinc-100 placeholder-zinc-500 outline-none focus:outline-none focus:ring-0 focus-visible:outline-none focus-visible:ring-0 focus-visible:shadow-none shadow-none border-none ring-0"
                        placeholder="Start date..."
                      />
                      {includeTime && (
                        <>
                          <div className="h-4 w-px bg-zinc-700 mx-2.5 shrink-0" />
                          <input
                            type="text"
                            value={startTimeInputText}
                            onFocus={() => setActiveTarget('start')}
                            onChange={(e) => setStartTimeInputText(e.target.value)}
                            onBlur={handleCommitStartTimeInput}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') e.currentTarget.blur();
                            }}
                            style={{ outline: 'none', boxShadow: 'none' }}
                            className="w-20 shrink-0 bg-transparent text-left text-sm font-normal text-zinc-100 placeholder-zinc-500 outline-none focus:outline-none focus:ring-0 focus-visible:outline-none focus-visible:ring-0 focus-visible:shadow-none shadow-none border-none ring-0"
                            placeholder="11:37 PM"
                          />
                        </>
                      )}
                    </div>

                    <div
                      className={cn(
                        'rounded-lg border px-2.5 py-1.5 flex items-center transition-colors',
                        activeTarget === 'end'
                          ? 'border-zinc-400 bg-zinc-800/60'
                          : 'border-[#383838] bg-[#2a2a2a]/70',
                      )}
                    >
                      <input
                        type="text"
                        value={endInputText}
                        onFocus={() => setActiveTarget('end')}
                        onChange={(e) => setEndInputText(e.target.value)}
                        onBlur={handleCommitEndInput}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') e.currentTarget.blur();
                        }}
                        style={{ outline: 'none', boxShadow: 'none' }}
                        className="flex-1 min-w-0 bg-transparent text-left text-sm font-normal text-zinc-100 placeholder-zinc-500 outline-none focus:outline-none focus:ring-0 focus-visible:outline-none focus-visible:ring-0 focus-visible:shadow-none shadow-none border-none ring-0"
                        placeholder="End date..."
                      />
                      {includeTime && (
                        <>
                          <div className="h-4 w-px bg-zinc-700 mx-2.5 shrink-0" />
                          <input
                            type="text"
                            value={endTimeInputText}
                            onFocus={() => setActiveTarget('end')}
                            onChange={(e) => setEndTimeInputText(e.target.value)}
                            onBlur={handleCommitEndTimeInput}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') e.currentTarget.blur();
                            }}
                            style={{ outline: 'none', boxShadow: 'none' }}
                            className="w-20 shrink-0 bg-transparent text-left text-sm font-normal text-zinc-100 placeholder-zinc-500 outline-none focus:outline-none focus:ring-0 focus-visible:outline-none focus-visible:ring-0 focus-visible:shadow-none shadow-none border-none ring-0"
                            placeholder="11:37 PM"
                          />
                        </>
                      )}
                    </div>
                  </div>
                )}

                {/* CALENDAR SECTION */}
                <div className="space-y-1">
                  {/* Header: Month Year + Now/Today + Arrows */}
                  <div className="flex items-center justify-between px-1">
                    <span className="text-sm font-semibold text-white tracking-tight">
                      {MONTH_NAMES[viewMonth]} {viewYear}
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={handleTodayOrNowClick}
                        className="rounded px-1.5 py-0.5 text-xs font-normal text-zinc-400 hover:text-white transition-colors cursor-pointer"
                      >
                        {includeTime ? 'Now' : 'Today'}
                      </button>
                      <button
                        type="button"
                        onClick={handlePrevMonth}
                        className="p-1 rounded text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
                        aria-label="Previous Month"
                      >
                        <ChevronLeft className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={handleNextMonth}
                        className="p-1 rounded text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
                        aria-label="Next Month"
                      >
                        <ChevronRight className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Day of week labels */}
                  <div className="grid grid-cols-7 text-center text-xs text-zinc-400 font-normal py-1">
                    {WEEKDAY_NAMES.map((name) => (
                      <div key={name} className="py-0.5">
                        {name}
                      </div>
                    ))}
                  </div>

                  {/* Day cells grid */}
                  <div className="grid grid-cols-7 gap-y-1 text-center">
                    {calendarCells.map((cell) => {
                      const isSelected = cell.isStartDate || cell.isEndDate;

                      return (
                        <div
                          key={cell.iso}
                          className={cn(
                            'relative flex items-center justify-center h-7.5',
                            cell.isInRange && 'bg-lime-400/15',
                            cell.isStartDate && hasRange && 'rounded-l-md bg-lime-400/20',
                            cell.isEndDate && hasRange && 'rounded-r-md bg-lime-400/20',
                          )}
                        >
                          <button
                            type="button"
                            onClick={() => handleSelectDay(cell.year, cell.month, cell.day)}
                            className={cn(
                              'h-7 w-7 rounded-md flex items-center justify-center text-sm font-normal transition-colors cursor-pointer',
                              cell.isCurrentMonth ? 'text-zinc-200' : 'text-zinc-600',
                              cell.isToday &&
                                !isSelected &&
                                'text-lime-400 font-semibold ring-1 ring-lime-400/50',
                              isSelected && 'bg-lime-400 text-black font-semibold shadow-sm',
                              !isSelected &&
                                !cell.isToday &&
                                'hover:bg-zinc-800/80 hover:text-white',
                            )}
                          >
                            {cell.day}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* SETTINGS ROWS */}
                <div className="space-y-2 pt-2.5 border-t border-zinc-800/80 text-sm">
                  {/* End date toggle */}
                  <div className="flex items-center justify-between py-0.5">
                    <span className="text-zinc-200">End date</span>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={hasRange}
                      onClick={() => handleToggleRange(!hasRange)}
                      className={cn(
                        'relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none',
                        hasRange ? 'bg-lime-400' : 'bg-zinc-700',
                      )}
                    >
                      <span
                        className={cn(
                          'pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out',
                          hasRange ? 'translate-x-4' : 'translate-x-0',
                        )}
                      />
                    </button>
                  </div>

                  {/* Date format selector (opens submenu outside to the right) */}
                  <div className="relative flex items-center justify-between py-0.5">
                    <span className="text-zinc-200">Date format</span>
                    <Popover open={showFormatMenu} onOpenChange={setShowFormatMenu}>
                      <PopoverTrigger asChild>
                        <button
                          type="button"
                          className="flex items-center gap-1 text-zinc-400 hover:text-zinc-200 transition-colors cursor-pointer"
                        >
                          <span>{getFormatDisplayLabel(currentFormat)}</span>
                          <ChevronRight className="h-3.5 w-3.5 text-zinc-500" />
                        </button>
                      </PopoverTrigger>
                      <PopoverContent
                        side="right"
                        align="start"
                        sideOffset={8}
                        className="w-48 rounded-xl border border-zinc-700/80 bg-[#252525] p-1.5 shadow-2xl space-y-0.5 z-[60] text-zinc-100"
                      >
                        {[
                          { id: 'relative' as const, label: 'Relative', preview: 'Tomorrow' },
                          { id: 'full' as const, label: 'Full date', preview: 'Oct 5, 2026' },
                          { id: 'short' as const, label: 'Short date', preview: 'Oct 5' },
                          { id: 'iso' as const, label: 'ISO', preview: '2026-10-05' },
                        ].map((fmt) => (
                          <button
                            key={fmt.id}
                            type="button"
                            onClick={() => {
                              updateDate({ displayFormat: fmt.id });
                              setShowFormatMenu(false);
                            }}
                            className={cn(
                              'w-full flex items-center justify-between rounded-lg px-2.5 py-1.5 text-left text-xs transition-colors cursor-pointer',
                              currentFormat === fmt.id
                                ? 'bg-lime-400/15 text-lime-400 font-medium'
                                : 'text-zinc-200 hover:bg-zinc-800',
                            )}
                          >
                            <span>{fmt.label}</span>
                            <span className="text-[11px] text-zinc-400">{fmt.preview}</span>
                          </button>
                        ))}
                      </PopoverContent>
                    </Popover>
                  </div>

                  {/* Include time toggle */}
                  <div className="flex items-center justify-between py-0.5">
                    <span className="text-zinc-200">Include time</span>
                    <button
                      type="button"
                      role="switch"
                      aria-checked={includeTime}
                      onClick={() => handleToggleTime(!includeTime)}
                      className={cn(
                        'relative inline-flex h-5 w-9 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none',
                        includeTime ? 'bg-lime-400' : 'bg-zinc-700',
                      )}
                    >
                      <span
                        className={cn(
                          'pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow-sm ring-0 transition duration-200 ease-in-out',
                          includeTime ? 'translate-x-4' : 'translate-x-0',
                        )}
                      />
                    </button>
                  </div>

                  {/* Time format & Timezone (shown when Include time is ON) */}
                  {includeTime && (
                    <>
                      <div className="flex items-center justify-between py-0.5">
                        <span className="text-zinc-200">Time format</span>
                        <button
                          type="button"
                          onClick={() => {
                            updateDate({
                              timeFormat: currentTimeFormat === '12h' ? '24h' : '12h',
                            });
                          }}
                          className="flex items-center gap-1 text-zinc-400 hover:text-zinc-200 transition-colors cursor-pointer"
                        >
                          <span>{currentTimeFormat === '12h' ? '12 hour' : '24 hour'}</span>
                          <ChevronRight className="h-3.5 w-3.5 text-zinc-500" />
                        </button>
                      </div>

                      <div className="flex items-center justify-between py-0.5">
                        <span className="text-zinc-200">Timezone</span>
                        <span className="flex items-center gap-1 text-zinc-400">
                          <span>{timeZoneStr}</span>
                          <ChevronRight className="h-3.5 w-3.5 text-zinc-500" />
                        </span>
                      </div>
                    </>
                  )}
                </div>

                {/* FOOTER ACTIONS: Clear date & Set remainder */}
                <div className="pt-2.5 border-t border-zinc-800/80 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={handleClear}
                    className="flex-1 py-1.5 px-2 rounded-lg border border-zinc-700/60 bg-zinc-800/40 text-xs font-medium text-zinc-400 hover:text-red-400 hover:border-red-500/40 hover:bg-red-500/10 transition-colors cursor-pointer text-center"
                  >
                    Clear
                  </button>

                  <Popover open={showReminderMenu} onOpenChange={setShowReminderMenu}>
                    <PopoverTrigger asChild>
                      <button
                        type="button"
                        className={cn(
                          'flex-1 py-1.5 px-2 rounded-lg border text-xs font-medium transition-colors cursor-pointer text-center flex items-center justify-center gap-1.5 truncate',
                          hasReminder
                            ? 'border-lime-400/50 bg-lime-400/15 text-lime-400'
                            : 'border-zinc-700/60 bg-zinc-800/40 text-zinc-300 hover:text-white hover:bg-zinc-800',
                        )}
                      >
                        <AlarmClock className="h-3.5 w-3.5 shrink-0" />
                        <span className="truncate">
                          {hasReminder ? getReminderLabel(currentReminder) : 'Set remainder'}
                        </span>
                      </button>
                    </PopoverTrigger>
                    <PopoverContent
                      side="right"
                      align="end"
                      sideOffset={8}
                      className="w-48 rounded-xl border border-zinc-700/80 bg-[#252525] p-1.5 shadow-2xl space-y-0.5 max-h-56 overflow-y-auto z-[60] text-zinc-100"
                    >
                      {[
                        { id: 'none' as const, label: 'None' },
                        { id: 'at_time' as const, label: 'On day of event' },
                        { id: '5m' as const, label: '5 minutes before' },
                        { id: '15m' as const, label: '15 minutes before' },
                        { id: '1h' as const, label: '1 hour before' },
                        { id: '1d' as const, label: '1 day before' },
                        { id: '2d' as const, label: '2 days before' },
                        { id: '1w' as const, label: '1 week before' },
                      ].map((rem) => (
                        <button
                          key={rem.id}
                          type="button"
                          onClick={() => {
                            updateDate({ reminder: rem.id });
                            setShowReminderMenu(false);
                          }}
                          className={cn(
                            'w-full flex items-center justify-between rounded-lg px-2.5 py-1.5 text-left text-xs transition-colors cursor-pointer',
                            currentReminder === rem.id
                              ? 'bg-lime-400/15 text-lime-400 font-medium'
                              : 'text-zinc-200 hover:bg-zinc-800',
                          )}
                        >
                          <span>{rem.label}</span>
                        </button>
                      ))}
                    </PopoverContent>
                  </Popover>
                </div>
              </PopoverContent>
            </Popover>
          </Tooltip>
        </TooltipProvider>
      )}
      {props.children}
    </PlateElement>
  );
}
