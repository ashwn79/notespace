'use client';

import { Image as ImageIcon, Link, Upload } from '@xpace/icons';
import { Button, cn } from '@xpace/ui';
import { AudioLines, FileUp, Film, Loader2 } from 'lucide-react';
import { KEYS } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement, useEditorRef } from 'platejs/react';
import type React from 'react';
import { useRef, useState } from 'react';
import type { EditorUploadAdapter } from '../types/adapters';

interface PlaceholderConfig {
  icon: React.ReactNode;
  title: string;
  accept: string;
  type: string;
}

const CONFIGS: Record<string, PlaceholderConfig> = {
  [KEYS.img]: {
    icon: <ImageIcon className="h-5 w-5 text-lime-400" />,
    title: 'Image',
    accept: 'image/*',
    type: KEYS.img,
  },
  [KEYS.video]: {
    icon: <Film className="h-5 w-5 text-lime-400" />,
    title: 'Video',
    accept: 'video/*',
    type: KEYS.video,
  },
  [KEYS.audio]: {
    icon: <AudioLines className="h-5 w-5 text-lime-400" />,
    title: 'Audio',
    accept: 'audio/*',
    type: KEYS.audio,
  },
  [KEYS.file]: {
    icon: <FileUp className="h-5 w-5 text-lime-400" />,
    title: 'File',
    accept: '*',
    type: KEYS.file,
  },
};

export function MediaPlaceholderElement(props: PlateElementProps) {
  const editor = useEditorRef();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState<'upload' | 'embed'>('upload');
  const [embedUrl, setEmbedUrl] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const mediaType = (props.element.mediaType as string) || KEYS.img;
  const config = CONFIGS[mediaType] ??
    CONFIGS[KEYS.img] ?? {
      type: KEYS.img,
      title: 'Image',
      icon: <ImageIcon className="h-4 w-4" />,
      accept: 'image/*',
    };

  const replaceWithMedia = (
    url: string,
    name?: string,
    meta?: { size?: number; mimeType?: string },
  ) => {
    const path = editor.api.findPath(props.element);
    if (!path) return;

    editor.tf.withoutSaving(() => {
      editor.tf.removeNodes({ at: path });
      editor.tf.insertNodes(
        {
          type: config.type,
          url,
          name: name || '',
          size: meta?.size,
          mimeType: meta?.mimeType,
          children: [{ text: '' }],
        },
        { at: path },
      );
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setUploadProgress(20);

    try {
      const adapter = (editor as unknown as { uploadAdapter?: EditorUploadAdapter }).uploadAdapter;
      let finalUrl = '';
      if (adapter?.upload) {
        setUploadProgress(50);
        const results = await adapter.upload([file], {
          kind: mediaType as 'image' | 'video' | 'audio' | 'file',
        });
        if (results?.[0]?.url) {
          finalUrl = results[0].url;
        }
      }

      if (!finalUrl) {
        finalUrl = URL.createObjectURL(file);
      }

      setUploadProgress(100);
      replaceWithMedia(finalUrl, file.name, { size: file.size, mimeType: file.type });
    } catch {
      replaceWithMedia(URL.createObjectURL(file), file.name, {
        size: file.size,
        mimeType: file.type,
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleEmbedSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (embedUrl.trim()) {
      replaceWithMedia(embedUrl.trim(), `${config.title} Embed`);
    }
  };

  return (
    <PlateElement {...props} className="my-2.5">
      <div
        contentEditable={false}
        className="rounded-xl border border-zinc-800 bg-zinc-900/50 p-4 shadow-sm select-none"
      >
        <div className="flex items-center justify-between mb-3 border-b border-zinc-800/80 pb-2.5">
          <div className="flex items-center gap-2 text-xs font-semibold text-zinc-200">
            {config.icon}
            <span>Add {config.title}</span>
          </div>

          <div className="flex items-center gap-1 rounded-lg bg-zinc-950 p-0.5 border border-zinc-800">
            <button
              type="button"
              onClick={() => setActiveTab('upload')}
              className={cn(
                'flex items-center gap-1 rounded px-2.5 py-1 text-[11px] font-medium transition-colors',
                activeTab === 'upload'
                  ? 'bg-zinc-800 text-white'
                  : 'text-zinc-400 hover:text-zinc-200',
              )}
            >
              <Upload className="h-3 w-3" />
              <span>Upload</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('embed')}
              className={cn(
                'flex items-center gap-1 rounded px-2.5 py-1 text-[11px] font-medium transition-colors',
                activeTab === 'embed'
                  ? 'bg-zinc-800 text-white'
                  : 'text-zinc-400 hover:text-zinc-200',
              )}
            >
              <Link className="h-3 w-3" />
              <span>Embed link</span>
            </button>
          </div>
        </div>

        {activeTab === 'upload' ? (
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept={config.accept}
              onChange={handleFileChange}
              className="hidden"
            />
            {isUploading ? (
              <div className="flex flex-col items-center justify-center py-6 gap-2 text-xs text-zinc-400">
                <Loader2 className="h-5 w-5 animate-spin text-lime-400" />
                <span>
                  Uploading {config.title.toLowerCase()}... {uploadProgress}%
                </span>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex flex-col items-center justify-center rounded-lg border border-dashed border-zinc-700/80 p-6 text-center hover:border-lime-400/50 hover:bg-zinc-800/30 transition-all cursor-pointer w-full"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-zinc-800 text-lime-400 mb-2">
                  <Upload className="h-5 w-5" />
                </div>
                <p className="text-xs font-medium text-zinc-200">
                  Click to choose a {config.title.toLowerCase()} file
                </p>
                <p className="text-[10px] text-zinc-500 mt-0.5">or drag and drop into the editor</p>
              </button>
            )}
          </div>
        ) : (
          <form onSubmit={handleEmbedSubmit} className="space-y-3 py-2">
            <div className="flex items-center gap-2">
              <input
                type="url"
                value={embedUrl}
                onChange={(e) => setEmbedUrl(e.target.value)}
                placeholder={`Paste ${config.title.toLowerCase()} URL or embed link...`}
                className="flex-1 rounded-lg border border-zinc-800 bg-zinc-950 px-3 py-1.5 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:ring-1 focus:ring-lime-400"
              />
              <Button
                type="submit"
                size="sm"
                className="h-8 text-xs bg-lime-400 hover:bg-lime-500 text-zinc-950 font-semibold px-3"
              >
                Embed {config.title}
              </Button>
            </div>
            <p className="text-[10px] text-zinc-500">
              Supports direct URLs (PNG, JPG, MP4, MP3, PDF) and embeds (YouTube, Vimeo).
            </p>
          </form>
        )}
      </div>
      {props.children}
    </PlateElement>
  );
}
