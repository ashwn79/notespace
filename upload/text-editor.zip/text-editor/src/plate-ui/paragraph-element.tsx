import { cn } from '@xpace/ui';
import { PlateElement, type PlateElementProps } from 'platejs/react';

export function ParagraphElement({ className, children, ...props }: PlateElementProps) {
  return (
    <PlateElement
      as={props.element.listStyleType ? 'div' : 'p'}
      className={cn('m-0 px-0 py-1 leading-relaxed text-foreground', className)}
      {...props}
    >
      {children}
    </PlateElement>
  );
}
