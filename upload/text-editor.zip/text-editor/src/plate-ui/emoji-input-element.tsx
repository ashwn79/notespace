'use client';

import emojiData from '@emoji-mart/data';
import { EmojiInlineIndexSearch } from '@platejs/emoji';
import { Smile } from 'lucide-react';
import type { TComboboxInputElement } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement, useEditorRef } from 'platejs/react';
import * as React from 'react';
import {
  InlineCombobox,
  InlineComboboxContent,
  InlineComboboxEmpty,
  InlineComboboxGroup,
  InlineComboboxGroupLabel,
  InlineComboboxInput,
  InlineComboboxItem,
} from './inline-combobox';

// EmojiInlineIndexSearch is a singleton; passing data directly initializes its internal library
const indexSearch = EmojiInlineIndexSearch.getInstance(emojiData as any);

interface EmojiItem {
  id: string;
  name: string;
  native: string;
  keywords?: string[];
}

const POPULAR_EMOJIS: EmojiItem[] = [
  {
    id: 'smile',
    name: 'Grinning Face with Smiling Eyes',
    native: '😄',
    keywords: ['smile', 'happy'],
  },
  { id: 'heart', name: 'Red Heart', native: '❤️', keywords: ['heart', 'love'] },
  { id: 'fire', name: 'Fire', native: '🔥', keywords: ['fire', 'hot', 'lit'] },
  {
    id: 'thumbsup',
    name: 'Thumbs Up',
    native: '👍',
    keywords: ['thumbsup', 'like', 'approve', '+1'],
  },
  { id: 'rocket', name: 'Rocket', native: '🚀', keywords: ['rocket', 'launch', 'fast'] },
  { id: 'sparkles', name: 'Sparkles', native: '✨', keywords: ['sparkles', 'magic', 'clean'] },
  { id: 'tada', name: 'Party Popper', native: '🎉', keywords: ['tada', 'party', 'celebrate'] },
  { id: 'eyes', name: 'Eyes', native: '👀', keywords: ['eyes', 'look', 'see'] },
  { id: 'check', name: 'Check Mark Button', native: '✅', keywords: ['check', 'done', 'todo'] },
  { id: 'bulb', name: 'Light Bulb', native: '💡', keywords: ['bulb', 'idea', 'light'] },
  { id: '100', name: 'Hundred Points', native: '💯', keywords: ['100', 'score', 'perfect'] },
  { id: 'zap', name: 'High Voltage', native: '⚡', keywords: ['zap', 'lightning', 'energy'] },
  { id: 'coffee', name: 'Hot Beverage', native: '☕', keywords: ['coffee', 'tea', 'drink'] },
  { id: 'books', name: 'Books', native: '📚', keywords: ['books', 'study', 'read'] },
  { id: 'pray', name: 'Folded Hands', native: '🙏', keywords: ['pray', 'thank you', 'please'] },
];

export function EmojiInputElement(props: PlateElementProps<TComboboxInputElement>) {
  const editor = useEditorRef();
  const [search, setSearch] = React.useState('');

  const filteredEmojis = React.useMemo<EmojiItem[]>(() => {
    const query = search.trim().toLowerCase();
    if (!query) {
      return POPULAR_EMOJIS;
    }
    const results = (
      indexSearch.search(query).get() as Array<{
        id: string;
        name: string;
        skins?: Array<{ native: string }>;
        keywords?: string[];
      }>
    ).slice(0, 16);

    return results.map((item) => ({
      id: item.id,
      name: item.name,
      native: item.skins?.[0]?.native || '😀',
      keywords: item.keywords,
    }));
  }, [search]);

  const insertEmojiChar = (nativeChar: string) => {
    editor.tf.insertText(nativeChar);
  };

  return (
    <PlateElement {...props} as="span">
      <InlineCombobox
        element={props.element}
        trigger=":"
        value={search}
        setValue={setSearch}
        filter={false}
      >
        <InlineComboboxInput />

        <InlineComboboxContent className="w-64 max-h-64">
          <InlineComboboxEmpty>No matching emoji</InlineComboboxEmpty>

          <InlineComboboxGroup>
            <InlineComboboxGroupLabel>
              <span className="flex items-center gap-1.5">
                <Smile className="h-3 w-3 text-amber-400" />
                <span>{search ? 'Matching Emojis' : 'Popular Emojis'}</span>
              </span>
            </InlineComboboxGroupLabel>

            {filteredEmojis.map((emoji) => (
              <InlineComboboxItem
                key={emoji.id}
                value={emoji.id}
                label={emoji.name}
                onClick={() => insertEmojiChar(emoji.native)}
                className="gap-2.5 py-1"
              >
                <span className="text-base select-none leading-none">{emoji.native}</span>
                <span className="text-xs text-zinc-300 truncate font-normal">:{emoji.id}:</span>
              </InlineComboboxItem>
            ))}
          </InlineComboboxGroup>
        </InlineComboboxContent>
      </InlineCombobox>
      {props.children}
    </PlateElement>
  );
}
