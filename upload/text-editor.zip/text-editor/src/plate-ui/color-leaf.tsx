'use client';

import type { PlateLeafProps } from 'platejs/react';
import { PlateLeaf } from 'platejs/react';

export function ColorLeaf({ leaf, children, style, ...props }: PlateLeafProps) {
  const color = (leaf as { color?: string })?.color;
  return (
    <PlateLeaf leaf={leaf} style={{ ...(color ? { color } : {}), ...style }} {...props}>
      {children}
    </PlateLeaf>
  );
}

export function BackgroundColorLeaf({ leaf, children, style, ...props }: PlateLeafProps) {
  const bg = (leaf as { backgroundColor?: string })?.backgroundColor;
  return (
    <PlateLeaf leaf={leaf} style={{ ...(bg ? { backgroundColor: bg } : {}), ...style }} {...props}>
      {children}
    </PlateLeaf>
  );
}
