'use client';

import {
  Caption as CaptionPrimitive,
  CaptionTextarea as CaptionTextareaPrimitive,
} from '@platejs/caption/react';
import { Button, cn } from '@xpace/ui';
import { useEditorRef, useElement } from 'platejs/react';
import React from 'react';

class CaptionErrorBoundary extends React.Component<
  { children: React.ReactNode; fallback?: React.ReactNode },
  { hasError: boolean }
> {
  constructor(props: { children: React.ReactNode; fallback?: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  override componentDidCatch(error: unknown) {
    console.warn('CaptionErrorBoundary caught error:', error);
  }

  override render() {
    if (this.state.hasError) {
      return this.props.fallback || null;
    }
    return this.props.children;
  }
}

export function Caption({
  children,
  className,
  align = 'center',
  style,
}: {
  children?: React.ReactNode;
  className?: string;
  align?: 'left' | 'center' | 'right';
  style?: React.CSSProperties;
}) {
  const element = useElement() as unknown as { caption?: unknown; hideCaption?: boolean };

  if (typeof element?.caption === 'string') {
    (element as { caption: unknown }).caption = [{ children: [{ text: element.caption }] }];
  } else if (Array.isArray(element?.caption)) {
    if (
      element.caption.length === 0 ||
      !element.caption[0] ||
      !Array.isArray((element.caption[0] as { children?: unknown[] })?.children)
    ) {
      (element as { caption: unknown[] }).caption = [{ children: [{ text: '' }] }];
    }
  }

  const hasCaptionText =
    typeof element?.caption === 'string'
      ? element.caption.trim().length > 0
      : Array.isArray(element?.caption) &&
        element.caption.some((node: any) => {
          if (typeof node?.text === 'string') return node.text.trim().length > 0;
          if (Array.isArray(node?.children)) {
            return node.children.some(
              (child: any) => typeof child?.text === 'string' && child.text.trim().length > 0,
            );
          }
          return false;
        });

  const isHidden =
    element?.hideCaption === true || (element?.hideCaption === undefined && !hasCaptionText);

  if (isHidden) {
    return null;
  }

  const fallback = (
    <figcaption
      className={cn(
        'mt-2 max-w-full text-center',
        align === 'left' && 'text-left',
        align === 'right' && 'text-right',
        className,
      )}
      style={style}
    >
      {children}
    </figcaption>
  );

  return (
    <CaptionErrorBoundary fallback={fallback}>
      <CaptionPrimitive
        className={cn(
          'mt-2 max-w-full text-center',
          align === 'left' && 'text-left',
          align === 'right' && 'text-right',
          className,
        )}
        style={style}
      >
        {children}
      </CaptionPrimitive>
    </CaptionErrorBoundary>
  );
}

export function CaptionTextarea({
  className,
  readOnly,
  ...props
}: React.ComponentProps<typeof CaptionTextareaPrimitive>) {
  return (
    <CaptionTextareaPrimitive
      className={cn(
        'w-full max-w-full resize-none border-none bg-transparent text-center text-xs text-muted-foreground outline-hidden focus:text-foreground placeholder:text-muted-foreground/50',
        readOnly && 'cursor-default select-text',
        className,
      )}
      readOnly={readOnly}
      {...props}
    />
  );
}

export function CaptionButton({ children, ...props }: React.ComponentProps<typeof Button>) {
  const editor = useEditorRef();
  const element = useElement() as unknown as {
    id: string;
    hideCaption?: boolean;
    caption?: unknown;
  };

  const isHidden = Boolean(element?.hideCaption);

  const handleToggleCaption = (e: React.MouseEvent) => {
    e.preventDefault();
    const path = editor.api.findPath(element as never);
    if (!path) return;

    if (isHidden) {
      editor.tf.setNodes({ hideCaption: false }, { at: path });
    } else {
      editor.tf.setNodes({ hideCaption: true }, { at: path });
    }
  };

  return (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      onMouseDown={(e) => e.preventDefault()}
      onClick={handleToggleCaption}
      className={cn('h-7 text-xs px-2', !isHidden && 'text-lime-400 font-medium')}
      {...props}
    >
      {children || (isHidden ? 'Show caption' : 'Hide caption')}
    </Button>
  );
}
