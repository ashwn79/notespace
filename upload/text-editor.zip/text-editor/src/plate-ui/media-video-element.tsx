'use client';

import { useMediaState, VideoPlugin } from '@platejs/media/react';
import { Resizable, ResizableProvider, useResizableValue } from '@platejs/resizable';
import { cn } from '@xpace/ui';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement, withHOC } from 'platejs/react';
import * as React from 'react';
import { Caption, CaptionTextarea } from './caption';
import { MediaToolbar } from './media-toolbar';
import { ResizeHandle } from './resize-handle';

export const MediaVideoElement = withHOC(
  ResizableProvider,
  function MediaVideoElement(props: PlateElementProps) {
    const { align = 'center', readOnly, selected } = useMediaState();
    const width = useResizableValue('width');
    const url = (props.element.url as string) || '';
    const figureRef = React.useRef<HTMLElement>(null);
    const [maxWidth, setMaxWidth] = React.useState<number>(800);

    React.useEffect(() => {
      const figure = figureRef.current;
      if (!figure) return;
      const parent = figure.parentElement;
      if (!parent) return;

      const updateWidth = () => {
        const clientWidth = parent.clientWidth;
        if (clientWidth > 0) {
          setMaxWidth(clientWidth);
        }
      };

      updateWidth();
      const ro = new ResizeObserver(updateWidth);
      ro.observe(parent);
      return () => ro.disconnect();
    }, []);

    const isYoutube = url.includes('youtube.com') || url.includes('youtu.be');
    const isVimeo = url.includes('vimeo.com');

    const getEmbedUrl = (raw: string) => {
      if (raw.includes('youtube.com/watch?v=')) {
        return raw.replace('watch?v=', 'embed/');
      }
      if (raw.includes('youtu.be/')) {
        return raw.replace('youtu.be/', 'www.youtube.com/embed/');
      }
      return raw;
    };

    return (
      <MediaToolbar plugin={VideoPlugin}>
        <PlateElement {...props} className="py-2.5">
          <figure
            ref={figureRef}
            className={cn(
              'group/media relative m-0 flex w-full max-w-full flex-col',
              align === 'left' && 'items-start',
              align === 'center' && 'items-center',
              align === 'right' && 'items-end',
            )}
            contentEditable={false}
          >
            <Resizable
              className="max-w-full"
              options={{
                align,
                readOnly,
                maxWidth,
                minWidth: 92,
              }}
            >
              <ResizeHandle options={{ direction: 'left' }} />
              <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-zinc-800 bg-zinc-950 shadow-md">
                {isYoutube || isVimeo ? (
                  <iframe
                    src={getEmbedUrl(url)}
                    title="Video embed"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="h-full w-full border-none"
                  />
                ) : (
                  <video
                    src={url}
                    controls
                    className={cn(
                      'h-full w-full object-contain',
                      selected && 'ring-2 ring-lime-400',
                    )}
                  >
                    <track kind="captions" />
                  </video>
                )}
              </div>
              <ResizeHandle options={{ direction: 'right' }} />
            </Resizable>

            <Caption align={align} style={{ width }}>
              <CaptionTextarea placeholder="Write a video caption..." readOnly={readOnly} />
            </Caption>
          </figure>
          {props.children}
        </PlateElement>
      </MediaToolbar>
    );
  },
);
