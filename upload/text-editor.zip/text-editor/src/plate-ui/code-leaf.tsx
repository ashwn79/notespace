import { cn } from '@xpace/ui';
import { PlateLeaf, type PlateLeafProps } from 'platejs/react';

export function CodeLeaf({ className, children, ...props }: PlateLeafProps) {
  return (
    <PlateLeaf
      as="code"
      className={cn(
        'rounded-md bg-muted px-1.5 py-0.5 font-mono text-sm font-medium text-foreground',
        className,
      )}
      {...props}
    >
      {children}
    </PlateLeaf>
  );
}
