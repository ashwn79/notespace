import { cn } from '@xpace/ui';
import { PlateElement, type PlateElementProps } from 'platejs/react';

export function HeadingElement({
  className,
  children,
  variant = 'h1',
  ...props
}: PlateElementProps & { variant?: 'h1' | 'h2' | 'h3' }) {
  const styles = {
    h1: 'mt-6 mb-2 text-2xl font-bold tracking-tight text-foreground first:mt-0',
    h2: 'mt-5 mb-2 text-xl font-semibold tracking-tight text-foreground first:mt-0',
    h3: 'mt-4 mb-1 text-lg font-semibold text-foreground first:mt-0',
  };

  return (
    <PlateElement
      as={props.element.listStyleType ? 'div' : variant}
      className={cn(styles[variant], className)}
      {...props}
    >
      {children}
    </PlateElement>
  );
}

export function H1Element(props: PlateElementProps) {
  return <HeadingElement variant="h1" {...props} />;
}

export function H2Element(props: PlateElementProps) {
  return <HeadingElement variant="h2" {...props} />;
}

export function H3Element(props: PlateElementProps) {
  return <HeadingElement variant="h3" {...props} />;
}
