'use client';

import {
  Combobox,
  ComboboxGroup,
  ComboboxGroupLabel,
  ComboboxItem,
  type ComboboxItemProps,
  ComboboxPopover,
  ComboboxProvider,
  ComboboxRow,
  Portal,
  useComboboxContext,
  useComboboxStore,
} from '@ariakit/react';
import { type UseComboboxInputResult, useComboboxInput } from '@platejs/combobox/react';
import { cn } from '@xpace/ui';
import type { PointRef, TElement } from 'platejs';
import { useComposedRef, useEditorRef } from 'platejs/react';
import * as React from 'react';

type FilterFn = (
  item: { value: string; group?: string; keywords?: string[]; label?: string },
  search: string,
) => boolean;

interface InlineComboboxContextValue {
  filter: FilterFn | false;
  inputProps: UseComboboxInputResult['props'];
  inputRef: React.RefObject<HTMLInputElement | null>;
  removeInput: UseComboboxInputResult['removeInput'];
  showTrigger: boolean;
  trigger: string;
  setHasEmpty: (hasEmpty: boolean) => void;
}

const InlineComboboxContext = React.createContext<InlineComboboxContextValue>(
  null as unknown as InlineComboboxContextValue,
);

export const defaultFilter: FilterFn = ({ group, keywords = [], label, value }, search) => {
  const query = search.toLowerCase().trim();
  if (!query) return true;
  if (value.toLowerCase().includes(query)) return true;
  if (label?.toLowerCase().includes(query)) return true;
  if (group?.toLowerCase().includes(query)) return true;
  return keywords.some((kw) => kw.toLowerCase().includes(query));
};

export function InlineCombobox({
  children,
  element,
  filter = defaultFilter,
  hideWhenNoValue = false,
  showTrigger = true,
  trigger,
  value: valueProp,
  setValue: setValueProp,
}: {
  children: React.ReactNode;
  element: TElement;
  filter?: FilterFn | false;
  hideWhenNoValue?: boolean;
  showTrigger?: boolean;
  trigger: string;
  value?: string;
  setValue?: (value: string) => void;
}) {
  const editor = useEditorRef();
  const inputRef = React.useRef<HTMLInputElement | null>(null);
  const [valueState, setValueState] = React.useState('');
  const hasValueProp = valueProp !== undefined;
  const value = hasValueProp ? valueProp : valueState;

  const setValue = React.useCallback(
    (newValue: string) => {
      setValueProp?.(newValue);
      if (!hasValueProp) {
        setValueState(newValue);
      }
    },
    [setValueProp, hasValueProp],
  );

  const insertPointRef = React.useRef<PointRef | null>(null);

  React.useEffect(() => {
    insertPointRef.current?.unref();
    insertPointRef.current = null;

    const path = editor.api.findPath(element);
    if (!path) return;

    const point = editor.api.before(path);
    if (!point) return;

    const pointRef = editor.api.pointRef(point);
    insertPointRef.current = pointRef;

    return () => {
      if (insertPointRef.current === pointRef) {
        insertPointRef.current = null;
      }
      pointRef.unref();
    };
  }, [editor, element]);

  const { props: inputProps, removeInput } = useComboboxInput({
    cancelInputOnBlur: true,
    autoFocus: true,
    ref: inputRef,
    onCancelInput: (cause) => {
      if (cause !== 'backspace') {
        editor.tf.insertText(trigger + value, {
          at: insertPointRef.current?.current ?? undefined,
        });
      }
      if (cause === 'arrowLeft' || cause === 'arrowRight') {
        editor.tf.move({
          distance: 1,
          reverse: cause === 'arrowLeft',
        });
      }
    },
  });

  const [hasEmpty, setHasEmpty] = React.useState(false);

  const contextValue: InlineComboboxContextValue = React.useMemo(
    () => ({
      filter,
      inputProps,
      inputRef,
      removeInput,
      setHasEmpty,
      showTrigger,
      trigger,
    }),
    [filter, inputProps, removeInput, showTrigger, trigger],
  );

  const store = useComboboxStore({
    setValue: (newValue) => React.startTransition(() => setValue(newValue)),
  });

  const items = store.useState('items');

  React.useEffect(() => {
    if (!store.getState().activeId) {
      store.setActiveId(store.first());
    }
  }, [store]);

  return (
    <span contentEditable={false}>
      <ComboboxProvider
        open={(items.length > 0 || hasEmpty) && (!hideWhenNoValue || value.length > 0)}
        store={store}
      >
        <InlineComboboxContext.Provider value={contextValue}>
          {children}
        </InlineComboboxContext.Provider>
      </ComboboxProvider>
    </span>
  );
}

export const InlineComboboxInput = ({
  className,
  ref: propRef,
  ...props
}: React.HTMLAttributes<HTMLInputElement> & {
  ref?: React.RefObject<HTMLInputElement | null>;
}) => {
  const {
    inputProps,
    inputRef: contextRef,
    showTrigger,
    trigger,
  } = React.useContext(InlineComboboxContext);

  const store = useComboboxContext();
  const value = store?.useState('value') ?? '';
  const ref = useComposedRef(propRef, contextRef);

  return (
    <>
      {showTrigger && trigger}
      <span className="relative min-h-[1lh]">
        <span aria-hidden="true" className="invisible overflow-hidden text-nowrap">
          {value || '\u200B'}
        </span>
        <Combobox
          autoSelect
          className={cn(
            'absolute top-0 left-0 size-full bg-transparent outline-none text-foreground font-medium',
            className,
          )}
          ref={ref}
          value={value}
          {...inputProps}
          {...props}
        />
      </span>
    </>
  );
};
InlineComboboxInput.displayName = 'InlineComboboxInput';

export const InlineComboboxContent = ({
  className,
  ...props
}: React.ComponentProps<typeof ComboboxPopover>) => {
  const store = useComboboxContext();

  function handleKeyDown(event: React.KeyboardEvent<HTMLDivElement>) {
    if (!store) return;
    const state = store.getState();
    const { items, activeId } = state;
    if (!items.length) return;

    const currentIndex = items.findIndex((item) => item.id === activeId);
    if (event.key === 'ArrowUp' && currentIndex <= 0) {
      event.preventDefault();
      store.setActiveId(store.last());
    } else if (event.key === 'ArrowDown' && currentIndex >= items.length - 1) {
      event.preventDefault();
      store.setActiveId(store.first());
    }
  }

  return (
    <Portal>
      <ComboboxPopover
        className={cn(
          'z-50 max-h-72 w-64 overflow-y-auto rounded-xl border border-zinc-800 bg-zinc-950/95 p-1 text-foreground shadow-2xl backdrop-blur-md outline-hidden',
          className,
        )}
        onKeyDownCapture={handleKeyDown}
        {...props}
      />
    </Portal>
  );
};

export const InlineComboboxItem = ({
  className,
  focusEditor = true,
  group,
  keywords,
  label,
  onClick,
  ...props
}: {
  focusEditor?: boolean;
  group?: string;
  keywords?: string[];
  label?: string;
} & ComboboxItemProps &
  Required<Pick<ComboboxItemProps, 'value'>>) => {
  const { value } = props;
  const { filter, removeInput } = React.useContext(InlineComboboxContext);
  const store = useComboboxContext();
  const storeValue = store?.useState('value');
  const search = filter ? (storeValue ?? '') : '';

  const visible = React.useMemo(
    () => !filter || filter({ group, keywords, label, value }, search as string),
    [filter, group, keywords, label, value, search],
  );

  if (!visible) return null;

  return (
    <ComboboxItem
      className={cn(
        'relative flex cursor-pointer select-none items-center gap-2 rounded-lg px-2 py-1.5 text-xs text-zinc-300 outline-none transition-colors',
        'hover:bg-zinc-800 hover:text-white',
        'data-[active-item=true]:bg-zinc-800 data-[active-item=true]:text-white',
        className,
      )}
      onClick={(event) => {
        removeInput(focusEditor);
        onClick?.(event);
      }}
      {...props}
    />
  );
};

export const InlineComboboxEmpty = ({
  children,
  className,
}: React.HTMLAttributes<HTMLDivElement>) => {
  const { setHasEmpty } = React.useContext(InlineComboboxContext);
  const store = useComboboxContext();
  const items = store?.useState('items') ?? [];

  React.useEffect(() => {
    setHasEmpty(true);
    return () => {
      setHasEmpty(false);
    };
  }, [setHasEmpty]);

  if (items.length > 0) return null;

  return (
    <div className={cn('px-2.5 py-3 text-center text-xs text-zinc-500 italic', className)}>
      {children}
    </div>
  );
};

export const InlineComboboxRow = ComboboxRow;

export function InlineComboboxGroup({
  className,
  ...props
}: React.ComponentProps<typeof ComboboxGroup>) {
  return (
    <ComboboxGroup
      {...props}
      className={cn('py-1 not-last:border-b not-last:border-zinc-800/60', className)}
    />
  );
}

export function InlineComboboxGroupLabel({
  className,
  ...props
}: React.ComponentProps<typeof ComboboxGroupLabel>) {
  return (
    <ComboboxGroupLabel
      {...props}
      className={cn(
        'px-2.5 py-1 text-[10px] font-semibold text-zinc-500 uppercase tracking-wider',
        className,
      )}
    />
  );
}
