'use client';

import { BlockSelectionPlugin } from '@platejs/selection/react';
import { Button, cn } from '@xpace/ui';
import { Baseline, Highlighter } from 'lucide-react';
import { useEditorRef } from 'platejs/react';
import * as React from 'react';
import { Popover, PopoverContent, PopoverTrigger } from './popover';

const TEXT_COLORS = [
  { label: 'Default', value: '', color: '#f4f4f5' },
  { label: 'Gray', value: '#71717a', color: '#71717a' },
  { label: 'Brown', value: '#92400e', color: '#92400e' },
  { label: 'Orange', value: '#ea580c', color: '#ea580c' },
  { label: 'Yellow', value: '#eab308', color: '#eab308' },
  { label: 'Green', value: '#22c55e', color: '#22c55e' },
  { label: 'Blue', value: '#3b82f6', color: '#3b82f6' },
  { label: 'Purple', value: '#a855f7', color: '#a855f7' },
  { label: 'Pink', value: '#ec4899', color: '#ec4899' },
  { label: 'Red', value: '#ef4444', color: '#ef4444' },
];

const BG_COLORS = [
  { label: 'None', value: '', bg: 'transparent' },
  { label: 'Gray', value: 'rgba(113, 113, 122, 0.35)', bg: 'rgba(113, 113, 122, 0.4)' },
  { label: 'Brown', value: 'rgba(146, 64, 14, 0.35)', bg: 'rgba(146, 64, 14, 0.4)' },
  { label: 'Orange', value: 'rgba(234, 88, 12, 0.35)', bg: 'rgba(234, 88, 12, 0.4)' },
  { label: 'Yellow', value: 'rgba(234, 179, 8, 0.35)', bg: 'rgba(234, 179, 8, 0.4)' },
  { label: 'Green', value: 'rgba(34, 197, 94, 0.35)', bg: 'rgba(34, 197, 94, 0.4)' },
  { label: 'Blue', value: 'rgba(59, 130, 246, 0.35)', bg: 'rgba(59, 130, 246, 0.4)' },
  { label: 'Purple', value: 'rgba(168, 85, 247, 0.35)', bg: 'rgba(168, 85, 247, 0.4)' },
  { label: 'Pink', value: 'rgba(236, 72, 153, 0.35)', bg: 'rgba(236, 72, 153, 0.4)' },
  { label: 'Red', value: 'rgba(239, 68, 68, 0.35)', bg: 'rgba(239, 68, 68, 0.4)' },
];

export function ColorDropdown() {
  const editor = useEditorRef();
  const [open, setOpen] = React.useState(false);
  const savedSelectionRef = React.useRef(editor.selection);

  const handleOpenChange = (nextOpen: boolean) => {
    if (nextOpen && editor.selection) {
      savedSelectionRef.current = editor.selection;
    }
    setOpen(nextOpen);
  };

  const handleTextColor = (color: string) => {
    // Restore selection if blurred or collapsed
    if (savedSelectionRef.current) {
      editor.tf.select(savedSelectionRef.current);
    }

    const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;
    const nodes = blockSelectionApi ? blockSelectionApi.getNodes() : [];

    if (nodes.length > 0) {
      editor.tf.withoutNormalizing(() => {
        nodes.forEach(([, path]) => {
          if (!color) {
            editor.tf.unsetNodes('color', { at: path, match: (n) => 'text' in n });
          } else {
            editor.tf.setNodes({ color }, { at: path, match: (n) => 'text' in n });
          }
        });
      });
    } else {
      if (!color) {
        editor.tf.removeMark('color');
      } else {
        editor.tf.addMark('color', color);
      }
    }

    setOpen(false);
    editor.tf.focus();
  };

  const handleBgColor = (backgroundColor: string) => {
    if (savedSelectionRef.current) {
      editor.tf.select(savedSelectionRef.current);
    }

    const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;
    const nodes = blockSelectionApi ? blockSelectionApi.getNodes() : [];

    if (nodes.length > 0) {
      editor.tf.withoutNormalizing(() => {
        nodes.forEach(([, path]) => {
          if (!backgroundColor) {
            editor.tf.unsetNodes(['backgroundColor', 'highlight'], {
              at: path,
              match: (n) => 'text' in n,
            });
          } else {
            editor.tf.setNodes(
              { backgroundColor, highlight: true },
              { at: path, match: (n) => 'text' in n },
            );
          }
        });
      });
    } else {
      if (!backgroundColor) {
        editor.tf.removeMark('backgroundColor');
        editor.tf.removeMark('highlight');
      } else {
        editor.tf.addMark('backgroundColor', backgroundColor);
        editor.tf.addMark('highlight', true);
      }
    }

    setOpen(false);
    editor.tf.focus();
  };

  return (
    <Popover open={open} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          onMouseDown={(e) => {
            e.preventDefault();
            if (editor.selection) {
              savedSelectionRef.current = editor.selection;
            }
          }}
          className={cn(
            'h-7 w-7 p-0 text-muted-foreground hover:text-foreground hover:bg-zinc-800 transition-colors',
            open && 'bg-zinc-800 text-lime-400',
          )}
          title="Text & background colors"
        >
          <Baseline className="h-3.5 w-3.5" />
        </Button>
      </PopoverTrigger>
      <PopoverContent
        align="start"
        sideOffset={6}
        data-plate-prevent-deselect
        onOpenAutoFocus={(e) => e.preventDefault()}
        className="w-56 p-2 z-50 bg-zinc-950/95 border-zinc-800 shadow-2xl backdrop-blur-md rounded-xl"
      >
        <div className="px-1.5 py-1 text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">
          Text color
        </div>
        <div className="grid grid-cols-5 gap-1 p-0.5">
          {TEXT_COLORS.map((c) => (
            <button
              type="button"
              key={c.label}
              data-plate-prevent-deselect
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => handleTextColor(c.value)}
              title={c.label}
              className={cn(
                'flex h-7 w-full cursor-pointer items-center justify-center rounded border border-zinc-800 hover:border-zinc-500 transition-colors',
                !c.value && 'bg-zinc-800/40 text-zinc-300 font-semibold text-[10px]',
              )}
              style={{ color: c.color }}
            >
              {c.value ? <Baseline className="h-3.5 w-3.5" /> : 'A'}
            </button>
          ))}
        </div>

        <div className="h-px bg-zinc-800/80 my-2" />

        <div className="px-1.5 py-1 text-[10px] font-semibold text-zinc-500 uppercase tracking-wider">
          Highlight
        </div>
        <div className="grid grid-cols-5 gap-1 p-0.5">
          {BG_COLORS.map((bg) => (
            <button
              type="button"
              key={bg.label}
              data-plate-prevent-deselect
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => handleBgColor(bg.value)}
              title={bg.label}
              className={cn(
                'flex h-7 w-full cursor-pointer items-center justify-center rounded border border-zinc-800 hover:border-zinc-500 transition-colors',
                !bg.value && 'bg-zinc-800/40 text-zinc-400 text-[10px]',
              )}
              style={{ backgroundColor: bg.bg }}
            >
              {bg.value ? (
                <Highlighter className="h-3 w-3 text-white" />
              ) : (
                <span className="text-[10px] text-zinc-400">✕</span>
              )}
            </button>
          ))}
        </div>
      </PopoverContent>
    </Popover>
  );
}
