'use client';

import { cn } from '@xpace/ui';
import type { PlateLeafProps } from 'platejs/react';
import { PlateLeaf } from 'platejs/react';

export function CommentLeaf(props: PlateLeafProps) {
  return (
    <PlateLeaf
      {...props}
      className={cn(
        'border-b border-amber-400/80 bg-amber-400/15 text-foreground transition-colors hover:bg-amber-400/25 cursor-pointer',
        props.className,
      )}
    >
      {props.children}
    </PlateLeaf>
  );
}
