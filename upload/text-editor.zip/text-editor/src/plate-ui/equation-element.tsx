'use client';

import { useEquationElement } from '@platejs/math/react';
import { Button, cn } from '@xpace/ui';
import { CornerDownLeft, Sigma } from 'lucide-react';
import type { TEquationElement } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement, useEditorRef, useReadOnly, useSelected } from 'platejs/react';
import { useEffect, useRef, useState } from 'react';
import TextareaAutosize from 'react-textarea-autosize';
import { Popover, PopoverContent, PopoverTrigger } from './popover';

export function EquationElement(props: PlateElementProps<TEquationElement>) {
  const editor = useEditorRef();
  const readOnly = useReadOnly();
  const selected = useSelected();
  const [open, setOpen] = useState(false);
  const katexRef = useRef<HTMLDivElement | null>(null);

  const texExpression = String(props.element.texExpression || '');
  const [inputValue, setInputValue] = useState(texExpression);

  useEffect(() => {
    setInputValue(texExpression);
  }, [texExpression]);

  useEquationElement({
    element: props.element,
    katexRef,
    options: {
      displayMode: true,
      errorColor: '#ef4444',
      throwOnError: false,
    },
  });

  const handleDone = () => {
    setOpen(false);
    const path = editor.api.findPath(props.element);
    if (path) {
      editor.tf.setNodes({ texExpression: inputValue }, { at: path });
    }
  };

  return (
    <PlateElement className="my-2" {...props}>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            type="button"
            contentEditable={false}
            className={cn(
              'group flex cursor-pointer select-none items-center justify-center rounded-xl border border-zinc-800/80 bg-zinc-900/40 p-3 transition-colors hover:border-zinc-700 w-full',
              selected && 'ring-1 ring-lime-400/50 border-lime-400/50',
            )}
          >
            {texExpression.length > 0 ? (
              <div ref={katexRef} className="overflow-x-auto py-1 text-foreground" />
            ) : (
              <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
                <Sigma className="h-4 w-4 text-lime-400" />
                <span>Click to enter LaTeX equation...</span>
              </div>
            )}
          </button>
        </PopoverTrigger>

        {!readOnly && (
          <PopoverContent align="center" className="w-80 p-3">
            <div className="space-y-2.5">
              <div className="flex items-center justify-between text-xs font-semibold text-zinc-300">
                <span className="flex items-center gap-1.5">
                  <Sigma className="h-3.5 w-3.5 text-lime-400" />
                  <span>LaTeX Equation</span>
                </span>
                <span className="text-[10px] text-zinc-500 font-mono">Block</span>
              </div>
              <TextareaAutosize
                minRows={2}
                maxRows={6}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="e.g. f(x) = \int_{-\infty}^\infty e^{-x^2} dx"
                className="w-full resize-none rounded-lg border border-zinc-800 bg-zinc-900 px-2.5 py-1.5 text-xs font-mono text-white placeholder:text-zinc-600 focus:outline-none focus:ring-1 focus:ring-lime-400"
              />
              <div className="flex justify-end">
                <Button
                  size="sm"
                  onClick={handleDone}
                  className="h-7 text-xs bg-lime-400 hover:bg-lime-500 text-zinc-950 font-semibold gap-1"
                >
                  <span>Done</span>
                  <CornerDownLeft className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </PopoverContent>
        )}
      </Popover>
      {props.children}
    </PlateElement>
  );
}

export function InlineEquationElement(props: PlateElementProps<TEquationElement>) {
  const editor = useEditorRef();
  const readOnly = useReadOnly();
  const selected = useSelected();
  const [open, setOpen] = useState(false);
  const katexRef = useRef<HTMLDivElement | null>(null);

  const texExpression = String(props.element.texExpression || '');
  const [inputValue, setInputValue] = useState(texExpression);

  useEffect(() => {
    setInputValue(texExpression);
  }, [texExpression]);

  useEquationElement({
    element: props.element,
    katexRef,
    options: {
      displayMode: false,
      errorColor: '#ef4444',
      throwOnError: false,
    },
  });

  const handleDone = () => {
    setOpen(false);
    const path = editor.api.findPath(props.element);
    if (path) {
      editor.tf.setNodes({ texExpression: inputValue }, { at: path });
    }
  };

  return (
    <PlateElement {...props} as="span" className="inline-flex items-center align-baseline mx-0.5">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            type="button"
            contentEditable={false}
            onKeyDown={(e) => {
              if (e.key === ' ') {
                e.preventDefault();
                e.stopPropagation();
                setOpen(true);
              }
            }}
            className={cn(
              'inline-flex cursor-pointer select-none items-center rounded px-1.5 py-0.5 text-xs font-mono transition-colors focus:outline-none',
              'bg-zinc-800/80 hover:bg-zinc-800 text-foreground border border-zinc-700/60',
              selected && 'ring-1 ring-lime-400 border-lime-400',
            )}
          >
            {texExpression.length > 0 ? (
              <span ref={katexRef} />
            ) : (
              <span className="text-zinc-500">f(x)</span>
            )}
          </button>
        </PopoverTrigger>

        {!readOnly && (
          <PopoverContent
            align="center"
            className="w-72 p-2.5 z-50 bg-zinc-950/95 border-zinc-800 shadow-2xl backdrop-blur-md"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between text-[11px] font-semibold text-zinc-300">
                <span>Inline Formula</span>
                <span className="text-[10px] text-zinc-500 font-mono">LaTeX</span>
              </div>
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleDone();
                  } else if (e.key === 'Escape') {
                    e.preventDefault();
                    setOpen(false);
                    editor.tf.focus();
                  }
                }}
                placeholder="e.g. E = mc^2"
                className="w-full rounded-md border border-zinc-800 bg-zinc-900 px-2 py-1 text-xs font-mono text-white placeholder:text-zinc-600 focus:outline-none focus:ring-1 focus:ring-lime-400"
              />
              <div className="flex justify-end">
                <Button
                  size="sm"
                  onClick={handleDone}
                  className="h-6 px-2 text-[11px] bg-lime-400 hover:bg-lime-500 text-zinc-950 font-semibold"
                >
                  Done
                </Button>
              </div>
            </div>
          </PopoverContent>
        )}
      </Popover>
      {props.children}
    </PlateElement>
  );
}
