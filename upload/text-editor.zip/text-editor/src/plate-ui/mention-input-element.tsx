'use client';

import { formatDateValue, insertDate } from '@platejs/date';
import { Calendar, FileText, User } from '@xpace/icons';
import { ChevronDown } from 'lucide-react';
import { AlarmClock } from 'lucide-react';
import { KEYS, type TComboboxInputElement } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement, useEditorRef } from 'platejs/react';
import * as React from 'react';
import {
  defaultFilter,
  InlineCombobox,
  InlineComboboxContent,
  InlineComboboxEmpty,
  InlineComboboxGroup,
  InlineComboboxGroupLabel,
  InlineComboboxInput,
  InlineComboboxItem,
} from './inline-combobox';

import { ALL_PAGES, INITIAL_TEAM_MEMBERS, MORE_TEAM_MEMBERS } from './mention-data';

interface MentionEntry {
  id: string;
  label: string;
  /** date inserts a DateElement directly; person/page insert a mention node */
  category: 'date' | 'person' | 'page';
  dateValue?: string;
  reminder?: 'at_time' | 'none';
  description?: string;
  role?: string;
  keywords?: string[];
}

// Show first 3 people initially
const INITIAL_TEAM: MentionEntry[] = INITIAL_TEAM_MEMBERS.slice(0, 3).map((m) => ({
  ...m,
  category: 'person',
}));

const MORE_TEAM: MentionEntry[] = [
  ...INITIAL_TEAM_MEMBERS.slice(3),
  ...MORE_TEAM_MEMBERS,
].map((m) => ({
  ...m,
  category: 'person',
}));

const PAGE_ENTRIES: MentionEntry[] = ALL_PAGES.map((p) => ({
  ...p,
  category: 'page',
}));

export function MentionInputElement(props: PlateElementProps<TComboboxInputElement>) {
  const editor = useEditorRef();
  const [search, setSearch] = React.useState('');
  const [showAllTeam, setShowAllTeam] = React.useState(false);

  // Only two date shortcuts: Today and Remind me
  const dateItems = React.useMemo<MentionEntry[]>(() => {
    const today = new Date();
    const todayValue = formatDateValue(today);
    const label = today.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
    return [
      {
        id: 'today',
        label: 'Today',
        description: label,
        dateValue: todayValue,
        reminder: 'none',
        category: 'date',
        keywords: ['today', 'date', 'now', label],
      },
      {
        id: 'remind_me',
        label: 'Remind me',
        description: 'Today with reminder',
        dateValue: todayValue,
        reminder: 'at_time',
        category: 'date',
        keywords: ['remind', 'reminder', 'alarm', 'date', label],
      },
    ];
  }, []);

  const teamList = React.useMemo(() => {
    if (search.trim().length > 0 || showAllTeam) {
      return [...INITIAL_TEAM, ...MORE_TEAM];
    }
    return INITIAL_TEAM;
  }, [search, showAllTeam]);

  const handleSelect = (item: MentionEntry) => {
    // Date → insert a native DateElement (edited via DateElement popover)
    if (item.category === 'date' && item.dateValue) {
      insertDate(editor, {
        date: item.dateValue,
        // Attach reminder if "Remind me" was chosen
        ...(item.reminder && item.reminder !== 'none' ? { reminder: item.reminder } : {}),
        select: true,
      });
      return;
    }

    // Person / Page → insert a mention node (edited via mention-element popover — People+Pages only)
    editor.tf.insertNodes([
      {
        type: editor.getType(KEYS.mention),
        key: `${item.category}:${item.id}`,
        value: item.label,
        category: item.category,
        children: [{ text: '' }],
      },
      { text: ' ' },
    ]);
    editor.tf.move({ distance: 1 });
  };

  return (
    <PlateElement {...props} as="span">
      <InlineCombobox
        element={props.element}
        trigger="@"
        value={search}
        setValue={setSearch}
        filter={defaultFilter}
      >
        <InlineComboboxInput />

        <InlineComboboxContent className="w-80 max-h-80 overflow-y-auto z-50 p-1 bg-zinc-950/95 border-zinc-800 shadow-2xl backdrop-blur-md rounded-xl">
          <InlineComboboxEmpty>No matching mentions found</InlineComboboxEmpty>

          {/* Section 1: Date — Today + Remind me */}
          <InlineComboboxGroup>
            <InlineComboboxGroupLabel className="flex items-center gap-1.5 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-amber-400">
              <Calendar className="h-3 w-3" />
              <span>Date</span>
            </InlineComboboxGroupLabel>

            {dateItems.map((item) => (
              <InlineComboboxItem
                key={item.id}
                value={item.label}
                label={item.label}
                keywords={item.keywords}
                group="Date"
                onClick={() => handleSelect(item)}
                className="gap-2.5 px-2 py-1.5"
              >
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded bg-amber-400/10 text-amber-400 border border-amber-400/20">
                  {item.id === 'remind_me' ? (
                    <AlarmClock className="h-3.5 w-3.5" />
                  ) : (
                    <Calendar className="h-3.5 w-3.5" />
                  )}
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="font-medium text-white truncate text-xs">{item.label}</span>
                  <span className="text-[10px] text-zinc-400 truncate">{item.description}</span>
                </div>
              </InlineComboboxItem>
            ))}
          </InlineComboboxGroup>

          <div className="h-px bg-zinc-800 my-1 mx-1" />

          {/* Section 2: People — 3 shown initially, rest behind "Show more" */}
          <InlineComboboxGroup>
            <InlineComboboxGroupLabel className="flex items-center gap-1.5 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-lime-400">
              <User className="h-3 w-3" />
              <span>People</span>
            </InlineComboboxGroupLabel>

            {teamList.map((item) => (
              <InlineComboboxItem
                key={item.id}
                value={item.label}
                label={item.label}
                keywords={item.keywords}
                group="People"
                onClick={() => handleSelect(item)}
                className="gap-2.5 px-2 py-1.5"
              >
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded bg-lime-400/10 text-lime-400 border border-lime-400/20">
                  <User className="h-3.5 w-3.5" />
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="font-medium text-white truncate text-xs">{item.label}</span>
                  {item.role && (
                    <span className="text-[10px] text-zinc-400 truncate">{item.role}</span>
                  )}
                </div>
              </InlineComboboxItem>
            ))}

            {!showAllTeam && search.trim().length === 0 && MORE_TEAM.length > 0 && (
              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={(e) => {
                  e.stopPropagation();
                  setShowAllTeam(true);
                }}
                className="w-full flex items-center justify-center gap-1 py-1.5 px-2 text-[11px] font-medium text-lime-400 hover:text-lime-300 hover:bg-zinc-800/60 rounded-md transition-colors mt-0.5"
              >
                <ChevronDown className="h-3 w-3" />
                <span>Show more ({MORE_TEAM.length} more)</span>
              </button>
            )}
          </InlineComboboxGroup>

          <div className="h-px bg-zinc-800 my-1 mx-1" />

          {/* Section 3: Pages */}
          <InlineComboboxGroup>
            <InlineComboboxGroupLabel className="flex items-center gap-1.5 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-blue-400">
              <FileText className="h-3 w-3" />
              <span>Pages</span>
            </InlineComboboxGroupLabel>

            {PAGE_ENTRIES.map((item) => (
              <InlineComboboxItem
                key={item.id}
                value={item.label}
                label={item.label}
                keywords={item.keywords}
                group="Pages"
                onClick={() => handleSelect(item)}
                className="gap-2.5 px-2 py-1.5"
              >
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded bg-blue-400/10 text-blue-400 border border-blue-400/20">
                  <FileText className="h-3.5 w-3.5" />
                </div>
                <div className="flex flex-col min-w-0">
                  <span className="font-medium text-white truncate text-xs">{item.label}</span>
                  {item.description && (
                    <span className="text-[10px] text-zinc-400 truncate">{item.description}</span>
                  )}
                </div>
              </InlineComboboxItem>
            ))}
          </InlineComboboxGroup>
        </InlineComboboxContent>
      </InlineCombobox>
      {props.children}
    </PlateElement>
  );
}
