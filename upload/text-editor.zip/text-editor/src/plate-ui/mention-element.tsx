'use client';

import { FileText, Search, User } from '@xpace/icons';
import { cn } from '@xpace/ui';
import type { TMentionElement } from 'platejs';
import type { PlateElementProps } from 'platejs/react';
import { PlateElement, useReadOnly, useSelected } from 'platejs/react';
import * as React from 'react';
import {
  ALL_PAGES,
  ALL_TEAM_MEMBERS,
  type MentionPageItem,
  type MentionTeamMember,
} from './mention-data';
import { Popover, PopoverContent, PopoverTrigger } from './popover';

interface ExtendedMentionElement extends TMentionElement {
  category?: 'person' | 'page';
  role?: string;
  description?: string;
  url?: string;
}

type TabType = 'all' | 'person' | 'page';

export function MentionElement(props: PlateElementProps<ExtendedMentionElement>) {
  const { editor, element } = props;
  const readOnly = useReadOnly();
  const selected = useSelected();
  const [open, setOpen] = React.useState(false);

  const value = (element.value as string) || (element.text as string) || '';
  const key = (element.key as string) || '';
  const currentCategory: 'person' | 'page' =
    element.category || (key.startsWith('page:') ? 'page' : 'person');

  const [activeTab, setActiveTab] = React.useState<TabType>('all');
  const [filterQuery, setFilterQuery] = React.useState('');

  // Reset filter when opening popover
  React.useEffect(() => {
    if (open) {
      setFilterQuery('');
      // Default to the tab matching the current category
      setActiveTab(currentCategory);
    }
  }, [open, currentCategory]);

  const handleRemove = () => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.removeNodes({ at: path });
    }
    setOpen(false);
  };

  const handleSelectPerson = (member: MentionTeamMember) => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.setNodes(
        {
          type: 'mention',
          value: member.label,
          key: `person:${member.id}`,
          category: 'person',
          role: member.role,
          description: undefined,
          url: undefined,
        },
        { at: path },
      );
    }
    setOpen(false);
  };

  const handleSelectPage = (page: MentionPageItem) => {
    const path = editor.api.findPath(element);
    if (path) {
      editor.tf.setNodes(
        {
          type: 'mention',
          value: page.label,
          key: `page:${page.id}`,
          category: 'page',
          description: page.description,
          url: `/docs/${page.id}`,
          role: undefined,
        },
        { at: path },
      );
    }
    setOpen(false);
  };

  const filteredMembers = React.useMemo(() => {
    if (!filterQuery.trim()) return ALL_TEAM_MEMBERS;
    const q = filterQuery.toLowerCase();
    return ALL_TEAM_MEMBERS.filter(
      (m) =>
        m.label.toLowerCase().includes(q) ||
        m.role.toLowerCase().includes(q) ||
        m.keywords?.some((k) => k.toLowerCase().includes(q)),
    );
  }, [filterQuery]);

  const filteredPages = React.useMemo(() => {
    if (!filterQuery.trim()) return ALL_PAGES;
    const q = filterQuery.toLowerCase();
    return ALL_PAGES.filter(
      (p) =>
        p.label.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.keywords?.some((k) => k.toLowerCase().includes(q)),
    );
  }, [filterQuery]);

  const getBadgeStyle = () => {
    switch (currentCategory) {
      case 'page':
        return 'bg-blue-400/10 text-blue-400 border-blue-400/30 hover:bg-blue-400/20';
      case 'person':
      default:
        return 'bg-lime-400/10 text-lime-400 border-lime-400/30 hover:bg-lime-400/20';
    }
  };

  const getIcon = () => {
    switch (currentCategory) {
      case 'page':
        return <FileText className="h-3 w-3 text-blue-400 shrink-0" />;
      case 'person':
      default:
        return <User className="h-3 w-3 text-lime-400 shrink-0" />;
    }
  };

  const trigger = (
    <button
      type="button"
      contentEditable={false}
      data-plate-prevent-deselect
      onKeyDown={(e) => {
        if (e.key === 'Backspace' || e.key === 'Delete') {
          e.preventDefault();
          handleRemove();
        }
      }}
      className={cn(
        'inline-flex cursor-pointer select-none items-center gap-1 rounded-md px-1.5 py-0.5 text-xs font-medium mx-0.5 align-baseline border transition-colors',
        getBadgeStyle(),
        selected && 'ring-1 ring-lime-400',
      )}
      title="Click to edit mention"
    >
      {getIcon()}
      <span>{value}</span>
    </button>
  );

  const showPeople = activeTab === 'all' || activeTab === 'person';
  const showPages = activeTab === 'all' || activeTab === 'page';

  return (
    <PlateElement {...props} as="span" className="inline-flex items-center align-baseline mx-0.5">
      {readOnly ? (
        trigger
      ) : (
        <Popover open={open} onOpenChange={setOpen}>
          <PopoverTrigger asChild>{trigger}</PopoverTrigger>
          <PopoverContent
            align="start"
            sideOffset={4}
            className="w-80 p-2.5 space-y-2 z-50 bg-zinc-950/95 border-zinc-800 shadow-2xl backdrop-blur-md rounded-xl text-zinc-200"
          >
            {/* Header: Current Selection badge & Remove Action */}
            <div className="flex items-center justify-between text-[11px] font-semibold text-zinc-400">
              <span className="flex items-center gap-1.5 truncate">
                <span className="text-[10px] text-zinc-500 uppercase tracking-wider font-mono">
                  Current:
                </span>
                <span
                  className={cn(
                    'inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-xs font-medium border truncate max-w-[170px]',
                    getBadgeStyle(),
                  )}
                >
                  {getIcon()}
                  <span className="truncate">{value}</span>
                </span>
              </span>
              <button
                type="button"
                onClick={handleRemove}
                className="text-[10px] text-red-400 hover:text-red-300 font-normal transition-colors cursor-pointer shrink-0 ml-1"
              >
                Remove
              </button>
            </div>

            {/* Filter Search Input */}
            <div className="relative">
              <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-zinc-500" />
              <input
                type="text"
                autoFocus
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder="Search or convert to..."
                className="h-7 w-full rounded-md bg-zinc-900 border border-zinc-800 pl-8 pr-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-lime-400/80"
              />
            </div>

            {/* Category Switcher Tabs — 3 columns: All / People / Pages */}
            <div className="grid grid-cols-3 gap-1 p-0.5 bg-zinc-900/80 rounded-lg border border-zinc-800/80 text-[11px]">
              <button
                type="button"
                onClick={() => setActiveTab('all')}
                className={cn(
                  'h-6 rounded flex items-center justify-center font-medium transition-colors',
                  activeTab === 'all'
                    ? 'bg-zinc-800 text-white shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200',
                )}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('person')}
                className={cn(
                  'h-6 rounded flex items-center justify-center gap-1 font-medium transition-colors',
                  activeTab === 'person'
                    ? 'bg-lime-400/20 text-lime-400 border border-lime-400/30'
                    : 'text-zinc-400 hover:text-zinc-200',
                )}
              >
                <User className="h-3 w-3 text-lime-400" />
                People
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('page')}
                className={cn(
                  'h-6 rounded flex items-center justify-center gap-1 font-medium transition-colors',
                  activeTab === 'page'
                    ? 'bg-blue-400/20 text-blue-400 border border-blue-400/30'
                    : 'text-zinc-400 hover:text-zinc-200',
                )}
              >
                <FileText className="h-3 w-3 text-blue-400" />
                Pages
              </button>
            </div>

            {/* Scrollable Items List */}
            <div className="max-h-56 overflow-y-auto space-y-2 pr-0.5 custom-scrollbar">
              {/* People Section */}
              {showPeople && filteredMembers.length > 0 && (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 px-1 text-[10px] font-bold uppercase tracking-wider text-lime-400">
                    <User className="h-3 w-3" />
                    <span>People</span>
                  </div>
                  {filteredMembers.map((member) => {
                    const isCurrent =
                      currentCategory === 'person' &&
                      (key === `person:${member.id}` || value === member.label);
                    return (
                      <button
                        key={member.id}
                        type="button"
                        onClick={() => handleSelectPerson(member)}
                        className={cn(
                          'w-full flex items-center justify-between rounded-md px-2 py-1.5 text-left text-xs transition-colors hover:bg-zinc-800 cursor-pointer',
                          isCurrent
                            ? 'bg-zinc-800/90 text-lime-400 font-medium border border-lime-400/30'
                            : 'text-zinc-200',
                        )}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded bg-lime-400/10 text-lime-400 border border-lime-400/20">
                            <User className="h-3 w-3" />
                          </div>
                          <span className="truncate">{member.label}</span>
                        </div>
                        <span className="text-[10px] text-zinc-500 truncate ml-2">
                          {member.role}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Pages Section */}
              {showPages && filteredPages.length > 0 && (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 px-1 text-[10px] font-bold uppercase tracking-wider text-blue-400">
                    <FileText className="h-3 w-3" />
                    <span>Pages</span>
                  </div>
                  {filteredPages.map((page) => {
                    const isCurrent =
                      currentCategory === 'page' &&
                      (key === `page:${page.id}` || value === page.label);
                    return (
                      <button
                        key={page.id}
                        type="button"
                        onClick={() => handleSelectPage(page)}
                        className={cn(
                          'w-full flex items-center justify-between rounded-md px-2 py-1.5 text-left text-xs transition-colors hover:bg-zinc-800 cursor-pointer',
                          isCurrent
                            ? 'bg-zinc-800/90 text-blue-400 font-medium border border-blue-400/30'
                            : 'text-zinc-200',
                        )}
                      >
                        <div className="flex items-center gap-2 truncate">
                          <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded bg-blue-400/10 text-blue-400 border border-blue-400/20">
                            <FileText className="h-3 w-3" />
                          </div>
                          <span className="truncate">{page.label}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Empty State */}
              {filteredMembers.length === 0 && filteredPages.length === 0 && (
                <div className="text-[11px] text-zinc-500 text-center py-4">
                  No results match &quot;{filterQuery}&quot;
                </div>
              )}
            </div>
          </PopoverContent>
        </Popover>
      )}
      {props.children}
    </PlateElement>
  );
}
