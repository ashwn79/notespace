import type { Path, TRange } from 'platejs';
import type { PlateEditor } from 'platejs/react';
import type { ReactNode } from 'react';
import type { TextEditorElementNode } from './editor';

export type CommandGroup = 'ai' | 'basic' | 'lists' | 'media' | 'advanced' | 'inline';

export interface CommandContext {
  at?: Path | TRange;
  element?: TextEditorElementNode;
  insertAfter?: boolean;
}

export interface EditorCommand {
  key: string;
  label: string;
  description: string;
  shortcut?: string;
  icon: ReactNode;
  keywords: string[];
  group: CommandGroup;
  type: 'block' | 'inline' | 'action';
  execute: (editor: PlateEditor, context?: CommandContext) => void;
  canTurnInto?: boolean;
  focusEditor?: boolean;
}
