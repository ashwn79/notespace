export interface EditorUploadedAsset {
  id?: string;
  url: string;
  name?: string;
  mimeType?: string;
  size?: number;
  width?: number;
  height?: number;
  type?: string;
}

export type UploadedAsset = EditorUploadedAsset;

export interface EditorUploadAdapter {
  upload(
    files: File[],
    context?: {
      kind?: 'image' | 'video' | 'audio' | 'file';
    },
  ): Promise<EditorUploadedAsset[]>;
}

export interface EditorAIAdapter {
  endpoint?: string;
  complete?: (prompt: string, options?: { system?: string }) => Promise<string>;
  stream?: (prompt: string, onChunk: (text: string) => void) => Promise<void>;
}

export interface EditorMentionItem {
  id: string;
  key?: string;
  text: string;
  label?: string;
  description?: string;
  avatar?: string;
  type?: 'user' | 'brand' | 'knowledge' | 'content' | 'playbook' | string;
}

export type EditorMentionProvider = (
  query: string,
) => Promise<EditorMentionItem[]> | EditorMentionItem[];
