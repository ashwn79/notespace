import type { Path, TRange } from 'platejs';
import type { PlateEditor } from 'platejs/react';
import type { ReactNode } from 'react';

export interface TextEditorTextNode {
  text: string;
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  strikethrough?: boolean;
  code?: boolean;
  [key: string]: unknown;
}

export interface TextEditorElementNode {
  id?: string;
  type: string;
  children: Array<TextEditorTextNode | TextEditorElementNode>;
  url?: string;
  listStyleType?: string;
  indent?: number;
  checked?: boolean;
  [key: string]: unknown;
}

export type TextEditorNode = TextEditorElementNode | TextEditorTextNode;

export type TextEditorValue = TextEditorElementNode[];

import type { EditorAIAdapter, EditorMentionProvider, EditorUploadAdapter } from './adapters';

export interface TextEditorProps {
  value?: TextEditorValue;
  onChange?: (value: TextEditorValue) => void;
  title?: string;
  onTitleChange?: (title: string) => void;
  icon?: string;
  onIconChange?: (icon?: string) => void;
  placeholder?: string;
  readOnly?: boolean;
  className?: string;
  autoFocus?: boolean;
  minHeight?: string | number;
  showFixedToolbar?: boolean;
  uploadAdapter?: EditorUploadAdapter;
  aiAdapter?: EditorAIAdapter;
  mentionProvider?: EditorMentionProvider;
}

export interface BlockCommandItem {
  id: string;
  label: string;
  description: string;
  icon: ReactNode;
  keywords: string[];
  group: 'basic' | 'lists' | 'advanced';
  action: (
    editor: PlateEditor,
    options?: {
      at?: Path | TRange;
      element?: TextEditorElementNode;
      insertAfter?: boolean;
    },
  ) => void;
}
