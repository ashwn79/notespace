'use client';

import { DndScroller } from '@platejs/dnd';
import { BlockSelectionAfterEditable, BlockSelectionPlugin } from '@platejs/selection/react';
import { cn } from '@xpace/ui';
import { Plate, PlateContent, usePlateEditor } from 'platejs/react';
import * as React from 'react';
import { FloatingToolbar } from '../plate-ui/floating-toolbar';
import { LinkFloatingToolbar } from '../plate-ui/link-floating-toolbar';
import { Popover, PopoverContent, PopoverTrigger } from '../plate-ui/popover';
import { editorPlugins } from '../plugins/editor-plugins';
import type { TextEditorProps, TextEditorValue } from '../types/editor';
import { Toolbar } from './toolbar';

const DEFAULT_VALUE: TextEditorValue = [
  {
    type: 'p',
    children: [{ text: '' }],
  },
];

export function TextEditor({
  value,
  onChange,
  title,
  onTitleChange,
  icon,
  onIconChange,
  placeholder = 'Press "/" for commands',
  readOnly = false,
  className,
  autoFocus = false,
  minHeight = 260,
  showFixedToolbar = false,
  uploadAdapter,
  aiAdapter,
  mentionProvider,
}: TextEditorProps) {
  const initialValueRef = React.useRef(
    value && Array.isArray(value) && value.length > 0 ? value : DEFAULT_VALUE,
  );

  const editor = usePlateEditor({
    plugins: editorPlugins,
    value: initialValueRef.current as never,
  });

  const [internalTitle, setInternalTitle] = React.useState(title ?? '');
  const currentTitle = title !== undefined ? title : internalTitle;
  const handleTitleChange = (newTitle: string) => {
    setInternalTitle(newTitle);
    onTitleChange?.(newTitle);
  };

  const [internalIcon, setInternalIcon] = React.useState<string | undefined>(icon);
  const currentIcon = icon !== undefined ? icon : internalIcon;
  const handleIconChange = (newIcon?: string) => {
    setInternalIcon(newIcon);
    onIconChange?.(newIcon);
  };

  const [iconPickerOpen, setIconPickerOpen] = React.useState(false);

  // Sync title / icon if controlled
  React.useEffect(() => {
    if (title !== undefined) setInternalTitle(title);
  }, [title]);
  React.useEffect(() => {
    if (icon !== undefined) setInternalIcon(icon);
  }, [icon]);

  // Attach adapters to editor instance for plugins to access
  React.useEffect(() => {
    if (editor) {
      const ed = editor as unknown as {
        uploadAdapter?: unknown;
        aiAdapter?: unknown;
        mentionProvider?: unknown;
      };
      ed.uploadAdapter = uploadAdapter;
      ed.aiAdapter = aiAdapter;
      ed.mentionProvider = mentionProvider;

      if (typeof window !== 'undefined') {
        (window as unknown as { __PLATE_EDITOR__?: unknown }).__PLATE_EDITOR__ = editor;
      }
    }
  }, [editor, uploadAdapter, aiAdapter, mentionProvider]);

  const prevValueRef = React.useRef(value);

  // Sync external value updates (e.g. document switching)
  React.useEffect(() => {
    if (value !== undefined && value !== prevValueRef.current) {
      prevValueRef.current = value;
      if (editor && Array.isArray(value) && value.length > 0) {
        editor.tf.setValue(value as never);
      }
    }
  }, [value, editor]);

  const handleValueChange = React.useCallback(
    ({ value: newValue }: { value: unknown }) => {
      const typedValue = newValue as TextEditorValue;
      prevValueRef.current = typedValue;
      onChange?.(typedValue);
    },
    [onChange],
  );

  return (
    <div
      className={cn(
        'relative flex w-full flex-col rounded-xl border border-border bg-card shadow-xs transition-colors overflow-hidden',
        className,
      )}
    >
      <Plate editor={editor} readOnly={readOnly} onValueChange={handleValueChange}>
        {showFixedToolbar && <Toolbar readOnly={readOnly} />}

        <FloatingToolbar />
        <LinkFloatingToolbar />

        {/* biome-ignore lint/a11y/noStaticElementInteractions: Clicking empty scroll area focuses editor end */}
        <div
          className="relative flex-1 overflow-y-auto pl-14 pr-4 py-3 sm:pl-16 sm:pr-6 sm:py-5 cursor-text"
          onKeyDown={(e) => {
            if (e.key === 'Escape' && editor) {
              const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;
              blockSelectionApi?.clear?.();
            }
          }}
          onClick={(e) => {
            if (e.target === e.currentTarget && editor) {
              const lastEntry = editor.api.last();
              if (lastEntry) {
                const end = editor.api.end(lastEntry[1]);
                if (end) {
                  editor.tf.select(end);
                  editor.tf.focus();
                  return;
                }
              }
              editor.tf.focus();
            }
          }}
        >
          {/* Document Header: Icon & Title above Plate content */}
          <div className="mb-4 space-y-2 select-none group/header" contentEditable={false}>
            <div className="flex items-center gap-2">
              <Popover open={iconPickerOpen} onOpenChange={setIconPickerOpen}>
                <PopoverTrigger asChild>
                  <button
                    type="button"
                    disabled={readOnly}
                    className={cn(
                      'flex items-center justify-center rounded-lg transition-colors',
                      currentIcon
                        ? 'h-10 w-10 text-2xl hover:bg-zinc-800/80 cursor-pointer'
                        : 'h-7 px-2 text-xs text-muted-foreground/60 hover:text-foreground hover:bg-zinc-800/60 opacity-0 group-hover/header:opacity-100 focus:opacity-100 transition-opacity',
                      readOnly && 'cursor-default pointer-events-none',
                    )}
                    title={currentIcon ? 'Change icon' : 'Add icon'}
                  >
                    {currentIcon ? currentIcon : '+ Add icon'}
                  </button>
                </PopoverTrigger>
                {!readOnly && (
                  <PopoverContent
                    align="start"
                    className="w-64 p-2 bg-zinc-950/95 border-zinc-800 shadow-xl backdrop-blur-md z-50"
                  >
                    <div className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider mb-2 px-1">
                      Select Icon
                    </div>
                    <div className="grid grid-cols-6 gap-1 p-1">
                      {[
                        '📄',
                        '💡',
                        '🚀',
                        '🎯',
                        '📊',
                        '⚡',
                        '🧠',
                        '📚',
                        '✨',
                        '🌐',
                        '🔥',
                        '💎',
                        '📌',
                        '🛠️',
                        '📝',
                        '🏷️',
                        '📦',
                        '⭐',
                      ].map((em) => (
                        <button
                          type="button"
                          key={em}
                          onClick={() => {
                            handleIconChange(em);
                            setIconPickerOpen(false);
                          }}
                          className="flex h-8 w-8 items-center justify-center rounded hover:bg-zinc-800 text-lg transition-colors"
                        >
                          {em}
                        </button>
                      ))}
                    </div>
                    {currentIcon && (
                      <div className="mt-2 pt-2 border-t border-zinc-800 flex justify-end">
                        <button
                          type="button"
                          onClick={() => {
                            handleIconChange(undefined);
                            setIconPickerOpen(false);
                          }}
                          className="text-[11px] text-red-400 hover:text-red-300 px-2 py-0.5"
                        >
                          Remove icon
                        </button>
                      </div>
                    )}
                  </PopoverContent>
                )}
              </Popover>
            </div>

            <input
              type="text"
              readOnly={readOnly}
              value={currentTitle}
              onChange={(e) => handleTitleChange(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  if (editor) {
                    const firstEntry = editor.api.first();
                    if (firstEntry) {
                      editor.tf.select(editor.api.start(firstEntry[1]));
                    }
                    editor.tf.focus();
                  }
                }
              }}
              placeholder="Untitled"
              className="w-full bg-transparent text-3xl sm:text-4xl font-bold tracking-tight text-foreground placeholder:text-muted-foreground/30 border-0 p-0 focus:outline-none focus:ring-0 leading-tight"
            />
          </div>

          <PlateContent
            readOnly={readOnly}
            autoFocus={autoFocus}
            placeholder={placeholder}
            className={cn(
              'w-full text-foreground leading-relaxed outline-hidden focus:outline-hidden focus-visible:outline-hidden selection:bg-lime-400/25',
              '[&_[data-slate-placeholder]]:text-muted-foreground/50 [&_[data-slate-placeholder]]:!opacity-100',
              readOnly && 'cursor-default select-text',
            )}
            style={{
              minHeight: typeof minHeight === 'number' ? `${minHeight}px` : minHeight,
            }}
          />
          <BlockSelectionAfterEditable />
          <DndScroller />
        </div>
      </Plate>
    </div>
  );
}
