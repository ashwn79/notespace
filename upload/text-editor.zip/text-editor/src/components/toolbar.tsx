'use client';

import { unwrapLink, upsertLink } from '@platejs/link';
import { ListStyleType, someList, toggleList } from '@platejs/list';
import {
  Bold,
  BulletedList,
  ChevronDown,
  Code,
  Heading1,
  Heading2,
  Heading3,
  Italic,
  Link as LinkIcon,
  NumberedList,
  Quote,
  Redo2,
  Strikethrough,
  Underline,
  Undo2,
} from '@xpace/icons';
import {
  Button,
  cn,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  Separator,
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@xpace/ui';
import { useEditorRef, useEditorSelector } from 'platejs/react';
import type React from 'react';

interface ToolbarButtonProps {
  active?: boolean;
  disabled?: boolean;
  onClick: () => void;
  tooltip: string;
  children: React.ReactNode;
}

function ToolbarButton({ active, disabled, onClick, tooltip, children }: ToolbarButtonProps) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={disabled}
          onMouseDown={(e) => e.preventDefault()}
          onClick={onClick}
          className={cn(
            'h-8 w-8 p-0 text-muted-foreground transition-colors hover:text-foreground',
            active && 'bg-accent text-accent-foreground font-semibold shadow-xs',
          )}
        >
          {children}
          <span className="sr-only">{tooltip}</span>
        </Button>
      </TooltipTrigger>
      <TooltipContent side="bottom" sideOffset={6} className="text-xs">
        {tooltip}
      </TooltipContent>
    </Tooltip>
  );
}

export interface ToolbarProps {
  readOnly?: boolean;
  className?: string;
}

export function Toolbar({ readOnly, className }: ToolbarProps) {
  const editor = useEditorRef();

  // Active marks state
  const isBold = useEditorSelector((ed) => ed.api.hasMark('bold'), []);
  const isItalic = useEditorSelector((ed) => ed.api.hasMark('italic'), []);
  const isUnderline = useEditorSelector((ed) => ed.api.hasMark('underline'), []);
  const isStrikethrough = useEditorSelector((ed) => ed.api.hasMark('strikethrough'), []);
  const isCode = useEditorSelector((ed) => ed.api.hasMark('code'), []);

  // Active blocks state
  const isH1 = useEditorSelector((ed) => ed.api.some({ match: { type: 'h1' } }), []);
  const isH2 = useEditorSelector((ed) => ed.api.some({ match: { type: 'h2' } }), []);
  const isH3 = useEditorSelector((ed) => ed.api.some({ match: { type: 'h3' } }), []);
  const isBlockquote = useEditorSelector(
    (ed) => ed.api.some({ match: { type: 'blockquote' } }),
    [],
  );

  // Lists state
  const isBulletedList = useEditorSelector((ed) => someList(ed, ListStyleType.Disc), []);
  const isNumberedList = useEditorSelector((ed) => someList(ed, ListStyleType.Decimal), []);

  // Link state
  const isLink = useEditorSelector((ed) => ed.api.some({ match: { type: 'a' } }), []);

  if (readOnly) return null;

  const currentBlockLabel = isH1
    ? 'Heading 1'
    : isH2
      ? 'Heading 2'
      : isH3
        ? 'Heading 3'
        : isBlockquote
          ? 'Quote'
          : 'Paragraph';

  const handleLink = () => {
    if (isLink) {
      unwrapLink(editor);
      return;
    }
    const url = window.prompt('Enter link URL:', 'https://');
    if (url?.trim()) {
      upsertLink(editor, { url: url.trim() });
    }
  };

  return (
    <TooltipProvider delayDuration={400}>
      <div
        className={cn(
          'flex flex-wrap items-center gap-1 border-b border-border bg-card/60 px-3 py-1.5 backdrop-blur-xs',
          className,
        )}
      >
        {/* History */}
        <ToolbarButton tooltip="Undo (Ctrl+Z)" onClick={() => editor.undo()}>
          <Undo2 className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton tooltip="Redo (Ctrl+Y)" onClick={() => editor.redo()}>
          <Redo2 className="h-4 w-4" />
        </ToolbarButton>

        <Separator orientation="vertical" className="mx-1 h-5" />

        {/* Block Type Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onMouseDown={(e) => e.preventDefault()}
              className="h-8 gap-1.5 px-2.5 text-xs font-medium text-muted-foreground hover:text-foreground"
            >
              <span>{currentBlockLabel}</span>
              <ChevronDown className="h-3.5 w-3.5 opacity-60" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-36">
            <DropdownMenuItem
              onClick={() => {
                if (isH1 || isH2 || isH3 || isBlockquote) {
                  editor.tf.setNodes({ type: 'p' });
                }
              }}
              className={cn(
                'text-sm',
                !isH1 && !isH2 && !isH3 && !isBlockquote && 'font-semibold text-primary',
              )}
            >
              Paragraph
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => editor.tf.toggleBlock('h1')}
              className={cn('text-sm', isH1 && 'font-semibold text-primary')}
            >
              <Heading1 className="mr-2 h-4 w-4" />
              Heading 1
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => editor.tf.toggleBlock('h2')}
              className={cn('text-sm', isH2 && 'font-semibold text-primary')}
            >
              <Heading2 className="mr-2 h-4 w-4" />
              Heading 2
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => editor.tf.toggleBlock('h3')}
              className={cn('text-sm', isH3 && 'font-semibold text-primary')}
            >
              <Heading3 className="mr-2 h-4 w-4" />
              Heading 3
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => editor.tf.toggleBlock('blockquote')}
              className={cn('text-sm', isBlockquote && 'font-semibold text-primary')}
            >
              <Quote className="mr-2 h-4 w-4" />
              Quote
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Separator orientation="vertical" className="mx-1 h-5" />

        {/* Inline Formatting */}
        <ToolbarButton
          active={isBold}
          tooltip="Bold (Ctrl+B)"
          onClick={() => editor.tf.toggleMark('bold')}
        >
          <Bold className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          active={isItalic}
          tooltip="Italic (Ctrl+I)"
          onClick={() => editor.tf.toggleMark('italic')}
        >
          <Italic className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          active={isUnderline}
          tooltip="Underline (Ctrl+U)"
          onClick={() => editor.tf.toggleMark('underline')}
        >
          <Underline className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          active={isStrikethrough}
          tooltip="Strikethrough"
          onClick={() => editor.tf.toggleMark('strikethrough')}
        >
          <Strikethrough className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          active={isCode}
          tooltip="Inline Code"
          onClick={() => editor.tf.toggleMark('code')}
        >
          <Code className="h-4 w-4" />
        </ToolbarButton>

        <Separator orientation="vertical" className="mx-1 h-5" />

        {/* Lists */}
        <ToolbarButton
          active={isBulletedList}
          tooltip="Bulleted List"
          onClick={() => toggleList(editor, { listStyleType: ListStyleType.Disc })}
        >
          <BulletedList className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          active={isNumberedList}
          tooltip="Numbered List"
          onClick={() => toggleList(editor, { listStyleType: ListStyleType.Decimal })}
        >
          <NumberedList className="h-4 w-4" />
        </ToolbarButton>
        <ToolbarButton
          active={isBlockquote}
          tooltip="Blockquote"
          onClick={() => editor.tf.toggleBlock('blockquote')}
        >
          <Quote className="h-4 w-4" />
        </ToolbarButton>

        <Separator orientation="vertical" className="mx-1 h-5" />

        {/* Link */}
        <ToolbarButton
          active={isLink}
          tooltip={isLink ? 'Remove Link' : 'Add Link'}
          onClick={handleLink}
        >
          <LinkIcon className="h-4 w-4" />
        </ToolbarButton>
      </div>
    </TooltipProvider>
  );
}
