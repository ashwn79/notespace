'use client';

import { insertCallout } from '@platejs/callout';
import { insertCodeBlock, toggleCodeBlock, unwrapCodeBlock } from '@platejs/code-block';
import { insertDate } from '@platejs/date';
import { insertColumnGroup } from '@platejs/layout';
import { triggerFloatingLink } from '@platejs/link/react';
import { insertEquation, insertInlineEquation } from '@platejs/math';
import {
  insertAudioPlaceholder,
  insertFilePlaceholder,
  insertImagePlaceholder,
  insertMedia,
  insertVideoPlaceholder,
} from '@platejs/media';
import { BlockSelectionPlugin } from '@platejs/selection/react';
import { TablePlugin } from '@platejs/table/react';
import { insertToc } from '@platejs/toc';
import { KEYS, type NodeEntry, type Path, PathApi, type TElement } from 'platejs';
import type { PlateEditor } from 'platejs/react';
import type { TextEditorElementNode } from '../types/editor';

export const ACTION_THREE_COLUMNS = 'action_three_columns';
export const ACTION_TWO_COLUMNS = 'action_two_columns';

export const insertList = (editor: PlateEditor, type: string) => {
  editor.tf.insertNodes(
    editor.api.create.block({
      indent: 1,
      listStyleType: type,
    }),
    { select: true },
  );
};

export const createBlockquote = (editor: PlateEditor) => ({
  children: [editor.api.create.block({ type: KEYS.p })],
  type: KEYS.blockquote,
});

export const selectBlockquoteStart = (editor: PlateEditor, path: Path) => {
  const start = editor.api.start(path.concat([0]));
  if (start) {
    editor.tf.select(start);
  }
};

const insertBlockMap: Record<string, (editor: PlateEditor, type: string) => void> = {
  [KEYS.listTodo]: (editor) =>
    editor.tf.insertNodes(
      editor.api.create.block({
        type: 'todo',
        checked: false,
      }),
      { select: true },
    ),
  [KEYS.hr]: (editor) => {
    const block = editor.api.block();
    if (!block) return;
    const [, path] = block;
    const insertPath = PathApi.next(path);
    editor.tf.insertNodes(
      [editor.api.create.block({ type: KEYS.hr }), editor.api.create.block({ type: KEYS.p })],
      { at: insertPath },
    );
    const nextPPath = PathApi.next(insertPath);
    const startPoint = editor.api.start(nextPPath);
    if (startPoint) editor.tf.select(startPoint);
  },
  [KEYS.ol]: insertList,
  [KEYS.ul]: insertList,
  [ACTION_TWO_COLUMNS]: (editor) => insertColumnGroup(editor, { columns: 2, select: true }),
  [ACTION_THREE_COLUMNS]: (editor) => insertColumnGroup(editor, { columns: 3, select: true }),
  [KEYS.audio]: (editor) => insertAudioPlaceholder(editor, { select: true }),
  [KEYS.callout]: (editor) => insertCallout(editor, { select: true }),
  [KEYS.codeBlock]: (editor) => insertCodeBlock(editor, { select: true }),
  [KEYS.equation]: (editor) => insertEquation(editor, { select: true }),
  [KEYS.file]: (editor) => insertFilePlaceholder(editor, { select: true }),
  [KEYS.img]: (editor) => insertImagePlaceholder(editor, { select: true }),
  [KEYS.video]: (editor) => insertVideoPlaceholder(editor, { select: true }),
  [KEYS.mediaEmbed]: (editor) =>
    insertMedia(editor, {
      select: true,
      type: KEYS.mediaEmbed,
    }),
  [KEYS.table]: (editor) => editor.getTransforms(TablePlugin).insert.table({}, { select: true }),
  [KEYS.toc]: (editor) => insertToc(editor, { select: true }),
  [KEYS.toggle]: (editor) =>
    editor.tf.insertNodes(
      editor.api.create.block({
        type: KEYS.toggle,
        open: true,
        children: [{ text: '' }],
      }),
      { select: true },
    ),
  toggle_h1: (editor) =>
    editor.tf.insertNodes(
      editor.api.create.block({
        type: KEYS.toggle,
        headingLevel: 1,
        open: true,
        children: [{ text: '' }],
      }),
      { select: true },
    ),
  toggle_h2: (editor) =>
    editor.tf.insertNodes(
      editor.api.create.block({
        type: KEYS.toggle,
        headingLevel: 2,
        open: true,
        children: [{ text: '' }],
      }),
      { select: true },
    ),
  toggle_h3: (editor) =>
    editor.tf.insertNodes(
      editor.api.create.block({
        type: KEYS.toggle,
        headingLevel: 3,
        open: true,
        children: [{ text: '' }],
      }),
      { select: true },
    ),
};

const insertInlineMap: Record<string, (editor: PlateEditor, type: string) => void> = {
  [KEYS.date]: (editor) => insertDate(editor, { select: true }),
  [KEYS.inlineEquation]: (editor) => insertInlineEquation(editor, '', { select: true }),
  [KEYS.link]: (editor) => triggerFloatingLink(editor, { focused: true }),
};

export interface InsertBlockOptions {
  upsert?: boolean;
}

export const insertBlock = (
  editor: PlateEditor,
  type: string,
  options: InsertBlockOptions = {},
) => {
  const { upsert = false } = options;

  editor.tf.withoutNormalizing(() => {
    const block = editor.api.block();
    if (!block) return;

    const [currentNode, path] = block;
    const isCurrentBlockEmpty = editor.api.isEmpty(currentNode);
    const currentBlockType = getBlockType(currentNode);
    const isSameBlockType = type === currentBlockType;

    if (upsert && isCurrentBlockEmpty && isSameBlockType) {
      return;
    }

    if (type === KEYS.blockquote) {
      const insertPath = PathApi.next(path);
      editor.tf.insertNodes(createBlockquote(editor), { at: insertPath });

      if (!isSameBlockType && isCurrentBlockEmpty) {
        editor.tf.removeNodes({ at: path });
      }

      selectBlockquoteStart(editor, isCurrentBlockEmpty && !isSameBlockType ? path : insertPath);
      return;
    }

    const targetIndent =
      currentNode.type === KEYS.toggle || currentNode.type === KEYS.callout
        ? ((currentNode.indent as number) || 0) + 1
        : (currentNode.indent as number) || 0;

    if (type in insertBlockMap) {
      insertBlockMap[type]?.(editor, type);
      if (targetIndent > 0) {
        const nextPath = PathApi.next(path);
        const node = editor.api.node(nextPath);
        if (node) {
          editor.tf.setNodes({ indent: targetIndent }, { at: nextPath });
        }
      }
    } else {
      editor.tf.insertNodes(
        editor.api.create.block({
          type,
          ...(targetIndent > 0 ? { indent: targetIndent } : {}),
        }),
        {
          at: PathApi.next(path),
          select: true,
        },
      );
    }

    if (!isSameBlockType && isCurrentBlockEmpty) {
      editor.tf.removeNodes({ previousEmptyBlock: true });
    }
  });
};

export const insertInlineElement = (editor: PlateEditor, type: string) => {
  if (insertInlineMap[type]) {
    insertInlineMap[type]?.(editor, type);
  }
};

export function getCommandTargets(
  editor: PlateEditor,
  activeBlockId?: string,
): NodeEntry<TElement>[] {
  const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;
  const selectedNodes = blockSelectionApi ? blockSelectionApi.getNodes({ sort: true }) : [];
  if (selectedNodes.length > 0) {
    return selectedNodes as NodeEntry<TElement>[];
  }
  if (activeBlockId) {
    const nodeEntry = editor.api.node<TElement>({ id: activeBlockId });
    if (nodeEntry) return [nodeEntry];
  }
  const block = editor.api.block<TElement>();
  return block ? [block] : [];
}

export const setBlockType = (editor: PlateEditor, type: string, { at }: { at?: Path } = {}) => {
  editor.tf.withoutNormalizing(() => {
    if (type === KEYS.blockquote) {
      const target = at ?? editor.selection;
      if (!target || editor.api.some({ at: target, match: { type } })) {
        return;
      }

      editor.tf.toggleBlock(type, {
        ...(at ? { at } : {}),
        wrap: true,
      });
      return;
    }

    const setEntry = (entry: NodeEntry<TElement>) => {
      const [node, path] = entry;

      // 1. If currently in a blockquote, unwrap it if converting to another type
      if (
        editor.api.some({ at: path, match: { type: KEYS.blockquote } }) &&
        type !== KEYS.blockquote
      ) {
        editor.tf.unwrapNodes({ at: path, match: { type: KEYS.blockquote } });
      }

      // 2. Unset list / indent if converting to non-list
      if (node.listStyleType || node[KEYS.listType]) {
        if (type !== KEYS.ul && type !== KEYS.ol) {
          editor.tf.unsetNodes(['listStyleType', KEYS.listType, 'indent'], { at: path });
        }
      }

      // 3. Unset todo checked if converting to non-todo
      if (node.type === 'todo' && type !== 'todo' && type !== KEYS.listTodo) {
        editor.tf.unsetNodes(['checked'], { at: path });
      }

      // 4. Unset callout metadata if converting to non-callout
      if (node.type === KEYS.callout && type !== KEYS.callout) {
        editor.tf.unsetNodes(['variant', 'icon'], { at: path });
      }

      // 5. Code block transformation
      if (
        node.type === KEYS.codeBlock ||
        node.type === KEYS.codeLine ||
        editor.api.some({ at: path, match: { type: KEYS.codeBlock } })
      ) {
        if (at) {
          editor.tf.select(at);
        }
        unwrapCodeBlock(editor);
        if (type !== KEYS.p) {
          editor.tf.setNodes({ type }, at ? { at } : undefined);
        }
        return;
      }

      // 6. Converting to code block
      if (type === KEYS.codeBlock) {
        if (at) {
          editor.tf.select(at);
        }
        toggleCodeBlock(editor);
        return;
      }

      // 7. Converting to list
      if (type === KEYS.ul || type === KEYS.ol) {
        editor.tf.setNodes(
          {
            type: KEYS.p,
            listStyleType: type === KEYS.ol ? 'decimal' : 'disc',
            indent: (node.indent as number) || 1,
          },
          { at: path },
        );
        return;
      }

      // 8. Converting to todo
      if (type === KEYS.listTodo || type === 'todo') {
        editor.tf.unsetNodes(['listStyleType', KEYS.listType, 'indent'], { at: path });
        editor.tf.setNodes(
          {
            type: 'todo',
            checked: false,
          },
          { at: path },
        );
        return;
      }

      // 9. Converting to callout
      if (type === KEYS.callout) {
        editor.tf.setNodes(
          {
            type: KEYS.callout,
            variant: 'default',
            icon: '💡',
          },
          { at: path },
        );
        return;
      }

      // 10. Converting to toggle or toggle headings
      if (
        type === KEYS.toggle ||
        type === 'toggle_h1' ||
        type === 'toggle_h2' ||
        type === 'toggle_h3'
      ) {
        const headingLevel =
          type === 'toggle_h1'
            ? 1
            : type === 'toggle_h2'
              ? 2
              : type === 'toggle_h3'
                ? 3
                : node.type === KEYS.h1
                  ? 1
                  : node.type === KEYS.h2
                    ? 2
                    : node.type === KEYS.h3
                      ? 3
                      : (node.headingLevel as number | undefined);

        editor.tf.setNodes(
          {
            type: KEYS.toggle,
            open: true,
            ...(headingLevel ? { headingLevel } : {}),
          },
          { at: path },
        );
        return;
      }

      // Unset toggle metadata if converting from toggle to non-toggle
      if (node.type === KEYS.toggle && type !== KEYS.toggle && !type.startsWith('toggle')) {
        editor.tf.unsetNodes(['open', 'headingLevel', 'variant'], { at: path });
      }

      // 11. Default block type change
      if (node.type !== type) {
        editor.tf.setNodes({ type }, { at: path });
      }
    };

    if (at) {
      const entry = editor.api.node<TElement>(at);
      if (entry) {
        setEntry(entry);
        return;
      }
    }

    const targets = resolveBlockCommandTargets(editor);
    if (targets.length > 0) {
      targets.forEach((entry) => {
        setEntry(entry);
      });
      return;
    }

    const entries = editor.api.blocks({ mode: 'lowest' });
    entries.forEach((entry) => {
      setEntry(entry);
    });
  });
};

export const resolveBlockCommandTargets = getCommandTargets;

export const getBlockType = (block: TElement) => {
  if (block[KEYS.listType]) {
    if (block[KEYS.listType] === KEYS.ol) {
      return KEYS.ol;
    }
    if (block[KEYS.listType] === KEYS.listTodo) {
      return KEYS.listTodo;
    }
    return KEYS.ul;
  }
  return block.type;
};

export function insertBlockAfter(
  editor: PlateEditor,
  element: TextEditorElementNode,
  newBlock: TextEditorElementNode,
) {
  const path = editor.api.findPath(element as never);
  if (!path || path.length === 0) return;
  const nextPath = PathApi.next(path);
  editor.tf.insertNodes([newBlock as never], { at: nextPath });
  const startPoint = editor.api.start(nextPath);
  if (startPoint) {
    editor.tf.select(startPoint);
  }
  editor.tf.focus();
}
