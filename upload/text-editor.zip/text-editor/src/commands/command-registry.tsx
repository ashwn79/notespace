'use client';

import { AIChatPlugin } from '@platejs/ai/react';
import {
  BulletedList,
  Calendar,
  FileCode2,
  FileText,
  Heading1,
  Heading2,
  Heading3,
  Image as ImageIcon,
  InlineEquation,
  Mic,
  Minus,
  NumberedList,
  Quote,
  Sparkles,
  TodoList,
  ToggleHeading1,
  ToggleHeading2,
  ToggleHeading3,
  ToggleList,
  Type,
} from '@xpace/icons';
import {
  Columns2,
  Columns3,
  FileUp,
  Film,
  Lightbulb,
  Sigma,
  Table as TableIcon,
} from 'lucide-react';
import { KEYS } from 'platejs';
import type { PlateEditor } from 'platejs/react';
import type { CommandContext, EditorCommand } from '../types/command';
import {
  ACTION_THREE_COLUMNS,
  ACTION_TWO_COLUMNS,
  insertBlock,
  insertBlockAfter,
  insertInlineElement,
  setBlockType,
} from './transforms';

export const EDITOR_COMMANDS: EditorCommand[] = [
  // ── AI Commands ─────────────────────────────────────────
  {
    key: 'ai_ask',
    label: 'Ask AI',
    description: 'Ask AI to write, brainstorm, or assist.',
    icon: <Sparkles className="h-4 w-4 text-lime-400" />,
    keywords: ['ai', 'ask', 'generate', 'prompt', 'assistant', 'magic'],
    group: 'ai',
    type: 'action',
    focusEditor: false,
    execute: (editor: PlateEditor) => {
      editor.getApi(AIChatPlugin).aiChat?.show();
    },
  },

  // ── Basic Blocks ─────────────────────────────────────────
  {
    key: KEYS.p,
    label: 'Text',
    description: 'Plain paragraph text.',
    icon: <Type className="h-4 w-4" />,
    keywords: ['p', 'paragraph', 'text', 'normal', 'plain'],
    group: 'basic',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, { type: KEYS.p, children: [{ text: '' }] });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, KEYS.p, { at: ctx.at as never });
        return;
      }
      insertBlock(editor, KEYS.p, { upsert: true });
    },
  },
  {
    key: KEYS.h1,
    label: 'Heading 1',
    description: 'Large section heading.',
    shortcut: '#',
    icon: <Heading1 className="h-4 w-4" />,
    keywords: ['h1', 'heading', 'title', 'large', 'header', '#'],
    group: 'basic',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, { type: KEYS.h1, children: [{ text: '' }] });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, KEYS.h1, { at: ctx.at as never });
        return;
      }
      insertBlock(editor, KEYS.h1, { upsert: true });
    },
  },
  {
    key: KEYS.h2,
    label: 'Heading 2',
    description: 'Medium subsection heading.',
    shortcut: '##',
    icon: <Heading2 className="h-4 w-4" />,
    keywords: ['h2', 'heading', 'subtitle', 'medium', '##'],
    group: 'basic',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, { type: KEYS.h2, children: [{ text: '' }] });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, KEYS.h2, { at: ctx.at as never });
        return;
      }
      insertBlock(editor, KEYS.h2, { upsert: true });
    },
  },
  {
    key: KEYS.h3,
    label: 'Heading 3',
    description: 'Small subsection heading.',
    shortcut: '###',
    icon: <Heading3 className="h-4 w-4" />,
    keywords: ['h3', 'heading', 'subheading', 'small', '###'],
    group: 'basic',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, { type: KEYS.h3, children: [{ text: '' }] });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, KEYS.h3, { at: ctx.at as never });
        return;
      }
      insertBlock(editor, KEYS.h3, { upsert: true });
    },
  },
  {
    key: KEYS.ul,
    label: 'Bulleted list',
    description: 'Create a simple bulleted list item.',
    shortcut: '-',
    icon: <BulletedList className="h-4 w-4" />,
    keywords: ['ul', 'bullet', 'unordered', 'list', 'bulleted list', '-'],
    group: 'lists',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, {
          type: KEYS.p,
          listStyleType: 'disc',
          children: [{ text: '' }],
        });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, KEYS.ul, { at: ctx.at as never });
        return;
      }
      insertBlock(editor, KEYS.ul, { upsert: true });
    },
  },
  {
    key: KEYS.ol,
    label: 'Numbered list',
    description: 'Create a numbered list item.',
    shortcut: '1.',
    icon: <NumberedList className="h-4 w-4" />,
    keywords: ['ol', 'ordered', 'numbered', 'list', 'numbered list', '1', '1.'],
    group: 'lists',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, {
          type: KEYS.p,
          listStyleType: 'decimal',
          children: [{ text: '' }],
        });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, KEYS.ol, { at: ctx.at as never });
        return;
      }
      insertBlock(editor, KEYS.ol, { upsert: true });
    },
  },
  {
    key: KEYS.listTodo,
    label: 'To-do list',
    description: 'Track tasks with interactive checkboxes.',
    shortcut: '[]',
    icon: <TodoList className="h-4 w-4" />,
    keywords: ['todo', 'task', 'checklist', 'checkbox', 'to-do list', '[]'],
    group: 'lists',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, {
          type: 'todo',
          checked: false,
          children: [{ text: '' }],
        });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, KEYS.listTodo, { at: ctx.at as never });
        return;
      }
      insertBlock(editor, KEYS.listTodo, { upsert: true });
    },
  },
  {
    key: KEYS.toggle,
    label: 'Toggle list',
    description: 'Collapsible block with nested content.',
    shortcut: '>',
    icon: <ToggleList className="h-4 w-4" />,
    keywords: ['toggle', 'toggle list', 'collapse', 'collapsible', 'details', 'accordion', '>'],
    group: 'basic',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, {
          type: KEYS.toggle,
          open: true,
          children: [{ text: '' }],
        });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, KEYS.toggle, { at: ctx.at as never });
        return;
      }
      insertBlock(editor, KEYS.toggle, { upsert: true });
    },
  },
  {
    key: 'toggle_h1',
    label: 'Toggle heading 1',
    description: 'Large heading with collapsible content.',
    shortcut: '>#',
    icon: <ToggleHeading1 className="h-4 w-4" />,
    keywords: ['toggle', 'toggle heading 1', 'heading 1', 'h1', 'th1', '>#'],
    group: 'basic',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, {
          type: KEYS.toggle,
          headingLevel: 1,
          open: true,
          children: [{ text: '' }],
        });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, 'toggle_h1', { at: ctx.at as never });
        return;
      }
      insertBlock(editor, 'toggle_h1', { upsert: true });
    },
  },
  {
    key: 'toggle_h2',
    label: 'Toggle heading 2',
    description: 'Medium heading with collapsible content.',
    shortcut: '>##',
    icon: <ToggleHeading2 className="h-4 w-4" />,
    keywords: ['toggle', 'toggle heading 2', 'heading 2', 'h2', 'th2', '>##'],
    group: 'basic',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, {
          type: KEYS.toggle,
          headingLevel: 2,
          open: true,
          children: [{ text: '' }],
        });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, 'toggle_h2', { at: ctx.at as never });
        return;
      }
      insertBlock(editor, 'toggle_h2', { upsert: true });
    },
  },
  {
    key: 'toggle_h3',
    label: 'Toggle heading 3',
    description: 'Small heading with collapsible content.',
    shortcut: '>###',
    icon: <ToggleHeading3 className="h-4 w-4" />,
    keywords: ['toggle', 'toggle heading 3', 'heading 3', 'h3', 'th3', '>###'],
    group: 'basic',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, {
          type: KEYS.toggle,
          headingLevel: 3,
          open: true,
          children: [{ text: '' }],
        });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, 'toggle_h3', { at: ctx.at as never });
        return;
      }
      insertBlock(editor, 'toggle_h3', { upsert: true });
    },
  },
  {
    key: KEYS.codeBlock,
    label: 'Code block',
    description: 'Code snippet with syntax highlighting.',
    shortcut: '```',
    icon: <FileCode2 className="h-4 w-4" />,
    keywords: ['code', 'snippet', 'syntax', 'programming', 'pre', '```'],
    group: 'basic',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, {
          type: KEYS.codeBlock,
          children: [{ type: KEYS.codeLine, children: [{ text: '' }] }],
        });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, KEYS.codeBlock, { at: ctx.at as never });
        return;
      }
      insertBlock(editor, KEYS.codeBlock, { upsert: true });
    },
  },
  {
    key: KEYS.table,
    label: 'Table',
    description: 'Insert a multi-column structured table.',
    icon: <TableIcon className="h-4 w-4" />,
    keywords: ['table', 'grid', 'rows', 'columns', 'data'],
    group: 'basic',
    type: 'block',
    execute: (editor: PlateEditor) => {
      insertBlock(editor, KEYS.table, { upsert: true });
    },
  },
  {
    key: KEYS.blockquote,
    label: 'Quote',
    description: 'Highlighted quotation statement.',
    shortcut: '"',
    icon: <Quote className="h-4 w-4" />,
    keywords: ['quote', 'blockquote', 'cite', '"'],
    group: 'basic',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, {
          type: KEYS.blockquote,
          children: [{ text: '' }],
        });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, KEYS.blockquote, { at: ctx.at as never });
        return;
      }
      insertBlock(editor, KEYS.blockquote, { upsert: true });
    },
  },
  {
    key: KEYS.callout,
    label: 'Callout',
    description: 'Highlighted note or tip box with an icon.',
    icon: <Lightbulb className="h-4 w-4" />,
    keywords: ['callout', 'note', 'alert', 'warning', 'tip', 'info'],
    group: 'basic',
    type: 'block',
    canTurnInto: true,
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, {
          type: KEYS.callout,
          children: [{ text: '' }],
        });
        return;
      }
      if (ctx?.at) {
        setBlockType(editor, KEYS.callout, { at: ctx.at as never });
        return;
      }
      insertBlock(editor, KEYS.callout, { upsert: true });
    },
  },

  // ── Media Blocks ─────────────────────────────────────────
  {
    key: KEYS.img,
    label: 'Image',
    description: 'Upload or embed an image with captions and resize.',
    icon: <ImageIcon className="h-4 w-4" />,
    keywords: ['image', 'photo', 'picture', 'upload', 'img'],
    group: 'media',
    type: 'block',
    execute: (editor: PlateEditor) => {
      insertBlock(editor, KEYS.img, { upsert: true });
    },
  },
  {
    key: KEYS.video,
    label: 'Video',
    description: 'Embed or upload video with playback controls.',
    icon: <Film className="h-4 w-4" />,
    keywords: ['video', 'movie', 'film', 'mp4', 'youtube'],
    group: 'media',
    type: 'block',
    execute: (editor: PlateEditor) => {
      insertBlock(editor, KEYS.video, { upsert: true });
    },
  },
  {
    key: KEYS.audio,
    label: 'Audio',
    description: 'Embed audio track or voice note.',
    icon: <Mic className="h-4 w-4" />,
    keywords: ['audio', 'sound', 'music', 'mp3', 'voice'],
    group: 'media',
    type: 'block',
    execute: (editor: PlateEditor) => {
      insertBlock(editor, KEYS.audio, { upsert: true });
    },
  },
  {
    key: KEYS.file,
    label: 'File',
    description: 'Upload attachment or downloadable document.',
    icon: <FileUp className="h-4 w-4" />,
    keywords: ['file', 'attachment', 'upload', 'pdf', 'document'],
    group: 'media',
    type: 'block',
    execute: (editor: PlateEditor) => {
      insertBlock(editor, KEYS.file, { upsert: true });
    },
  },

  // ── Advanced Blocks ───────────────────────────────────────
  {
    key: KEYS.toc,
    label: 'Table of Contents',
    description: 'Dynamic outline derived from headings.',
    icon: <FileText className="h-4 w-4" />,
    keywords: ['toc', 'outline', 'index', 'headings', 'contents'],
    group: 'advanced',
    type: 'block',
    execute: (editor: PlateEditor) => {
      insertBlock(editor, KEYS.toc, { upsert: true });
    },
  },
  {
    key: KEYS.equation,
    label: 'Equation',
    description: 'Block LaTeX mathematical equation.',
    icon: <Sigma className="h-4 w-4" />,
    keywords: ['math', 'equation', 'latex', 'formula', 'tex'],
    group: 'advanced',
    type: 'block',
    focusEditor: false,
    execute: (editor: PlateEditor) => {
      insertBlock(editor, KEYS.equation, { upsert: true });
    },
  },
  {
    key: 'columns_2',
    label: '2 Columns',
    description: 'Split section into 2 side-by-side columns.',
    icon: <Columns2 className="h-4 w-4" />,
    keywords: ['columns', 'layout', 'grid', 'side-by-side', '2'],
    group: 'advanced',
    type: 'block',
    execute: (editor: PlateEditor) => {
      insertBlock(editor, ACTION_TWO_COLUMNS, { upsert: true });
    },
  },
  {
    key: 'columns_3',
    label: '3 Columns',
    description: 'Split section into 3 side-by-side columns.',
    icon: <Columns3 className="h-4 w-4" />,
    keywords: ['columns', 'layout', 'grid', '3'],
    group: 'advanced',
    type: 'block',
    execute: (editor: PlateEditor) => {
      insertBlock(editor, ACTION_THREE_COLUMNS, { upsert: true });
    },
  },
  {
    key: KEYS.hr,
    label: 'Divider',
    description: 'Horizontal divider line.',
    shortcut: '---',
    icon: <Minus className="h-4 w-4" />,
    keywords: ['divider', 'hr', 'line', 'separator', 'rule', '---'],
    group: 'advanced',
    type: 'block',
    execute: (editor: PlateEditor, ctx?: CommandContext) => {
      if (ctx?.insertAfter && ctx?.element) {
        insertBlockAfter(editor, ctx.element, {
          type: KEYS.hr,
          children: [{ text: '' }],
        });
        return;
      }
      insertBlock(editor, KEYS.hr, { upsert: true });
    },
  },

  // ── Inline Elements ───────────────────────────────────────
  {
    key: KEYS.date,
    label: 'Date',
    description: 'Insert an interactive date picker badge.',
    icon: <Calendar className="h-4 w-4" />,
    keywords: ['date', 'calendar', 'time', 'today'],
    group: 'inline',
    type: 'inline',
    focusEditor: true,
    execute: (editor: PlateEditor) => {
      insertInlineElement(editor, KEYS.date);
    },
  },
  {
    key: KEYS.inlineEquation,
    label: 'Inline Equation',
    description: 'Insert inline mathematical formula.',
    icon: <InlineEquation className="h-4 w-4" />,
    keywords: ['math', 'inline', 'formula', 'latex'],
    group: 'inline',
    type: 'inline',
    focusEditor: false,
    execute: (editor: PlateEditor) => {
      insertInlineElement(editor, KEYS.inlineEquation);
    },
  },
];

export const TURN_INTO_COMMANDS = EDITOR_COMMANDS.filter((cmd) => cmd.canTurnInto);

export const BASIC_COMMANDS = EDITOR_COMMANDS.filter(
  (cmd) => cmd.group === 'basic' || cmd.group === 'lists',
);
