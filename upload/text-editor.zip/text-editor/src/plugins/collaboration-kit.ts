'use client';

import { BaseCommentPlugin } from '@platejs/comment';
import { BaseSuggestionPlugin } from '@platejs/suggestion';
import type { PlatePlugins } from 'platejs/react';
import { toPlatePlugin } from 'platejs/react';
import { CommentLeaf } from '../plate-ui/comment-leaf';
import { SuggestionLeaf } from '../plate-ui/suggestion-leaf';

export const CommentPlugin = toPlatePlugin(BaseCommentPlugin).configure({
  node: { component: CommentLeaf },
});

export const SuggestionPlugin = toPlatePlugin(BaseSuggestionPlugin).configure({
  render: { node: SuggestionLeaf },
});

export const CollaborationKit: PlatePlugins = [CommentPlugin, SuggestionPlugin];
