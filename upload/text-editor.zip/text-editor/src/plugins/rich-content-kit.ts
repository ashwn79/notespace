'use client';

import { CalloutPlugin } from '@platejs/callout/react';
import { DatePlugin } from '@platejs/date/react';
import { ColumnItemPlugin, ColumnPlugin } from '@platejs/layout/react';
import { EquationPlugin, InlineEquationPlugin } from '@platejs/math/react';
import { BlockSelectionPlugin } from '@platejs/selection/react';
import { getNextTableCell, getPreviousTableCell } from '@platejs/table';
import {
  TableCellHeaderPlugin,
  TableCellPlugin,
  TablePlugin,
  TableRowPlugin,
} from '@platejs/table/react';
import { TocPlugin } from '@platejs/toc/react';
import { TogglePlugin } from '@platejs/toggle/react';
import { createRuleFactory, KEYS, PathApi } from 'platejs';
import { createPlatePlugin, type PlatePlugins } from 'platejs/react';

const toggleRule = (createRuleFactory as any)({
  type: 'blockStart',
  trigger: ' ',
  match: () => /^(?:>|>>)$/,
  apply: ({ editor }: { editor: any }, match: any) => {
    editor.tf.delete({ at: match.range });
    editor.tf.setNodes({
      type: KEYS.toggle,
      open: true,
    });
    return true;
  },
});

const toggleH1Rule = (createRuleFactory as any)({
  type: 'blockStart',
  trigger: ' ',
  match: () => /^>#$/,
  apply: ({ editor }: { editor: any }, match: any) => {
    editor.tf.delete({ at: match.range });
    editor.tf.setNodes({
      type: KEYS.toggle,
      headingLevel: 1,
      open: true,
    });
    return true;
  },
});

const toggleH2Rule = (createRuleFactory as any)({
  type: 'blockStart',
  trigger: ' ',
  match: () => /^>##$/,
  apply: ({ editor }: { editor: any }, match: any) => {
    editor.tf.delete({ at: match.range });
    editor.tf.setNodes({
      type: KEYS.toggle,
      headingLevel: 2,
      open: true,
    });
    return true;
  },
});

const toggleH3Rule = (createRuleFactory as any)({
  type: 'blockStart',
  trigger: ' ',
  match: () => /^>###$/,
  apply: ({ editor }: { editor: any }, match: any) => {
    editor.tf.delete({ at: match.range });
    editor.tf.setNodes({
      type: KEYS.toggle,
      headingLevel: 3,
      open: true,
    });
    return true;
  },
});
import { CalloutElement } from '../plate-ui/callout-element';
import { ColumnElement, ColumnGroupElement } from '../plate-ui/column-element';
import { DateElement } from '../plate-ui/date-element';
import { EquationElement, InlineEquationElement } from '../plate-ui/equation-element';
import {
  TableCellElement,
  TableCellHeaderElement,
  TableElement,
  TableRowElement,
} from '../plate-ui/table-element';
import { TocElement } from '../plate-ui/toc-element';
import { ToggleElement } from '../plate-ui/toggle-element';
import { removeContainerSubtree, unwrapToggle } from '../plate-ui/toggle-utils';

export const TableKeyboardPlugin = createPlatePlugin({
  key: 'tableKeyboard',
  handlers: {
    onKeyDown: ({ editor, event }: { editor: any; event: any }): any => {
      if (event.key === 'Tab') {
        const cellEntry = editor.api.above({ match: { type: [KEYS.td, KEYS.th, 'td', 'th'] } });
        if (!cellEntry) return;

        event.preventDefault();
        event.stopPropagation();

        const [cellNode, cellPath] = cellEntry;
        const rowEntry = editor.api.parent(cellPath);
        if (!rowEntry) return;

        if (event.shiftKey) {
          const prevCell = getPreviousTableCell(editor, cellNode, cellPath, rowEntry);
          if (prevCell) {
            editor.tf.select(editor.api.start(prevCell[1]));
          } else {
            const tableEntry = editor.api.above({ match: { type: TablePlugin.key } });
            if (tableEntry && tableEntry[1][0] > 0) {
              const prevPath = [tableEntry[1][0] - 1];
              editor.tf.select(editor.api.end(prevPath));
            }
          }
          return true;
        }

        const nextCell = getNextTableCell(editor, cellNode, cellPath, rowEntry);
        if (nextCell) {
          editor.tf.select(editor.api.start(nextCell[1]));
        } else {
          // Tab from final cell: move to next editable block after table without auto-adding row
          const tableEntry = editor.api.above({ match: { type: TablePlugin.key } });
          const tablePath = tableEntry ? tableEntry[1] : [cellPath[0]];
          const nextBlockPath = PathApi.next(tablePath);
          const nextNode = editor.api.node(nextBlockPath);
          if (nextNode) {
            editor.tf.select(editor.api.start(nextBlockPath));
          } else {
            editor.tf.insertNodes(
              editor.api.create.block({ type: KEYS.p, children: [{ text: '' }] }),
              { at: nextBlockPath, select: true },
            );
          }
        }
        return true;
      }
    },
  },
});

export const ToggleKeyboardPlugin = createPlatePlugin({
  key: 'toggleKeyboard',
  handlers: {
    onKeyDown: ({ editor, event }: { editor: any; event: any }): any => {
      // 1. Keyboard toggle shortcut: Ctrl+Enter / Cmd+Enter / Alt+Enter (Feature 58)
      if (
        (event.metaKey || event.ctrlKey || event.altKey) &&
        event.key === 'Enter'
      ) {
        const entry = editor.api.block();
        if (entry && entry[0].type === KEYS.toggle) {
          event.preventDefault();
          const [node, path] = entry;
          const nextState = !node.open;
          editor.getApi(TogglePlugin)?.toggle?.toggleIds?.([node.id as string], nextState);
          editor.tf.setNodes({ open: nextState }, { at: path });
          return true;
        }
      }

      // 2. Enter key behavior (Features 16 & 17)
      if (event.key === 'Enter' && !event.shiftKey) {
        if (!editor.selection) return;
        const entry = editor.api.block();
        if (!entry) return;
        const [node, path] = entry;

        // Inside Toggle Header
        if (node.type === KEYS.toggle) {
          if (editor.api.isEnd(editor.selection.focus, path)) {
            event.preventDefault();
            // Expand toggle if collapsed so children are visible
            editor.getApi(TogglePlugin)?.toggle?.toggleIds?.([node.id as string], true);
            editor.tf.setNodes({ open: true }, { at: path });
            const nextPath = PathApi.next(path);
            const childIndent = ((node.indent as number) || 0) + 1;
            editor.tf.insertNodes(
              editor.api.create.block({
                type: KEYS.p,
                indent: childIndent,
                children: [{ text: '' }],
              }),
              { at: nextPath, select: true },
            );
            return true;
          }
        }

        // Inside Child Block: Empty child exit behavior (Feature 17)
        const currentIndent = (node.indent as number) || 0;
        if (currentIndent > 0 && editor.api.isEmpty(node)) {
          event.preventDefault();
          const newIndent = currentIndent - 1;
          if (newIndent === 0) {
            editor.tf.unsetNodes('indent', { at: path });
          } else {
            editor.tf.setNodes({ indent: newIndent }, { at: path });
          }
          return true;
        }
      }

      // 3. Backspace behavior (Feature 18)
      if (event.key === 'Backspace' && !event.shiftKey) {
        if (!editor.selection) return;
        const entry = editor.api.block();
        if (!entry) return;
        const [node, path] = entry;

        // Backspace on empty toggle title: unwrap toggle (convert to p, keep children)
        if (
          node.type === KEYS.toggle &&
          editor.api.isEmpty(node) &&
          editor.api.isStart(editor.selection.focus, path)
        ) {
          event.preventDefault();
          unwrapToggle(editor, node);
          return true;
        }

        // Backspace on indented child block at start of line: outdent
        const currentIndent = (node.indent as number) || 0;
        if (
          currentIndent > 0 &&
          editor.api.isStart(editor.selection.focus, path)
        ) {
          event.preventDefault();
          const newIndent = currentIndent - 1;
          if (newIndent === 0) {
            editor.tf.unsetNodes('indent', { at: path });
          } else {
            editor.tf.setNodes({ indent: newIndent }, { at: path });
          }
          return true;
        }
      }

      // 4. Delete key: remove entire container subtree if selected
      if (event.key === 'Delete') {
        const entry = editor.api.block();
        if (entry && entry[0].type === KEYS.toggle) {
          const blockSelectionApi = editor.getApi(BlockSelectionPlugin)?.blockSelection;
          if (blockSelectionApi?.getNodes().some(([n]: any) => n.id === entry[0].id)) {
            event.preventDefault();
            removeContainerSubtree(editor, entry[0]);
            blockSelectionApi.clear();
            return true;
          }
        }
      }
    },
  },
});

export const RichContentKit: PlatePlugins = [
  // Callouts
  CalloutPlugin.withComponent(CalloutElement),

  // Toggles
  TogglePlugin.configure({
    inputRules: [toggleRule(), toggleH1Rule(), toggleH2Rule(), toggleH3Rule()],
  }).withComponent(ToggleElement),
  ToggleKeyboardPlugin,

  // Tables
  TablePlugin.configure({
    options: {
      initialTableWidth: 600,
      minColumnWidth: 48,
    },
  }).withComponent(TableElement),  TableKeyboardPlugin,
  TableRowPlugin.withComponent(TableRowElement),
  TableCellPlugin.withComponent(TableCellElement),
  TableCellHeaderPlugin.withComponent(TableCellHeaderElement),


  // Multi-column Layouts
  ColumnPlugin.withComponent(ColumnGroupElement),
  ColumnItemPlugin.withComponent(ColumnElement),

  // Equations (KaTeX)
  EquationPlugin.withComponent(EquationElement),
  InlineEquationPlugin.withComponent(InlineEquationElement),

  // Table of Contents
  TocPlugin.withComponent(TocElement),

  // Date Nodes
  DatePlugin.withComponent(DateElement),
];
