'use client';

import {
  BoldRules,
  CodeRules,
  HighlightRules,
  ItalicRules,
  StrikethroughRules,
  UnderlineRules,
} from '@platejs/basic-nodes';
import {
  BoldPlugin,
  CodePlugin,
  HighlightPlugin,
  ItalicPlugin,
  StrikethroughPlugin,
  UnderlinePlugin,
} from '@platejs/basic-nodes/react';
import {
  FontBackgroundColorPlugin,
  FontColorPlugin,
  TextAlignPlugin,
} from '@platejs/basic-styles/react';
import { LinkRules } from '@platejs/link';
import { LinkPlugin } from '@platejs/link/react';
import type { PlatePlugins } from 'platejs/react';
import { createPlatePlugin } from 'platejs/react';
import { CodeLeaf } from '../plate-ui/code-leaf';
import { BackgroundColorLeaf, ColorLeaf } from '../plate-ui/color-leaf';
import { HighlightLeaf } from '../plate-ui/highlight-leaf';
import { LinkElement } from '../plate-ui/link-element';

export const ColorPlugin = createPlatePlugin({
  key: 'color',
  node: {
    isLeaf: true,
    component: ColorLeaf,
  },
});

export const BackgroundColorPlugin = createPlatePlugin({
  key: 'backgroundColor',
  node: {
    isLeaf: true,
    component: BackgroundColorLeaf,
  },
});

export const MarksKit: PlatePlugins = [
  BoldPlugin.configure({
    inputRules: [BoldRules.markdown({ variant: '*' }), BoldRules.markdown({ variant: '_' })],
  }),
  ItalicPlugin.configure({
    inputRules: [ItalicRules.markdown({ variant: '*' }), ItalicRules.markdown({ variant: '_' })],
  }),
  UnderlinePlugin.configure({
    inputRules: [UnderlineRules.markdown()],
  }),
  StrikethroughPlugin.configure({
    inputRules: [StrikethroughRules.markdown()],
  }),
  CodePlugin.configure({
    inputRules: [CodeRules.markdown()],
    node: { component: CodeLeaf },
  }),
  HighlightPlugin.configure({
    inputRules: [HighlightRules.markdown()],
    node: { component: HighlightLeaf },
  }),
  LinkPlugin.configure({
    inputRules: [
      LinkRules.autolink({ variant: 'paste' }),
      LinkRules.autolink({ variant: 'space' }),
      LinkRules.autolink({ variant: 'break' }),
      LinkRules.markdown({}),
    ],
    options: {
      allowedSchemes: ['http', 'https', 'mailto', 'tel'],
      keepSelectedTextOnPaste: true,
    },
  }).withComponent(LinkElement),

  // Style attributes with leaf rendering
  FontColorPlugin,
  FontBackgroundColorPlugin,
  ColorPlugin,
  BackgroundColorPlugin,
  TextAlignPlugin.configure({
    inject: {
      targetPlugins: ['p', 'h1', 'h2', 'h3', 'blockquote', 'code_block'],
    },
  }),
];
