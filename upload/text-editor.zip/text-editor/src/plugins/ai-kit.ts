'use client';

import { AIChatPlugin, AIPlugin, CopilotPlugin } from '@platejs/ai/react';
import type { PlatePlugins } from 'platejs/react';
import { AILoadingBar, AIMenu } from '../plate-ui/ai-menu';
import { GhostText } from '../plate-ui/ghost-text';

export const AIKit: PlatePlugins = [
  AIPlugin,
  AIChatPlugin.configure({
    shortcuts: { show: { keys: 'mod+j' } },
    render: {
      afterContainer: AILoadingBar,
      afterEditable: AIMenu,
    },
  }),
  CopilotPlugin.configure({
    options: {
      renderGhostText: GhostText,
      debounceDelay: 400,
    },
    shortcuts: {
      accept: { keys: 'tab' },
      acceptNextWord: { keys: 'mod+right' },
      reject: { keys: 'escape' },
      triggerSuggestion: { keys: 'ctrl+space' },
    },
  }),
];
