'use client';

import { HeadingRules, HorizontalRuleRules } from '@platejs/basic-nodes';
import {
  BlockquotePlugin,
  H1Plugin,
  H2Plugin,
  H3Plugin,
  HorizontalRulePlugin,
} from '@platejs/basic-nodes/react';
import { CodeBlockRules } from '@platejs/code-block';
import { CodeBlockPlugin, CodeLinePlugin, CodeSyntaxPlugin } from '@platejs/code-block/react';
import { indent, outdent } from '@platejs/indent';
import { IndentPlugin } from '@platejs/indent/react';
import {
  BulletedListRules,
  isOrderedList,
  ListStyleType,
  OrderedListRules,
  TaskListRules,
  toggleList,
} from '@platejs/list';
import { ListPlugin } from '@platejs/list/react';
import { all, createLowlight } from 'lowlight';
import { createRuleFactory, KEYS } from 'platejs';
import { createPlatePlugin, ParagraphPlugin, type PlatePlugins } from 'platejs/react';
import { BlockList } from '../plate-ui/block-list';
import { BlockquoteElement } from '../plate-ui/blockquote-element';
import { CodeBlockElement, CodeLineElement, CodeSyntaxLeaf } from '../plate-ui/code-block-element';
import { DividerElement } from '../plate-ui/divider-element';
import { H1Element, H2Element, H3Element } from '../plate-ui/heading-element';
import { ParagraphElement } from '../plate-ui/paragraph-element';
import { TodoElement } from '../plate-ui/todo-element';

const lowlight = createLowlight(all);

const quoteRule = (createRuleFactory as any)({
  type: 'blockStart',
  trigger: ' ',
  match: () => /^["”]$/,
  apply: ({ editor }: { editor: any }, match: any) => {
    editor.tf.delete({ at: match.range });
    editor.tf.setNodes({
      type: KEYS.blockquote,
    });
    return true;
  },
});

const todoRule = (createRuleFactory as any)({
  type: 'blockStart',
  trigger: ' ',
  match: ({ checked }: { checked?: boolean }) => (checked ? /^\[[xX]\]$/ : /^\[ ?\]$/),
  apply: ({ editor, checked }: { editor: any; checked?: boolean }, match: any) => {
    editor.tf.delete({ at: match.range });
    editor.tf.setNodes({
      type: 'todo',
      checked: Boolean(checked),
    });
    return true;
  },
});

export const TodoPlugin = createPlatePlugin({
  key: 'todo',
  node: { isElement: true },
  inputRules: [todoRule({ checked: false }), todoRule({ checked: true })],
}).withComponent(TodoElement);

export const BlockIndentKeyboardPlugin = createPlatePlugin({
  key: 'blockIndentKeyboard',
  handlers: {
    onKeyDown: ({ editor, event }) => {
      if (event.key === 'Tab') {
        const inTable = (editor as any).api.some({
          match: { type: ['table', 'tr', 'td', 'th'] },
        });
        if (inTable) return;

        event.preventDefault();
        if (event.shiftKey) {
          outdent(editor);
          return;
        }

        const entry = editor.api.block();
        if (!entry) return;
        const [node, path] = entry;

        if (node.type === 'code_block' || node.type === 'code_line') {
          editor.tf.insertText('  ');
          return;
        }

        if (path[0] === 0 && path.length === 1) {
          return;
        }

        const currentIndent = (node.indent as number) || 0;
        if (currentIndent >= 6) {
          return;
        }

        indent(editor);
      }
    },
  },
});

export const DocumentInvariantPlugin = createPlatePlugin({
  key: 'documentInvariant',
  extendEditor: ({ editor }) => {
    const origNormalizeNode = (editor as any).normalizeNode?.bind(editor);
    (editor as any).normalizeNode = (entry: any) => {
      const [, path] = entry;
      if (path.length === 0) {
        if (!editor.children || editor.children.length === 0) {
          editor.tf.insertNodes(
            editor.api.create.block({
              type: KEYS.p,
              children: [{ text: '' }],
            }),
            { at: [0] },
          );
          return;
        }
      }
      origNormalizeNode?.(entry);
    };
    return editor;
  },
});

export const BlocksKit: PlatePlugins = [
  DocumentInvariantPlugin,
  ParagraphPlugin.withComponent(ParagraphElement),
  H1Plugin.configure({
    inputRules: [HeadingRules.markdown()],
    node: { component: H1Element },
    rules: { break: { empty: 'reset' } },
    shortcuts: { toggle: { keys: 'mod+alt+1' } },
  }),
  H2Plugin.configure({
    inputRules: [HeadingRules.markdown()],
    node: { component: H2Element },
    rules: { break: { empty: 'reset' } },
    shortcuts: { toggle: { keys: 'mod+alt+2' } },
  }),
  H3Plugin.configure({
    inputRules: [HeadingRules.markdown()],
    node: { component: H3Element },
    rules: { break: { empty: 'reset' } },
    shortcuts: { toggle: { keys: 'mod+alt+3' } },
  }),
  BlockquotePlugin.configure({
    inputRules: [quoteRule()],
    node: { component: BlockquoteElement },
    shortcuts: { toggle: { keys: 'mod+shift+period' } },
  }),
  HorizontalRulePlugin.configure({
    inputRules: [
      HorizontalRuleRules.markdown({ variant: '-' }),
      HorizontalRuleRules.markdown({ variant: '_' }),
    ],
    node: { component: DividerElement },
  }),

  // Code Block with syntax highlighting
  CodeBlockPlugin.configure({
    inputRules: [CodeBlockRules.markdown({ on: 'match' })],
    node: { component: CodeBlockElement },
    options: { lowlight },
    shortcuts: { toggle: { keys: 'mod+alt+8' } },
  }),
  CodeLinePlugin.withComponent(CodeLineElement),
  CodeSyntaxPlugin.withComponent(CodeSyntaxLeaf),

  // Lists & Todo
  TodoPlugin,
  ListPlugin.configure({
    inputRules: [
      BulletedListRules.markdown({ variant: '-' }),
      BulletedListRules.markdown({ variant: '*' }),
      (createRuleFactory as any)({
        type: 'blockStart',
        trigger: ' ',
        match: '+',
        apply: ({ editor }: { editor: any }, match: any) => {
          editor.tf.delete({ at: match.range });
          toggleList(editor, { listStyleType: ListStyleType.Disc });
          return true;
        },
      })(),
      OrderedListRules.markdown({ variant: '.' }),
      OrderedListRules.markdown({ variant: ')' }),
      TaskListRules.markdown({ checked: false }),
      TaskListRules.markdown({ checked: true }),
    ],
    inject: {
      nodeProps: {
        nodeKey: KEYS.listType,
        query: ({ nodeProps }) => {
          const element = nodeProps.element;
          return !!element?.listStyleType && !isOrderedList(element);
        },
        transformProps: ({ props }) => ({
          ...props,
          role: 'listitem',
          style: {
            ...props.style,
            display: 'list-item',
          },
        }),
      },
      targetPlugins: [...KEYS.heading, KEYS.p, KEYS.blockquote, KEYS.codeBlock, KEYS.toggle],
    },
    render: {
      belowNodes: BlockList,
    },
  }),

  // Indentation
  IndentPlugin.configure({
    inject: {
      targetPlugins: [
        'p',
        'h1',
        'h2',
        'h3',
        'blockquote',
        'code_block',
        'code_line',
        'todo',
        'toggle',
        'callout',
        'img',
        'video',
        'audio',
        'file',
        'media_embed',
        'table',
        'hr',
        'date',
        'column_group',
        'column',
        'toc',
        'equation',
        'placeholder',
      ],
    },
  }),
  BlockIndentKeyboardPlugin,
];
