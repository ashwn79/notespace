'use client';

import { CaptionPlugin } from '@platejs/caption/react';
import {
  AudioPlugin,
  FilePlugin,
  ImagePlugin,
  PlaceholderPlugin,
  VideoPlugin,
} from '@platejs/media/react';
import type { PlatePlugins } from 'platejs/react';
import { MediaAudioElement } from '../plate-ui/media-audio-element';
import { MediaFileElement } from '../plate-ui/media-file-element';
import { MediaImageElement } from '../plate-ui/media-image-element';
import { MediaPlaceholderElement } from '../plate-ui/media-placeholder-element';
import { MediaVideoElement } from '../plate-ui/media-video-element';

export const MediaKit: PlatePlugins = [
  CaptionPlugin,
  ImagePlugin.withComponent(MediaImageElement),
  VideoPlugin.withComponent(MediaVideoElement),
  AudioPlugin.withComponent(MediaAudioElement),
  FilePlugin.withComponent(MediaFileElement),
  PlaceholderPlugin.withComponent(MediaPlaceholderElement),
];
