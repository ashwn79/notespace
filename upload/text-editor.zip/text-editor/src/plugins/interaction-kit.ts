import emojiData from '@emoji-mart/data';
import { DndPlugin } from '@platejs/dnd';
import { EmojiInputPlugin, EmojiPlugin } from '@platejs/emoji/react';
import { MentionInputPlugin, MentionPlugin } from '@platejs/mention/react';
import { BlockMenuPlugin, BlockSelectionPlugin } from '@platejs/selection/react';
import { SlashInputPlugin, SlashPlugin } from '@platejs/slash-command/react';
import { KEYS, type SlateEditor } from 'platejs';
import { createPlatePlugin, type PlatePlugins } from 'platejs/react';
import * as React from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { BlockContextMenu } from '../plate-ui/block-context-menu';
import { BlockDraggable } from '../plate-ui/block-draggable';
import { EmojiInputElement } from '../plate-ui/emoji-input-element';
import { MentionElement } from '../plate-ui/mention-element';
import { MentionInputElement } from '../plate-ui/mention-input-element';
import { SlashInputElement } from '../plate-ui/slash-input-element';

export const BlockSelectionKeyboardPlugin = createPlatePlugin({
  key: 'blockSelectionKeyboard',
  handlers: {
    onKeyDown: ({ editor, event }) => {
      if (event.key === 'Escape') {
        const bs = editor.getApi(BlockSelectionPlugin)?.blockSelection;
        if (bs && bs.getNodes().length > 0) {
          event.preventDefault();
          bs.unselect();
          editor.tf.focus();
          return true;
        }
      }
      return false;
    },
  },
});

export const InteractionKit: PlatePlugins = [
  // 1. Universal Drag-and-Drop & Gutter
  DndPlugin.configure({
    options: {
      enableScroller: true,
    },
    render: {
      aboveNodes: BlockDraggable,
      aboveSlate: ({ children }: { children: React.ReactNode }) =>
        React.createElement(DndProvider, { backend: HTML5Backend }, children),
    },
  }),

  // 2. Block Selection & Multi-select & Block Context Menu
  BlockSelectionPlugin,
  BlockSelectionKeyboardPlugin,
  BlockMenuPlugin.configure({
    render: { aboveEditable: BlockContextMenu },
  }),

  // 3. Slash Commands (/)
  SlashPlugin.configure({
    options: {
      triggerQuery: (editor: SlateEditor) =>
        !editor.api.some({
          match: { type: editor.getType(KEYS.codeBlock) },
        }),
    },
  }),
  SlashInputPlugin.withComponent(SlashInputElement),

  // 4. Mentions (@)
  MentionPlugin.configure({
    options: {
      trigger: '@',
      triggerPreviousCharPattern: /^[\s"'(]?$/,
      triggerQuery: (editor: SlateEditor) =>
        !editor.api.some({
          match: { type: editor.getType(KEYS.codeBlock) },
        }),
    },
    node: { component: MentionElement },
  }),
  MentionInputPlugin.withComponent(MentionInputElement),

  // 5. Emoji (:)
  EmojiPlugin.configure({
    options: {
      data: emojiData as any,
      trigger: ':',
      triggerPreviousCharPattern: /^\s?$/,
      triggerQuery: (editor: SlateEditor) =>
        !editor.api.some({
          match: { type: editor.getType(KEYS.codeBlock) },
        }),
    },
  }),
  EmojiInputPlugin.withComponent(EmojiInputElement),
];
