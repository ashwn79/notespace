'use client';

import { MarkdownPlugin } from '@platejs/markdown';
import { NodeIdPlugin } from 'platejs';
import type { PlatePlugins } from 'platejs/react';
import { toPlatePlugin } from 'platejs/react';
// import { AIKit } from './ai-kit';
import { BlocksKit } from './blocks-kit';
// import { CollaborationKit } from './collaboration-kit';
import { InteractionKit } from './interaction-kit';
import { MarksKit } from './marks-kit';
import { MediaKit } from './media-kit';
import { RichContentKit } from './rich-content-kit';

export const editorPlugins: PlatePlugins = [
  // 1. Stable Node Identity (normalizes legacy documents, assigns nanoid)
  toPlatePlugin(NodeIdPlugin),

  // 2. Base Blocks & Code & Lists
  ...BlocksKit,

  // 3. Rich Blocks: Callout, Toggle, Table, Columns, Equation, TOC, Date
  ...RichContentKit,

  // 4. Media: Image, Video, Audio, File, Placeholder, Captions
  ...MediaKit,

  // 5. Marks & Inline Styles & Links
  ...MarksKit,

  // 6. Interaction: Gutter & DnD, Block Selection, Slash Combobox, Mentions
  ...InteractionKit,

  // AI & Collaboration kits are preserved in codebase but disabled for Stages 1-4
  // ...AIKit,
  // ...CollaborationKit,

  // 9. Markdown serialization
  toPlatePlugin(MarkdownPlugin),
];
