For **Level 1**, I would include the features that make the Toggle fundamentally usable as a real recursive editor/container primitive. This level should cover the core interaction model, editing, hierarchy, manipulation, state, and basic accessibility—without advanced collaboration, lazy loading, analytics, dynamic metadata, or application-specific behavior.

## Level 1 — Core Toggle Foundation

| No. | Feature |
|---:|---|
| **1** | Basic expand / collapse behavior |
| **2** | Arbitrary content inside the Toggle |
| **3** | Recursive nesting |
| **4** | Toggle headings |
| **5** | Rich-text title |
| **6** | Inline editing |
| **7** | Block transformation |
| **8** | Drag content into the Toggle |
| **9** | Drag content out of the Toggle |
| **10** | Drag the entire Toggle |
| **11** | Reordering children |
| **12** | Multi-block selection |
| **14** | Indent / outdent behavior |
| **15** | Keyboard creation |
| **16** | Enter-key behavior |
| **17** | Empty-child exit behavior |
| **18** | Backspace merging behavior |
| **19** | Slash-command support inside Toggles |
| **20** | Nested drag-and-drop targeting |
| **22** | Persistent expansion state |
| **23** | Collapse hides entire subtree |
| **24** | Child state preservation |
| **27** | Context menu |
| **28** | Duplicate |
| **29** | Delete |
| **30** | Unwrap |
| **31** | Copy / paste |
| **42** | Presence indicators *(optional for Level 1 if collaboration already exists)* |
| **49** | Animation |
| **50** | Chevron animation |
| **51** | Hover state |
| **52** | Drag handle |
| **53** | Full-row hit target |
| **54** | Hover indentation guides |
| **57** | Accessibility |
| **58** | Keyboard accessibility |
| **59** | Focus preservation |
| **63** | Undo / redo |
| **64** | Stable identifiers |
| **66** | Collapsed state separated from content state |
| **67** | Tree traversal |
| **68** | Ancestor-aware visibility |
| **80** | Empty state |
| **81** | First-child quick creation |
| **93** | Controlled mode |
| **94** | Uncontrolled mode |
| **96** | Styling variants |
| **97** | Depth-based styling |
| **99** | Truncated titles |
| **100** | Extremely deep hierarchy handling |

### Level 1 count

**48 features** from the original 100.

I would treat these as the foundation because they establish the five systems everything else depends on:

```text
Level 1
├── Toggle mechanics
├── Recursive block hierarchy
├── Editor interactions
├── Tree manipulation
└── Core UX + accessibility
```

Features like **search, deep links, comments, collaboration, expand-all/collapse-all, dynamic metadata, lazy loading, error states, virtualization, API exposure, breadcrumbs, TOC integration, accordion mode, analytics, and application-shell behavior** should go into Levels 2 and 3 rather than complicating the initial implementation.