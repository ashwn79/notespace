import assert from 'node:assert/strict';
import test from 'node:test';
import {
  BlockquotePlugin,
  H1Plugin,
  H2Plugin,
  H3Plugin,
  HorizontalRulePlugin,
} from '@platejs/basic-nodes/react';
import { CodeBlockPlugin, CodeLinePlugin } from '@platejs/code-block/react';
import { indent, outdent } from '@platejs/indent';
import { IndentPlugin } from '@platejs/indent/react';
import { deserializeMd, MarkdownPlugin, serializeMd } from '@platejs/markdown';
import { NodeIdPlugin, nanoid } from 'platejs';
import {
  createPlateEditor,
  createPlatePlugin,
  ParagraphPlugin,
  toPlatePlugin,
} from 'platejs/react';

const TodoPlugin = createPlatePlugin({
  key: 'todo',
  node: { isElement: true },
});

function createTestEditor(initialValue) {
  return createPlateEditor({
    plugins: [
      toPlatePlugin(NodeIdPlugin),
      ParagraphPlugin,
      H1Plugin,
      H2Plugin,
      H3Plugin,
      BlockquotePlugin,
      HorizontalRulePlugin,
      CodeBlockPlugin,
      CodeLinePlugin,
      TodoPlugin,
      IndentPlugin.configure({
        inject: {
          targetPlugins: ['p', 'h1', 'h2', 'h3', 'blockquote', 'code_block', 'todo'],
        },
      }),
      toPlatePlugin(MarkdownPlugin),
    ],
    value: initialValue,
  });
}

test('1. Stable Block IDs & Legacy Normalization', () => {
  // Legacy document without IDs
  const legacyDoc = [
    { type: 'h1', children: [{ text: 'XPACE Vision' }] },
    { type: 'p', children: [{ text: 'Persistent brand context' }] },
  ];

  const editor = createTestEditor(legacyDoc);

  assert.equal(editor.children.length, 2);
  assert.ok(editor.children[0].id, 'First block should have an id');
  assert.ok(editor.children[1].id, 'Second block should have an id');
  assert.notEqual(editor.children[0].id, editor.children[1].id, 'IDs must be unique');

  // Document with existing ID preserves it
  const existingId = 'custom_stable_id_123';
  const docWithId = [{ id: existingId, type: 'p', children: [{ text: 'Preserved' }] }];
  const editor2 = createTestEditor(docWithId);
  assert.equal(editor2.children[0].id, existingId, 'Existing ID must not be regenerated');
});

test('2. Block Type Conversion (Turn into / Slash execution)', () => {
  const editor = createTestEditor([
    { id: 'b1', type: 'p', children: [{ text: 'Turn me into Heading 2' }] },
  ]);

  // In-place conversion
  editor.tf.setNodes({ type: 'h2' }, { at: [0] });
  assert.equal(editor.children[0].type, 'h2');
  assert.equal(editor.children[0].children[0].text, 'Turn me into Heading 2');

  // Convert to Blockquote
  editor.tf.setNodes({ type: 'blockquote' }, { at: [0] });
  assert.equal(editor.children[0].type, 'blockquote');

  // Convert to Todo
  editor.tf.setNodes({ type: 'todo', checked: false }, { at: [0] });
  assert.equal(editor.children[0].type, 'todo');
  assert.equal(editor.children[0].checked, false);
});

test('3. Block Duplication Generates Fresh IDs (including nested children)', () => {
  const editor = createTestEditor([
    { id: 'parent_1', type: 'h2', children: [{ text: 'Section' }] },
    { id: 'child_1', type: 'p', indent: 1, children: [{ text: 'Indented child' }] },
    { id: 'other_1', type: 'p', children: [{ text: 'Next section' }] },
  ]);

  const parentElement = editor.children[0];
  const index = editor.children.findIndex((n) => n.id === parentElement.id);
  const parentIndent = parentElement.indent || 0;
  const blocksToDuplicate = [editor.children[index]];

  for (let i = index + 1; i < editor.children.length; i++) {
    const child = editor.children[i];
    if ((child.indent || 0) > parentIndent) {
      blocksToDuplicate.push(child);
    } else {
      break;
    }
  }

  assert.equal(blocksToDuplicate.length, 2, 'Should group parent and indented child');

  const cloned = blocksToDuplicate.map((b) => {
    const copy = JSON.parse(JSON.stringify(b));
    copy.id = nanoid();
    return copy;
  });

  const insertAt = index + blocksToDuplicate.length;
  editor.tf.insertNodes(cloned, { at: [insertAt] });

  assert.equal(editor.children.length, 5);
  // Verify cloned items have new IDs
  assert.notEqual(editor.children[2].id, 'parent_1', 'Cloned parent must have fresh ID');
  assert.notEqual(editor.children[3].id, 'child_1', 'Cloned child must have fresh ID');
  assert.equal(editor.children[2].type, 'h2');
  assert.equal(editor.children[3].type, 'p');
  assert.equal(editor.children[3].indent, 1);
});

test('4. Block Deletion & Empty Document Guard', () => {
  const editor = createTestEditor([{ id: 'b1', type: 'p', children: [{ text: 'Only block' }] }]);

  // Remove the block
  editor.tf.removeNodes({ at: [0] });

  // Guard: if empty, restore empty paragraph
  if (editor.children.length === 0) {
    editor.tf.insertNodes([{ id: nanoid(), type: 'p', children: [{ text: '' }] }], { at: [0] });
  }

  assert.equal(editor.children.length, 1);
  assert.equal(editor.children[0].type, 'p');
  assert.ok(editor.children[0].id);
});

test('5. Nesting & Indentation Bounds', () => {
  const editor = createTestEditor([
    { id: 'root_1', type: 'p', children: [{ text: 'Root item' }] },
    { id: 'sub_1', type: 'p', children: [{ text: 'Sub item' }] },
  ]);

  // Rule: root block at [0] cannot be indented
  const rootPath = [0];
  const canIndentRoot = !(rootPath[0] === 0 && rootPath.length === 1);
  assert.equal(canIndentRoot, false, 'First block cannot be indented under nothing');

  // Indent second block
  editor.tf.select([1, 0]);
  indent(editor);
  assert.equal(editor.children[1].indent, 1);

  // Indent again
  indent(editor);
  assert.equal(editor.children[1].indent, 2);

  // Outdent
  outdent(editor);
  assert.equal(editor.children[1].indent, 1);

  // Outdent back to root
  outdent(editor);
  assert.equal(editor.children[1].indent, undefined);
});

test('6. Markdown Serialization and Deserialization', () => {
  const editor = createTestEditor([
    { id: '1', type: 'h1', children: [{ text: 'Architecture' }] },
    { id: '2', type: 'p', children: [{ text: 'A brand-centric system.' }] },
    { id: '3', type: 'blockquote', children: [{ text: 'Persistence over platforms.' }] },
    { id: '4', type: 'hr', children: [{ text: '' }] },
  ]);

  const md = serializeMd(editor);
  assert.ok(md.includes('# Architecture'), 'Markdown must contain H1');
  assert.ok(md.includes('A brand-centric system.'), 'Markdown must contain paragraph text');
  assert.ok(md.includes('> Persistence over platforms.'), 'Markdown must contain quote');
  assert.ok(md.includes('---') || md.includes('***'), 'Markdown must contain divider (--- or ***)');

  // Deserialization round-trip
  const deserialized = deserializeMd(editor, '# New Heading\n\n> Quote text\n\n---\n');
  assert.ok(Array.isArray(deserialized));
  assert.ok(deserialized.some((n) => n.type === 'h1'));
});

test('7. Potion Block Structures (Callout, Toggle, Table, Columns, Equation, Date, TOC)', () => {
  const CalloutPlugin = createPlatePlugin({ key: 'callout', node: { isElement: true } });
  const TogglePlugin = createPlatePlugin({ key: 'toggle', node: { isElement: true } });
  const TablePlugin = createPlatePlugin({ key: 'table', node: { isElement: true } });
  const TableRowPlugin = createPlatePlugin({ key: 'tr', node: { isElement: true } });
  const TableCellPlugin = createPlatePlugin({ key: 'td', node: { isElement: true } });
  const ColumnGroupPlugin = createPlatePlugin({ key: 'column_group', node: { isElement: true } });
  const ColumnPlugin = createPlatePlugin({ key: 'column', node: { isElement: true } });
  const EquationPlugin = createPlatePlugin({ key: 'equation', node: { isElement: true } });
  const TocPlugin = createPlatePlugin({ key: 'toc', node: { isElement: true } });
  const DatePlugin = createPlatePlugin({ key: 'date', node: { isElement: true, isInline: true } });

  const potionEditor = createPlateEditor({
    plugins: [
      toPlatePlugin(NodeIdPlugin),
      ParagraphPlugin,
      CalloutPlugin,
      TogglePlugin,
      TablePlugin,
      TableRowPlugin,
      TableCellPlugin,
      ColumnGroupPlugin,
      ColumnPlugin,
      EquationPlugin,
      TocPlugin,
      DatePlugin,
    ],
    value: [
      {
        id: 'c1',
        type: 'callout',
        icon: '💡',
        children: [{ type: 'p', children: [{ text: 'Important brand insight' }] }],
      },
      { id: 't1', type: 'toggle', children: [{ text: 'Toggle summary' }] },
      {
        id: 'tbl1',
        type: 'table',
        children: [
          {
            type: 'tr',
            children: [
              { type: 'td', children: [{ type: 'p', children: [{ text: 'Header 1' }] }] },
              { type: 'td', children: [{ type: 'p', children: [{ text: 'Header 2' }] }] },
            ],
          },
        ],
      },
      {
        id: 'cols1',
        type: 'column_group',
        layout: [50, 50],
        children: [
          { type: 'column', width: 50, children: [{ type: 'p', children: [{ text: 'Col 1' }] }] },
          { type: 'column', width: 50, children: [{ type: 'p', children: [{ text: 'Col 2' }] }] },
        ],
      },
      { id: 'eq1', type: 'equation', texExpression: 'E = mc^2', children: [{ text: '' }] },
      { id: 'toc1', type: 'toc', children: [{ text: '' }] },
      {
        id: 'p_date',
        type: 'p',
        children: [
          { text: 'Deadline: ' },
          { type: 'date', date: '2026-10-01', children: [{ text: '' }] },
        ],
      },
    ],
  });

  assert.equal(potionEditor.children.length, 7);
  assert.equal(potionEditor.children[0].type, 'callout');
  assert.equal(potionEditor.children[1].type, 'toggle');
  assert.equal(potionEditor.children[2].type, 'table');
  assert.equal(potionEditor.children[3].type, 'column_group');
  assert.equal(potionEditor.children[4].type, 'equation');
  assert.equal(potionEditor.children[5].type, 'toc');
  assert.equal(potionEditor.children[6].children[1].type, 'date');
});
