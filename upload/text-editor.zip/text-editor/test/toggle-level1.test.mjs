import assert from 'node:assert/strict';
import test from 'node:test';
import {
  getContainerDescendants,
  getContainerSubtree,
  getEffectiveIndentOffset,
  getToggleAncestors,
  hasToggleChildren,
  removeContainerSubtree,
  unwrapToggle,
} from '../src/plate-ui/toggle-utils.ts';
import { createPlateEditor, ParagraphPlugin } from 'platejs/react';
import { NodeIdPlugin, nanoid } from 'platejs';

function createMockEditor(children) {
  return {
    children,
    tf: {
      withoutNormalizing: (fn) => fn(),
      setNodes: (props, { at }) => {
        const idx = at[0];
        if (children[idx]) {
          Object.assign(children[idx], props);
        }
      },
      unsetNodes: (keys, { at }) => {
        const idx = at[0];
        if (children[idx]) {
          const keyList = Array.isArray(keys) ? keys : [keys];
          keyList.forEach((k) => delete children[idx][k]);
        }
      },
      removeNodes: ({ at }) => {
        const idx = at[0];
        children.splice(idx, 1);
      },
    },
  };
}

test('Toggle Level 1 — Descendant Tree Traversal', () => {
  const doc = [
    { id: 't1', type: 'toggle', indent: 0, children: [{ text: 'Parent Toggle' }] },
    { id: 'c1', type: 'p', indent: 1, children: [{ text: 'Child 1' }] },
    { id: 't2', type: 'toggle', indent: 1, children: [{ text: 'Nested Toggle' }] },
    { id: 'c2', type: 'p', indent: 2, children: [{ text: 'Grandchild' }] },
    { id: 'outside', type: 'p', indent: 0, children: [{ text: 'Outside block' }] },
  ];
  const editor = createMockEditor(doc);

  // 1. Descendants of t1
  const descendantsT1 = getContainerDescendants(editor, 't1');
  assert.equal(descendantsT1.length, 3, 't1 should have 3 descendants (c1, t2, c2)');
  assert.deepEqual(descendantsT1.map(([n]) => n.id), ['c1', 't2', 'c2']);

  // 2. Descendants of nested t2
  const descendantsT2 = getContainerDescendants(editor, 't2');
  assert.equal(descendantsT2.length, 1, 't2 should have 1 descendant (c2)');
  assert.equal(descendantsT2[0][0].id, 'c2');

  // 3. hasToggleChildren
  assert.equal(hasToggleChildren(editor, 't1'), true);
  assert.equal(hasToggleChildren(editor, 't2'), true);

  // Empty toggle
  const emptyToggleDoc = [
    { id: 'empty_t', type: 'toggle', indent: 0, children: [{ text: 'Empty' }] },
    { id: 'next_block', type: 'p', indent: 0, children: [{ text: 'Next' }] },
  ];
  const emptyEditor = createMockEditor(emptyToggleDoc);
  assert.equal(hasToggleChildren(emptyEditor, 'empty_t'), false);
});

test('Toggle Level 1 — Ancestor Aware Traversal', () => {
  const doc = [
    { id: 't1', type: 'toggle', indent: 0, children: [{ text: 'Root Toggle' }] },
    { id: 't2', type: 'toggle', indent: 1, children: [{ text: 'Level 1 Toggle' }] },
    { id: 'target', type: 'p', indent: 2, children: [{ text: 'Deep block' }] },
  ];
  const editor = createMockEditor(doc);

  const ancestors = getToggleAncestors(editor, 'target');
  assert.equal(ancestors.length, 2, 'target should have 2 toggle ancestors');
  assert.deepEqual(ancestors.map(([n]) => n.id), ['t1', 't2']);
});

test('Toggle Level 1 — Unwrap Toggle', () => {
  const doc = [
    { id: 't1', type: 'toggle', indent: 0, open: true, headingLevel: 2, children: [{ text: 'Heading Toggle' }] },
    { id: 'c1', type: 'p', indent: 1, children: [{ text: 'Child 1' }] },
    { id: 'c2', type: 'p', indent: 2, children: [{ text: 'Nested child' }] },
    { id: 'after', type: 'p', indent: 0, children: [{ text: 'After' }] },
  ];
  const editor = createMockEditor(doc);

  unwrapToggle(editor, 't1');

  // t1 should now be an h2 without toggle metadata
  assert.equal(editor.children[0].type, 'h2');
  assert.equal(editor.children[0].open, undefined);
  assert.equal(editor.children[0].headingLevel, undefined);

  // Children should be outdented by 1
  assert.equal(editor.children[1].indent, undefined, 'c1 should be at root indent (0/undefined)');
  assert.equal(editor.children[2].indent, 1, 'c2 should be at indent 1');
  assert.equal(editor.children[3].indent, 0, 'after block should remain untouched');
});

test('Toggle Level 1 — Remove Container Subtree', () => {
  const doc = [
    { id: 't1', type: 'toggle', indent: 0, children: [{ text: 'Toggle to delete' }] },
    { id: 'c1', type: 'p', indent: 1, children: [{ text: 'Child to delete' }] },
    { id: 'c2', type: 'p', indent: 2, children: [{ text: 'Deep child to delete' }] },
    { id: 'survivor', type: 'p', indent: 0, children: [{ text: 'Survivor' }] },
  ];
  const editor = createMockEditor(doc);

  removeContainerSubtree(editor, 't1');

  assert.equal(editor.children.length, 1);
  assert.equal(editor.children[0].id, 'survivor');
});

test('Toggle Level 1 — Deep Hierarchy Indentation Dampening', () => {
  // Up to level 6: linear 24px step
  assert.equal(getEffectiveIndentOffset(0), 0);
  assert.equal(getEffectiveIndentOffset(1), 24);
  assert.equal(getEffectiveIndentOffset(3), 72);
  assert.equal(getEffectiveIndentOffset(6), 144);

  // Beyond level 6: dampened 12px step so text is not pushed offscreen
  assert.equal(getEffectiveIndentOffset(7), 144 + 12);
  assert.equal(getEffectiveIndentOffset(8), 144 + 24);
  assert.equal(getEffectiveIndentOffset(10), 144 + 48);
});
